package com.ibm.plugin.util;

public class FilenetUtil {
	


}
