require(["dojo/_base/declare",
         "dojo/_base/lang","openCasePluginDojo/OpenCaseDetails"],
function(declare, lang,OpenCaseDetails) {		
	/**
	 * Use this function to add any global JavaScript methods your plug-in requires.
	 */
	
	lang.setObject("openCaseAction", function(repository, items, callback, teamspace, resultSet, parameterMap) {
	 
		
		debugger;
		console.log("Action Executed.....");
		console.log("Action Executed.....items",items);
		console.log("Action Executed.....resultSet",resultSet);
		console.log("Action Executed.....callback",callback);
		console.log("Action Executed.....repository",repository);
		
		/*var caseIdentifier="LINUX_Auto_000000210001";
		var url="https://cpd-ibm-cloudpaks-irb.cp4ba-ecmcoeirb-008a68085875ce640a8dcdfab0434f25-0000.us-south.containers.appdomain.cloud/icn/navigator/?desktop=baw&feature=Cases&tos=BAWTOS&solution=LINUX&caseGUID=%1";
		url=url.replace("%1",caseIdentifier);
		
		console.log("url>> ",url);
		
		window.open(url, '_blank');*/
		
		
	
		
		
		
		openCaseDetailsObj.executeOpenCaseDetails(repository, items, callback, teamspace, resultSet, parameterMap);
		
		
		
		
	});
});
