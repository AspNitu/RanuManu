

require(["dojo/_base/declare","dojo/_base/lang"],function(declare,lang){
	debugger;
	
	lang.setObject("openCaseDetailsObj",{
		
		"executeOpenCaseDetails":function(repository, items, callback, teamspace, resultSet, parameterMap){
			
			var docID="";
			var repoId="";
			
			console.log("itemArr",items[0]);
			for(var i=0;i<items.length;i++){
				if(i==0){
					docID=items[i].docid;
				}
				repoId=items[i].repository.id;
			}
			console.log("docID",docID);
			console.log("repoId",repoId);
			
			//call the pluginService
			
			
			
			var caseIDArray;
			for(var i=0;i<caseIDArray.length;i++){
				var caseID=caseIDArray[i];
				console.log("caseID>>",caseID);
				var url="https://cpd-ibm-cloudpaks-irb.cp4ba-ecmcoeirb-008a68085875ce640a8dcdfab0434f25-0000.us-south.containers.appdomain.cloud/icn/navigator/?desktop=baw&feature=Cases&tos=BAWTOS&solution=LINUX&caseGUID=%1";
				url=url.replace("%1",caseIdentifier);
				console.log("url>> ",url);
				window.open(url, '_blank');
			}
			
			
			
			
			
			
		}
		
		
		
	});
	
	
});