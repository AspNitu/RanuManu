/* Scripts having all the PropertyUpdated/FieldUpdated validation.. 04/11/2020 v2*/

/* Import here all the Modules used in your JS */
require(["icm/base/Constants", "icm/model/properties/controller/ControllerManager", "dojo/_base/lang", "dojo/_base/array", "dojo/date"], function(Constants, ControllerManager, lang, array, date) {

    lang.setObject("IBC_OnFieldUpdate", {

        /* Method to return payload */
        "passthrough": function(payload, solution, role, scriptAdaptor) {
            return payload;
        },

        /* Main Method for OnLoad Scripts */
        "OnFieldUpdateAction": function(payload, solution, role, scriptAdaptor) {

            var self = scriptAdaptor;
            self.pg_UserId = ecm.model.desktop.userId;
            self.pg_UserName = ecm.model.desktop.userDisplayName;
            self.pg_coordination = payload.coordination;
            self.pg_solution = scriptAdaptor.solution;
            self.pg_prefix = scriptAdaptor.solution.getPrefix();
            self.pg_eventName = payload.eventName;
            self.pg_role = ecm.model.desktop.currentRole.name;
            var dailogMessage = "";

            if (self.pg_eventName == "icm.PropertyUpdated") {
                self.pg_editable = payload.caseEditable;
                /* self.pg_editable=payload.workItemEditable; */

                self.propValue = payload.value;
                var propId = payload.property.binding;
                self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);
                var operationController = self.pg_propCollectionController.getPropertyController("COMMN_Operation");
                var operation = operationController.get("value");
				var subOperation = getPropValue("COMMN_SubOperation");

                /* Do the Updated Stuff */
                /* Auto populate  propertyValue from one tab to other */

                if (propId == "F_CaseFolder.COMMN_AccountNotobeDebited") {
                    exchangePropValue("COMMN_Dev_ACID");
                }
                if (propId == "F_CaseFolder.COMMN_RolloverIBCNo") {
                    exchangePropValue("COMMN_LimitRefNo");
                }
                if (propId == "F_CaseFolder.COMMN_BillType") {
                    exchangePropValue("COMMN_FinSTP_BILLTYPE");
                }
                if (propId == "F_CaseFolder.COMMN_Custid") {
                    exchangePropValue("COMMN_CIFID");
                }
                if (propId == "F_CaseFolder.COMMN_OperativeAccountNo") {
                    exchangePropValue("COMMN_OPERATIVEACID");
                }
                if (propId == "F_CaseFolder.COMMN_OtherBankAccountNo") {
                    exchangePropValue("COMMN_REFNO");
                }
                if (propId == "F_CaseFolder.COMMN_TotalClaimedAmount") {
                    exchangePropValue("COMMN_BILLAMT");
                    exchangePropValue("COMMN_DateandAmountofUtilization32AAmount");
                    exchangePropValue("COMMN_BILLAMOUNT");
                }
                if (propId == "F_CaseFolder.COMMN_SFMS_OtherBankRefNo") {
                    exchangePropValue("COMMN_HSMG_RELATEDREF");
                }
                if (propId == "F_CaseFolder.COMMN_BeneficiaryNameonInvoice") {
                    exchangePropValue("COMMN_NAME");
                }
                if (propId == "F_CaseFolder.COMMN_BeneficiaryAddress") {
                    exchangePropValue("COMMN_ADDRESSLINE1");
                    exchangePropValue("COMMN_ADDRESSLINE2");
                    exchangePropValue("COMMN_ADDRESSLINE3");
                }
                if (propId == "F_CaseFolder.COMMN_BeneficiaryCity") {
                    exchangePropValue("COMMN_CITY");
                }
                if (propId == "F_CaseFolder.COMMN_BeneficiaryState") {
                    exchangePropValue("COMMN_STATE");
                }
                if (propId == "F_CaseFolder.COMMN_BeneficiaryPostalCode") {
                    exchangePropValue("COMMN_POSTALCODE");
                }
                if (propId == "F_CaseFolder.COMMN_DCUtilizationAmount") {
                    exchangePropValue("COMMN_DOCUMENTRYCREDITUTILIZEDAMOUNT");
                }
                if (propId == "F_CaseFolder.COMMN_OtherBankRefno") {
                    exchangePropValue("COMMN_FinSTP_OTHERBANKSREFNO");
                }
                if (propId == "F_CaseFolder.COMMN_SFMS_OtherBankRefNo") {
                    exchangePropValue("COMMN_OTHERBANKSREFNO");
                }
                if (propId == "F_CaseFolder.COMMN_PaysisId") {
                    exchangePropValue("COMMN_PAYSYSID");
                }
                if (propId == "F_CaseFolder.COMMN_InvoiceAmount") {
                    exchangePropValue("COMMN_INVOICEAMT");
                }
                if (propId == "F_CaseFolder.COMMN_InvoiceNo") {
                    exchangePropValue("COMMN_FinSTP_INVOICENO");
                }
                if (propId == "F_CaseFolder.COMMN_InvoiceDate") {
                    exchangePropValue("COMMN_FinSTP_INVOICEDATE");
                }
                if (propId == "F_CaseFolder.COMMN_OtherBankCharges") {
                    exchangePropValue("COMMN_OTHERBANKINTERESTAMOUNT");
                    exchangePropValue("COMMN_OTHERBANKINTERESTAMT");
                    exchangePropValue("COMMN_Real_COMMISSION");
                }
                if (propId == "F_CaseFolder.COMMN_DraftNo") {
                    exchangePropValue("COMMN_FinSTP_DRAFTNO");
                }
                if (propId == "F_CaseFolder.COMMN_GracePeriod") {
                    exchangePropValue("COMMN_GRACEPERIODDDD");
                }
                if (propId == "F_CaseFolder.COMMN_DraftDate") {
                    exchangePropValue("COMMN_BILLDATE");
                }
                if (propId == "F_CaseFolder.COMMN_DocumentReceivedDate") {
                    exchangePropValue("COMMN_DOCUMENTSRECEIVEDON");
                }
                if (propId == "F_CaseFolder.COMMN_LRGRBOLDate") {
                    exchangePropValue("COMMN_ONBOARDDATE");
                }
                if (propId == "F_CaseFolder.COMMN_DueDate") {
                    exchangePropValue("COMMN_FinSTP_DUEDATE");
                }
                if (propId == "F_CaseFolder.COMMN_AcceptedAmount") {
                    exchangePropValue("COMMN_Real_BILLREALIZATIONAMT");
                    exchangePropValue("COMMN_Real_PAYMENTAMT");
                }
                if (propId == "F_CaseFolder.COMMN_GST") {
                    exchangePropValue("COMMN_Real_IMMEDIATECOLLECTIONAMTGST");
                }
                if (propId == "F_CaseFolder.COMMN_PostageonIBC") {
                    exchangePropValue("COMMN_Real_IMMEDIATECOLLECTIONAMTPostage");
                }
                if (propId == "F_CaseFolder.COMMN_PostageGST") {
                    exchangePropValue("COMMN_Real_IMMEDIATECOLLECTIONAMTPostageGST");
                }
                if (propId == "F_CaseFolder.COMMN_SFMSCharges") {
                    exchangePropValue("COMMN_Real_IMMEDIATECOLLECTIONAMTSFMS");
                }
                if (propId == "F_CaseFolder.COMMN_SFMSGST") {
                    exchangePropValue("COMMN_Real_IMMEDIATECOLLECTIONAMTSFMSGST");
                }
                if (propId == "F_CaseFolder.COMMN_MessageType") {
                    exchangePropValue("COMMN_HSMG_MESSAGENO");
                }
                if (propId == "F_CaseFolder.COMMN_EntityType") {
                    exchangePropValue("COMMN_HSMG_ENTITYTYPE");
                }
                if (propId == "F_CaseFolder.COMMN_EntityId") {
                    exchangePropValue("COMMN_HSMG_ENTITYID");
                }
                if (propId == "F_CaseFolder.COMMN_DrawerBankCodeSFMSIFScode") {
                    exchangePropValue("COMMN_HSMG_RECEIVERBIC");
                }
                if (propId == "F_CaseFolder.COMMN_TenorFrom") {
                    exchangePropValue("COMMN_TENORDESC");
                }
                if (propId == "F_CaseFolder.COMMN_Narrative77A") {
                    exchangePropValue("COMMN_DISCREPANCIES");
                }
                if (propId == "F_CaseFolder.COMMN_AccountNotobeDebited") {
                    exchangePropValue("COMMN_Real_ACID");
                }
                if (propId == "F_CaseFolder.COMMN_CommissiononIBC") {
                    exchangePropValue("COMMN_Real_IMMEDIATECOLLECTIONAMT");
                }
                if (propId == "F_CaseFolder.COMMN_AmounttobeRecover") {
                    exchangePropValue("COMMN_Re_RECOVERYAMOUNT");
                }
                if (propId == "F_CaseFolder.COMMN_Narrative") {
                    exchangePropValue("COMMN_HSMG_NarrativeFreeText");
                }
                if (propId == "F_CaseFolder.COMMN_FinacleRefNo") {
                    exchangePropValue("COMMN_Accep_FinacleRefNo");
                    exchangePropValue("COMMN_Dev_FinacleRefNo");
                    exchangePropValue("COMMN_Dis_FinacleRefNo");
                    exchangePropValue("COMMN_Real_FinacleRefNo");
					exchangePropValue("COMMN_Re_FinacleRefNo");
                }
                if (propId == "F_CaseFolder.COMMN_OurBankCharges") {
                    exchangePropValue("COMMN_AMT");
                }

                if (propId == "F_CaseFolder.COMMN_DTFCDEEFERALREASON") {
                    exchangePropValue("COMMN_SELECTEDDTFCDEFERALREASON");
                }

                if (propId == "F_CaseFolder.COMMN_DTFCHOLDREASON") {
                    exchangePropValue("COMMN_SELECTEDDTFCHOLDREASONS");
                }

                if (propId == "F_CaseFolder.COMMN_TenorFrom") {
                    exchangePropValue("COMMN_DUEDATEIND");
                }

                if (propId == "F_CaseFolder.COMMN_ACCEPTANCEREJECTIONREASON") {
                    exchangePropValue("COMMN_SELECTEDACCEPTANCEREJECTIONREASON");
                }
                if (propId == "F_CaseFolder.COMMN_EntityType") {
                    var entityTypeValue = self.propValue;
                    if (entityTypeValue == 'DOCCR-Doumentary Credit') {
                        var docCredit = getPropValue('COMMN_DocumentaryCreditNoonBankCoverLetter');
                        setPropValue("COMMN_EntityId", docCredit);
                    }
                    if (entityTypeValue == 'FBILL-Foreign Bill') {
                        var finRefNum = getPropValue('COMMN_FinacleRefNo');
                        setPropValue("COMMN_EntityId", finRefNum);
                    }
                    if (entityTypeValue == null || entityTypeValue == undefined) {
                        setPropValue("COMMN_EntityId", "");
                    }
                }

                /* rejectiongrid */
                if (self.pg_role == "SFMS AUTH" || self.pg_role == "DTFC COMP") {
                    if (propId == "F_CaseFolder.COMMN_RejectionReason") {
                        var RejectionReason = self.propValue;
                        var rejectReasonGrid = RejectionReason[self.current_row];
                        if (rejectReasonGrid != null || rejectReasonGrid != undefined) {

                            var gapResolved = getPropValue("COMMN_WhetherGapResolved");
                            var branchComment = getPropValue("COMMN_BranchComment");
                            gapResolved[self.current_row] = 'Yes';
                            branchComment[self.current_row] = 'NA';
                            setPropValue("COMMN_WhetherGapResolved", gapResolved);
                            setPropValue("COMMN_BranchComment", branchComment);
                        }
                    }
                }
                //deferral grid
                if (self.pg_role == "PENDING REALISATION" || self.pg_role == "REALISATION FIN ENTRY" || self.pg_role == "REALISATION FIN AUTH" || self.pg_role == "RTGS ENTRY" || self.pg_role == "RTGS AUTH" ||  self.pg_role == "RECOVERY AUTH") {
                    if (propId == "F_CaseFolder.COMMN_DeferralReason") {
                        var deferralReason = self.propValue;
                        var deferReasonGrid = deferralReason[self.current_row];
                        if (deferReasonGrid != null || deferReasonGrid != undefined) {
                            var dtfcComment = getPropValue("COMMN_DTFCComment");
                            dtfcComment[self.current_row] = 'NA';
                            setPropValue("COMMN_DTFCComment", dtfcComment);
                        }
                    }
                }
				
				
				
				
				
				
                if (propId == "F_CaseFolder.COMMN_SubOperation") {
					freezeNonMandateAllProps();
                    var subOperation = self.propValue;
                 
					//All role onLoad Scripts
				    if (subOperation == 'ACCEPTANCE') {
					setPropValue("COMMN_Accep_FUNCTION", 'A');
                    }
                    if (subOperation == 'REALIZATION') {
                        setPropValue("COMMN_Real_FUNCTION", 'R');
                    }
                    if (subOperation == 'RECOVERY') {
                        setPropValue("COMMN_Re_FUNCTION", 'O');
                    }
                    if (subOperation == 'DISHONOR') {
                        setPropValue("COMMN_Dis_FUNCTION", 'N');
                    }
					
					if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
						var collectionOnBill = getPropValue('COMMN_CollectiononBill');
						if (collectionOnBill == 'Backed by LC') {
							setPropValue("COMMN_UNDERDOCUMENTRYCREDIT", 'Yes');
						}
					}
					
					var devDecision = self.pg_propCollectionController.getPropertyController("COMMN_DevolvedDecision");
					var devDecisionValue = devDecision.get("value");
					if (devDecisionValue == 'Devolvement' || devDecisionValue == 'Open New Devolvement account' || devDecisionValue == 'Existing Devolvement Account' || devDecisionValue == 'TOD') {
						setPropValue("COMMN_Dev_FUNCTION", 'K');
						
						var enableProps = ['COMMN_Dev_DELINKACCOUNTNO', 'COMMN_Dev_REALIZATIONACID', 'COMMN_Dev_PURCHASESALE', 'COMMN_Dev_ACID', 'COMMN_Dev_CHARGEEVENTID'];
						doPropsAction(enableProps, "enable");
						doPropsAction(enableProps, "Mandate");
					}

					var devProcessing = self.pg_propCollectionController.getPropertyController("COMMN_Dev_ProcessingType");
					var devProcessingValue = devProcessing.get("value");
					if (devProcessingValue == 'Manual') {
						var mandateProps = ['COMMN_Dev_FinacleRefNo'];
						doPropsAction(mandateProps, "Mandate");
					}
					
					//Role Wise where Sub-operation is editable
					if(self.pg_role == "ACCEPTANCE SFMS AUTH"){
					    var enableProps = ['COMMN_SubOperation'];
						doPropsAction(enableProps, "enable");
						doPropsAction(enableProps, "Mandate");
					}
                    if (self.pg_role == "BR ACCEPT MAKER") {
						
						var enableProps = ['COMMN_SubOperation', 'COMMN_EarlierWID', 'COMMN_SignatureVerifiedbyEmployeeId'];
						var mandateProps = ['COMMN_SubOperation','COMMN_SignatureVerifiedbyEmployeeId'];

						doPropsAction(enableProps, "enable");
						doPropsAction(mandateProps, "Mandate");

						if (operation == 'LODGEMENT') {
							var enableProps = ['COMMN_TradePortalRefNo'];
							doPropsAction(enableProps, "enable");
						}

						if (operation == 'PRE-ACCEPTED') {
							var mandateProps = ['COMMN_SignatureVerifiedbyEmployeeId'];
							doPropsAction(mandateProps, "Mandate");
							doPropsAction(mandateProps, "enable");
						}

						if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'REALIZATION' || subOperation == 'ROLLOVER'))) {
							var enableProps = ['COMMN_AccountNotobeDebited'];
							doPropsAction(enableProps, "enable");
							doPropsAction(enableProps, "Mandate");
						}

						var branchDecision = getPropValue('COMMN_DTFCHoldBranchdecision');
						var subOperation = getPropValue('COMMN_SubOperation');
						if (branchDecision == 'Return Document' || subOperation == 'DISHONOR') {
							var enableProps = ['COMMN_CourierNo', 'COMMN_CourierCoName', 'COMMN_DateofReturn'];
							doPropsAction(enableProps, "enable");
						}
						
						var branchDecision = getPropValue('COMMN_DTFCHoldBranchdecision');
						var subOperation = getPropValue('COMMN_SubOperation');
						if (branchDecision == 'Return Document' || branchDecision == 'RETURN DOCUMENT' || subOperation == 'DISHONOR') {
							var enableProps = ['COMMN_CourierNo', 'COMMN_CourierCoName', 'COMMN_DateofReturn'];
							doPropsAction(enableProps, "enable");
						}
                        
                    }
                    if (self.pg_role == "BILL ACCEPTANCE") {
                       
						var enableProps = ['COMMN_SubOperation', 'COMMN_OtherBankRefno', 'COMMN_SFMSRequired'];

						var mandateProps = ['COMMN_SubOperation', 'COMMN_OtherBankRefno', 'COMMN_SFMSRequired','COMMN_HSMG_ENTITYTYPE', 'COMMN_HSMG_ENTITYID', 'COMMN_HSMG_PAYMENTSTATUS', 'COMMN_HSMG_RECEIVERBIC', 'COMMN_HSMG_RELATEDREF', 'COMMN_HSMG_NarrativeFreeText'];

						doPropsAction(enableProps, "enable");
						doPropsAction(mandateProps, "Mandate");

						if (operation == 'LODGEMENT') {
							var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_ChargeCollection', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID', 'COMMN_OurBankCharges', 'COMMN_Narrative77A'];

							var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_ChargeCollection', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo', 'COMMN_HSMG_PAYSISID','COMMN_OurBankCharges', 'COMMN_Narrative77A']

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'PRE-ACCEPTED') {
							var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_Narrative77A', 'COMMN_OtherMiscellaneousCharges', 'COMMN_OurBankCharges'];

							var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_Narrative77A', 'COMMN_OtherMiscellaneousCharges', 'COMMN_OurBankCharges'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'ROLLOVER') {
							var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_HSMG_PAYMENTSTATUS', 'COMMN_HSMG_RECEIVERBIC', 'COMMN_HSMG_RELATEDREF', 'COMMN_HSMG_NarrativeFreeText', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo', 'COMMN_HSMG_PAYSISID'];

							var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'MISCELLANEOUS' && subOperation == 'ACCEPTANCE') {
							var enableProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

							var mandateProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'MISCELLANEOUS' && subOperation == 'DISHONOR') {
							var enableProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

							var mandateProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo']

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') {
							var enableProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_RolloverInterestAmount', 'COMMN_RolloverIBCNo', 'COMMN_OtherMiscellaneousCharges', 'COMMN_Accep_ACCEPTANCEDATE', 'COMMN_DISCREPANCIES', 'COMMN_Accep_DOCUMENTSTYPE', 'COMMN_Accep_DOCUMENTSNO', 'COMMN_AMT', 'COMMN_Accep_SFMSFLAG', 'COMMN_Accep_CHARGEEVENTID', 'COMMN_Accep_PAYSYSID', 'COMMN_Accep_ProcessingType'];

							var mandateProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_SELECTEDACCEPTANCEREJECTIONREASON', 'COMMN_OtherMiscellaneousCharges', 'COMMN_Accep_ACCEPTANCEDATE', 'COMMN_DISCREPANCIES', 'COMMN_Accep_DOCUMENTSTYPE', 'COMMN_Accep_DOCUMENTSNO', 'COMMN_AMT', 'COMMN_Accep_SFMSFLAG', 'COMMN_Accep_CHARGEEVENTID', 'COMMN_Accep_PAYSYSID', 'COMMN_Accep_ProcessingType','COMMN_Accep_FUNCTION'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'LODGEMENT' && subOperation == 'ROLLOVER') {
							var enableProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_RolloverInterestAmount', 'COMMN_RolloverIBCNo', 'COMMN_OtherMiscellaneousCharges'];

							var mandateProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_SELECTEDACCEPTANCEREJECTIONREASON', 'COMMN_OtherMiscellaneousCharges'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'LODGEMENT' && subOperation == 'DISHONOR') {
							var enableProps = ['COMMN_ACCEPTANCEREJECTIONREASON','COMMN_Dis_ProcessingType', 'COMMN_RolloverInterestAmount', 'COMMN_RolloverIBCNo','COMMN_Dis_CHARGEEVENTID'];

							var mandateProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_Postage','COMMN_Dis_ProcessingType', 'COMMN_SELECTEDACCEPTANCEREJECTIONREASON','COMMN_Dis_CHARGEEVENTID','COMMN_Dis_FUNCTION'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'MISCELLANEOUS') {
							var enableProps = ['COMMN_ChargeCollection','COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo', 'COMMN_HSMG_PAYSISID'];

							var mandateProps = ['COMMN_ChargeCollection','COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
							var mandateProps = ['COMMN_OtherMiscellaneousCharges'];

							var enableProps = ['COMMN_OtherMiscellaneousCharges'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'CHARGE REVERSAL') {
							var enableProps = ['COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo', 'COMMN_HSMG_PAYSISID'];

							doPropsAction(enableProps, "enable");
							doPropsAction(enableProps, "Mandate");
						}

						if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR')) || operation == 'PRE-ACCEPTED' || operation == 'MISCELLANEOUS' || operation == 'ROLLOVER') {
							var msgTypeValue = getPropValue("COMMN_MessageType");

							var sfmsRequired = getPropValue("COMMN_SFMSRequired");
							if (msgTypeValue != '412' && sfmsRequired == 'Yes') {
								var enableProps = ['COMMN_Narrative'];
								doPropsAction(enableProps, "enable");
								doPropsAction(enableProps, "Mandate");
							}
						}
						
						if ((operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') || operation == 'PRE-ACCEPTED') {
							var mandateProps = ['COMMN_Accep_ACCEPTANCEDATE','COMMN_SignatureVerifiedbyEmployeeId'];
							doPropsAction(mandateProps, "Mandate");
						}
						
						if(operation == 'CHARGE REVERSAL' || operation == 'LODGEMENT' || operation == 'ROLLOVER' ||  operation == 'MISCELLANEOUS'){
							var enableProps = ['COMMN_HSMG_SOLID','COMMN_HSMG_ENTITYTYPE','COMMN_HSMG_ENTITYID','COMMN_HSMG_PAYMENTSTATUS','COMMN_HSMG_RECEIVERBIC','COMMN_HSMG_RELATEDREF','COMMN_HSMG_NarrativeFreeText'];
							doPropsAction(enableProps, "enable");
							doPropsAction(enableProps, "Mandate");
						}
                        
						var gridEnable = ['COMMN_RejectionReason', 'COMMN_RejectionCategory', 'COMMN_TFCComment', 'COMMN_BranchComment', 'COMMN_WhetherGapResolved'];
                        doPropsAction(gridEnable, "enable");	
						
						var gridEnable = ['COMMN_DISCREPENCY'];
                        doPropsAction(gridEnable, "enable");
							
						if(operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE'){
							var gridEnable = ['COMMN_FilterMessage_2','COMMN_InstructionBy_2','COMMN_InstructionDescription_2','COMMN_InstructionSubDesc_2'];
							doPropsAction(gridEnable,"enable");
						}
							
						if(operation == 'LODGEMENT' && subOperation == 'DISHONOR'){
							var gridEnable = ['COMMN_FilterMessage_6','COMMN_InstructionBy_6','COMMN_InstructionDescription_6','COMMN_InstructionSubDesc_6'];
							doPropsAction(gridEnable,"enable");
						}

						var msgTypeValue = getPropValue("COMMN_MessageType");
						if ((operation == "LODGEMENT" || operation == "ROLLOVER") && (!(self.pg_role == "FIN ENTRY" || self.pg_role == "ACCEPTANCE XMM ENTRY/MOD"))) {
							if (msgTypeValue != '412') {
								var enableProps = ['COMMN_EntityType'];
								doPropsAction(enableProps, "enable");
								doPropsAction(enableProps, "Mandate");
							}
						}
						if (operation == "LODGEMENT" || operation == "MISCELLANEOUS") {
							if (msgTypeValue != '412') {
								var enableProps = ['COMMN_EntityId'];
								doPropsAction(enableProps, "enable");
								doPropsAction(enableProps, "Mandate");
							}
						}
						
						var sfmsRequired = getPropValue("COMMN_SFMSRequired");
						var msgTypeValue = getPropValue("COMMN_MessageType");

						if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
							if (msgTypeValue == '754') {
								var enableProps = ['COMMN_Narrative77A'];
								doPropsAction(enableProps, "enable");
								doPropsAction(enableProps, "Mandate");
							}
						}

						if ((operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') || operation == 'PRE-ACCEPTED') {
							if (msgTypeValue == '754') {
								var enableProps = ['COMMN_SFMSFlag', 'COMMN_DocumentType', 'COMMN_DocumentNo', 'COMMN_DocumentDate'];
								doPropsAction(enableProps, "enable");
								doPropsAction(enableProps, "Mandate");
							}
						}

						if (sfmsRequired == 'Yes') {
							var enableProps = ['COMMN_MessageType'];
							doPropsAction(enableProps, "enable");
							doPropsAction(enableProps, "Mandate");
						}
						
						if (msgTypeValue == 'REJECTION 734') {
							var enableProps = ['COMMN_DisposalofDocuments'];
							doPropsAction(enableProps, "enable");
							doPropsAction(enableProps, "Mandate");
						}


						if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {
							var messageType = getPropValue("COMMN_MessageType");
							if (messageType == '754') {
								var enableProps = ['COMMN_AcceptanceDate'];
								doPropsAction(enableProps, "enable");
								doPropsAction(enableProps, "Mandate");
							}
						}

						if (operation == 'LODGEMENT' && (subOperation == 'REALIZATION' || subOperation == 'ROLLOVER' || subOperation == 'ACCEPTANCE')) {
							var enableProps = ['COMMN_RTGSIFSCode'];
							var mandateProps = ['COMMN_RTGSIFSCode'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}
						
						var billPayable = getPropValue('COMMN_BillPayable');
						if (billPayable == 'Usance') {
							var enableProps = ['COMMN_DueDate'];
							
							var mandateProps = ['COMMN_DueDate','COMMN_FinSTP_DUEDATE'];
							
							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}
						
						var chargeCollection = getPropValue("COMMN_ChargeCollection");

						if (chargeCollection == 'Yes') {
							var enableProps = ['COMMN_ChargeEventId', 'COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges'];
							var mandateProps = ['COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges', 'COMMN_ChargeEventId'];
							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						var collectionOnBill = getPropValue("COMMN_CollectiononBill");
						if (collectionOnBill == 'Backed by LC') {
							var enableProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
							doPropsAction(enableProps, "enable");

							var mandateProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
							doPropsAction(mandateProps, "Mandate");
						}

						if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR' || subOperation == 'REALIZATION' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {

							var chargeCollection = getPropValue("COMMN_ChargeCollection");
							if (chargeCollection == 'Yes') {
								var enableProps = ['COMMN_DiscrepancyGST'];
								var mandateProps = ['COMMN_DiscrepancyGST'];
								doPropsAction(enableProps, "enable");
								doPropsAction(mandateProps, "Mandate");
							}

							var collectionOnBill = getPropValue("COMMN_CollectiononBill");
							if (collectionOnBill == 'Backed by LC') {
								var enableProps = ['COMMN_DiscrepancyGST'];
								doPropsAction(enableProps, "enable");

								var mandateProps = ['COMMN_DiscrepancyGST'];
								doPropsAction(mandateProps, "Mandate");
							}
						}
                    }
                    if (self.pg_role == "DEVOLVED") {
                        
						var enableProps = ['COMMN_SubOperation'];
						doPropsAction(enableProps, "enable");
						doPropsAction(enableProps, "Mandate");

						if (operation == 'LODGEMENT') {
							var enableProps = ['COMMN_DevolvedDecision'];
							var mandateProps = ['COMMN_DevolvedDecision'];
							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if (operation == 'PRE-ACCEPTED') {
							var enableProps = ['COMMN_DevolvedDecision', 'COMMN_AmounttobeRecover', 'COMMN_AccountNofromAmounttobeRecover'];

							var mandateProps = ['COMMN_AccountName'];
							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}

						if ((operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') && subOperation == 'RECOVERY') {
							var enableProps = ['COMMN_Re_RECOVERYAMOUNT','COMMN_Re_ProcessingType','COMMN_Re_FUNCTION','COMMN_Re_CHARGEEVENTID'];

							var mandateProps = ['COMMN_Re_RECOVERYAMOUNT','COMMN_Re_ProcessingType','COMMN_Re_FUNCTION','COMMN_Re_CHARGEEVENTID'];

							doPropsAction(enableProps, "enable");
							doPropsAction(mandateProps, "Mandate");
						}
						if(((subOperation=="REALIZATION"||subOperation=="RECOVERY")&&operation=="LODGEMENT")|| operation == 'PRE-ACCEPTED'||operation == 'ROLLOVER'){
							doPropsAction(["COMMN_Recovery"], "enable");
							doPropsAction(["COMMN_Recovery"], "Mandate");
						}
						if (operation == 'LODGEMENT' && (subOperation == 'RECOVERY' || subOperation == 'REALIZATION')) {
							var mandateProps = ['COMMN_AmounttobeRecover', 'COMMN_AccountNofromAmounttobeRecover', 'COMMN_AccountName'];
							doPropsAction(mandateProps, "Mandate");

							var enableProps = ['COMMN_AccountNofromAmounttobeRecover', 'COMMN_AmounttobeRecover'];
							doPropsAction(enableProps, "enable");
						}

						if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR')) || operation == 'PRE-ACCEPTED' || operation == 'MISCELLANEOUS' || operation == 'ROLLOVER') {
							var msgTypeValue = getPropValue("COMMN_MessageType");

							var sfmsRequired = getPropValue("COMMN_SFMSRequired");
							if (msgTypeValue != '412' && sfmsRequired == 'Yes') {
								var enableProps = ['COMMN_Narrative'];
								doPropsAction(enableProps, "enable");
								doPropsAction(enableProps, "Mandate");
							}
						}
						
						if((operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED')&& subOperation == 'RECOVERY'){
							var gridEnable = ['COMMN_FilterMessage_5','COMMN_InstructionBy_5','COMMN_InstructionDescription_5','COMMN_InstructionSubDesc_5'];
							doPropsAction(gridEnable,"enable");
						}
                    }
                }

                if (propId == "F_CaseFolder.COMMN_CollectiononBill" || propId == "F_CaseFolder.COMMN_BillPayable") {
                    if (propId == "F_CaseFolder.COMMN_CollectiononBill") {
                        var collectionOnBill = self.propValue;
                        var billPayable = getPropValue('COMMN_BillPayable');
                    } else if (propId == "F_CaseFolder.COMMN_BillPayable") {
                        var billPayable = self.propValue;
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                    }

                    if (collectionOnBill == 'Backed by LC' && billPayable == 'Sight') {
                        setPropValue("COMMN_BillType", 'IBCSL');
                    }
                    if (collectionOnBill == 'Backed by LC' && billPayable == 'Usance') {
                        setPropValue("COMMN_BillType", 'IBCUL');
                    }
                    if (collectionOnBill == 'Non LC' && billPayable == 'Usance') {
                        setPropValue("COMMN_BillType", 'IBCU');
                    }
                    if (collectionOnBill == 'Non LC' && billPayable == 'Sight') {
                        setPropValue("COMMN_BillType", 'IBCS');
                    }

                    if (self.pg_role == "DTFC OCR") {
						if (collectionOnBill == 'Backed by LC') {
							doPropsAction(["COMMN_LCOpenDate", "COMMN_ApplicantNameinLC", "COMMN_BeneficiaryNameinLC"], "Mandate");
						} else {
							doPropsAction(["COMMN_LCOpenDate", "COMMN_ApplicantNameinLC", "COMMN_BeneficiaryNameinLC"], "Non_Mandate");
						}

						if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
							if (collectionOnBill == 'Backed by LC') {
								doPropsAction(["COMMN_LcAvailableValue"], "Mandate");
							} else {
								doPropsAction(["COMMN_LcAvailableValue"], "Non_Mandate");
							}
						}
					}

                    if (self.pg_role == "DTFC COMP") {
                        if (collectionOnBill == 'Backed by LC') {
                            doPropsAction(["COMMN_PlaceofExpiry", "COMMN_LCExpiryDate"], "Mandate");
                        } else {
                            doPropsAction(["COMMN_PlaceofExpiry", "COMMN_LCExpiryDate"], "Non_Mandate");
                        }
                    }

                    var operation = getPropValue('COMMN_Operation');
                    if (collectionOnBill == 'Backed by LC') {
                        setPropValue("COMMN_UNDERDOCUMENTRYCREDIT", 'Yes');

                        if ((self.pg_role == "DTFC COMP" || self.pg_role == "DTFC OCR") && (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED')) {
                            var enableProps = ['COMMN_DocumentaryCreditNoonBOE', 'COMMN_BankCoverLetterDate', 'COMMN_LatestShipmentDate', 'COMMN_DescreptionofDiscrepancyCharges', 'COMMN_GSTAmount', 'COMMN_OtherBankCharges', 'COMMN_DCUtilizationAmount'];
                            doPropsAction(enableProps, "enable");
                            var mandateProps = ['COMMN_DocumentaryCreditNoonBOE', 'COMMN_BankCoverLetterDate', 'COMMN_LatestShipmentDate', 'COMMN_DescreptionofDiscrepancyCharges', 'COMMN_DCUtilizationAmount', 'COMMN_OtherBankCharges'];
                            doPropsAction(mandateProps, "Mandate");
                        }

                    } else {
                        if (self.pg_role == "DTFC COMP" || self.pg_role == "DTFC OCR") {
                            var enableProps = ['COMMN_DocumentaryCreditNoonBOE', 'COMMN_BankCoverLetterDate', 'COMMN_LatestShipmentDate', 'COMMN_DescreptionofDiscrepancyCharges', 'COMMN_GSTAmount', 'COMMN_OtherBankCharges', 'COMMN_DCUtilizationAmount'];
                            doPropsAction(enableProps, "disable");
                            var mandateProps = ['COMMN_DocumentaryCreditNoonBOE', 'COMMN_BankCoverLetterDate', 'COMMN_LatestShipmentDate', 'COMMN_DescreptionofDiscrepancyCharges', 'COMMN_DCUtilizationAmount', 'COMMN_OtherBankCharges'];
                            doPropsAction(mandateProps, "Non_Mandate");
                        }

                    }

                    if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE" || self.pg_role == "PENDING REALISATION" || self.pg_role == "DTFC OCR") {
                        if (collectionOnBill == 'Backed by LC') {
                            var enableProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
                            doPropsAction(enableProps, "enable");

                            var mandateProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
                            doPropsAction(mandateProps, "Mandate");
                        } else {
                            var enableProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
                            doPropsAction(enableProps, "disable");

                            var mandateProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
                            doPropsAction(mandateProps, "Non_Mandate");
                        }

                        if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR' || subOperation == 'REALIZATION' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {

                            if (collectionOnBill == 'Backed by LC') {
                                var enableProps = ['COMMN_DiscrepancyGST'];
                                doPropsAction(enableProps, "enable");

                                var mandateProps = ['COMMN_DiscrepancyGST'];
                                doPropsAction(mandateProps, "Mandate");
                            } else {
                                var enableProps = ['COMMN_DiscrepancyGST'];
                                doPropsAction(enableProps, "disable");

                                var mandateProps = ['COMMN_DiscrepancyGST'];
                                doPropsAction(mandateProps, "Non_Mandate");
                            }
                        }
                    }

                    if (collectionOnBill == 'Non LC') {
                        setPropValue("COMMN_UNDERDOCUMENTRYCREDIT", 'No');
                        if ((self.pg_role == "DTFC COMP" || self.pg_role == "DTFC OCR") && (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED')) {
                            var enableProps = ['COMMN_BeneficiaryAddress', 'COMMN_BeneficiaryCity', 'COMMN_BeneficiaryState', 'COMMN_BeneficiaryPostalCode'];
                            doPropsAction(enableProps, "enable");

                            var mandateProps = ['COMMN_BILLAMT','COMMN_OTHERBANKSREFNO','COMMN_NAME','COMMN_ADDRESSLINE1','COMMN_ADDRESSLINE2', 'COMMN_ADDRESSLINE3','COMMN_CITY','COMMN_STATE','COMMN_POSTALCODE','COMMN_BeneficiaryAddress','COMMN_BeneficiaryCity'];
                            doPropsAction(mandateProps, "Mandate");
                        }

                    } else {
                        if (self.pg_role == "DTFC COMP" || self.pg_role == "DTFC OCR") {
                            var enableProps = ['COMMN_BeneficiaryAddress', 'COMMN_BeneficiaryCity', 'COMMN_BeneficiaryState', 'COMMN_BeneficiaryPostalCode'];
                            doPropsAction(enableProps, "disable");

                            var mandateProps = ['COMMN_BILLAMT','COMMN_OTHERBANKSREFNO','COMMN_NAME','COMMN_ADDRESSLINE1','COMMN_ADDRESSLINE2', 'COMMN_ADDRESSLINE3','COMMN_CITY','COMMN_STATE','COMMN_POSTALCODE','COMMN_BeneficiaryAddress','COMMN_BeneficiaryCity'];
                            doPropsAction(mandateProps, "Non_Mandate");
                        }

                    }

                    if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE" || self.pg_role == "PENDING REALISATION" || self.pg_role == "ACCEPTANCE FIN AUTH" || self.pg_role == "FIN AUTH") {
                        if (billPayable == 'Usance') {
                            var enableProps = ['COMMN_DueDate'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(enableProps, "Mandate");
                        } else {
                            var enableProps = ['COMMN_DueDate'];
                            doPropsAction(enableProps, "disable");
                            doPropsAction(enableProps, "Non_Mandate");
                        }
                    }

                }

                if (self.pg_role == "SOL MAKER" || self.pg_role == "DTFC OCR" || self.pg_role == "BRANCH HOLD") {
                    if (propId == "F_CaseFolder.COMMN_SanctionLetter") {
                        var sanctionLetter = self.propValue;
                        if (sanctionLetter == 'Y') {
                            if (!(self.pg_role == "BRANCH HOLD")) {
                                doPropsAction(['COMMN_SanctionCharges'], "enable");
                                doPropsAction(['COMMN_SanctionCharges'], "Mandate");
                            }
                            var mandateProps = ['COMMN_SanctionLetterAttached'];
                            doPropsAction(mandateProps, "Mandate");
                            if (self.pg_role == "SOL MAKER") {
                                customPopUpViewer("Please attach sanction letter");
                            }
                        } else {
                            if (!(self.pg_role == "BRANCH HOLD")) {
                                doPropsAction(['COMMN_SanctionCharges'], "disable");
                                doPropsAction(['COMMN_SanctionCharges'], "Non_Mandate");
                            }
                            var mandateProps = ['COMMN_SanctionLetterAttached'];
                            doPropsAction(mandateProps, "Non_Mandate");
                        }
                    }
                }
                if (self.pg_role == "SOL CHECKER") {
                    if (propId == "F_CaseFolder.COMMN_SanctionLetter") {
                        var sanctionLetter = self.propValue;
                        if (sanctionLetter == 'Y') {
                            customPopUpViewer("Please attach sanction letter");
                        }

                    }
                }


                if (self.pg_role == "SOL MAKER" || self.pg_role == "DTFC COMP") {
                    if (propId == "F_CaseFolder.COMMN_DocumentReceivedDate") {
                        var docReceiveDate = self.propValue;
                        var currentDate = new Date();
                        var AddDay = 5;
                        console.log("AddDay", AddDay);
                        var Day = new Date(docReceiveDate);
                        console.log("Day", Day);
                        var currentDay = currentDate.setDate(currentDate.getDate() + AddDay);
                        console.log("currentDay", currentDay);
                        if (Day > currentDay) {
                            customPopUpViewer("WID creation date is post Document received date and 5 working days, please check");
                        }
                    }
                }
                if ((self.pg_role == "DTFC OCR" || self.pg_role == "DTFC COMP") && (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED')) {
                    if (propId == "F_CaseFolder.COMMN_UsanceDays" || propId == "F_CaseFolder.COMMN_DraftAmount") {
                        if (propId == "F_CaseFolder.COMMN_UsanceDays") {
                            var usanceDays = self.propValue;
                            var draftAmt = getPropValue('COMMN_DraftAmount');
                        }
                        if (propId == "F_CaseFolder.COMMN_DraftAmount") {
                            var draftAmt = self.propValue;
                            var usanceDays = getPropValue('COMMN_UsanceDays');
                        }

                        if (usanceDays > 90) {
                            var enableProps = ['COMMN_StampDutyApplicable', 'COMMN_StampDutyAmount', 'COMMN_StampDutyPaid'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(enableProps, "Mandate");
                        } else {
                            var enableProps = ['COMMN_StampDutyApplicable', 'COMMN_StampDutyAmount', 'COMMN_StampDutyPaid'];
                            doPropsAction(enableProps, "disable");
                            doPropsAction(enableProps, "Non_Mandate");
                        }
                        if (usanceDays > 90 && usanceDays < 180) {
                            stampDutyAmt = (draftAmt * 0.00024);
                            console.log("stampDutyAmt", stampDutyAmt);
                            setPropValue("COMMN_StampDutyAmount", stampDutyAmt.toFixed(2));
                        }
                        if (usanceDays > 180 && usanceDays <= 270) {
                            stampDutyAmt = (draftAmt * 0.00036);
                            console.log("stampDutyAmt", stampDutyAmt);
                            setPropValue("COMMN_StampDutyAmount", stampDutyAmt.toFixed(2));
                        }
                        if (usanceDays > 270 && usanceDays < 365) {
                            stampDutyAmt = (draftAmt * 0.00050);
                            console.log("stampDutyAmt", stampDutyAmt);
                            setPropValue("COMMN_StampDutyAmount", stampDutyAmt.toFixed(2));
                        }
                        if (usanceDays > 365) {
                            stampDutyAmt = (draftAmt * 0.00010);
                            console.log("stampDutyAmt", stampDutyAmt);
                            setPropValue("COMMN_StampDutyAmount", stampDutyAmt.toFixed(2));
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_DocumentaryCreditNoonBOE" || propId == "F_CaseFolder.COMMN_DocumentaryCreditNoonBankCoverLetter") {
                    if (propId == "F_CaseFolder.COMMN_DocumentaryCreditNoonBOE") {
                        var docCreditNumonBOE = self.propValue;
                        var docCreditNoonBankCoverLetter = getPropValue('COMMN_DocumentaryCreditNoonBankCoverLetter');
                    }
                    if (propId == "F_CaseFolder.COMMN_DocumentaryCreditNoonBankCoverLetter") {
                        var docCreditNoonBankCoverLetter = self.propValue;
                        var docCreditNumonBOE = getPropValue('COMMN_DocumentaryCreditNoonBOE');
                    }
                    if (docCreditNumonBOE != null && docCreditNoonBankCoverLetter != null) {
                        if (docCreditNumonBOE != docCreditNoonBankCoverLetter) {
                            customPopUpViewer("Value in this field to matched with value in the field - DC no on bank cover letter, please check");
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_UsanceDays" || propId == "F_CaseFolder.COMMN_DraftDate" || propId == "F_CaseFolder.COMMN_LRGRBOLDate" || propId == "F_CaseFolder.COMMN_InvoiceDate" || propId == "F_CaseFolder.COMMN_LCOpenDate" || propId == "F_CaseFolder.COMMN_AcceptanceDate" || propId == "F_CaseFolder.COMMN_TenorFrom") {
                    if (propId == "F_CaseFolder.COMMN_TenorFrom") {
                        var tenorFrom = self.propValue;
                        var usance = getPropValue('COMMN_UsanceDays');
                        console.log("usanceDays", usance);
                        var draftDate = getPropValue('COMMN_DraftDate');
                        var lrgrbolDate = getPropValue('COMMN_LRGRBOLDate');
                        var invoiceDate = getPropValue('COMMN_InvoiceDate');
                        var lcDate = getPropValue('COMMN_LCOpenDate');
                        var acceptanceDate = getPropValue('COMMN_AcceptanceDate');
                    }
                    if (propId == "F_CaseFolder.COMMN_UsanceDays") {
                        var usance = self.propValue;
                        console.log("usanceDays", usance);
                        var draftDate = getPropValue('COMMN_DraftDate');
                        var lrgrbolDate = getPropValue('COMMN_LRGRBOLDate');
                        var invoiceDate = getPropValue('COMMN_InvoiceDate');
                        var lcDate = getPropValue('COMMN_LCOpenDate');
                        var acceptanceDate = getPropValue('COMMN_AcceptanceDate');
                        var tenorFrom = getPropValue('COMMN_TenorFrom');
                    }
                    if (propId == "F_CaseFolder.COMMN_DraftDate") {
                        var draftDate = self.propValue;
                        var usance = getPropValue('COMMN_UsanceDays');
                        console.log("usanceDays", usance);
                        var lrgrbolDate = getPropValue('COMMN_LRGRBOLDate');
                        var invoiceDate = getPropValue('COMMN_InvoiceDate');
                        var lcDate = getPropValue('COMMN_LCOpenDate');
                        var acceptanceDate = getPropValue('COMMN_AcceptanceDate');
                        var tenorFrom = getPropValue('COMMN_TenorFrom');
                    }
                    if (propId == "F_CaseFolder.COMMN_LRGRBOLDate") {
                        var lrgrbolDate = self.propValue;
                        var usance = getPropValue('COMMN_UsanceDays');
                        console.log("usanceDays", usance);
                        var draftDate = getPropValue('COMMN_DraftDate');
                        var invoiceDate = getPropValue('COMMN_InvoiceDate');
                        var lcDate = getPropValue('COMMN_LCOpenDate');
                        var acceptanceDate = getPropValue('COMMN_AcceptanceDate');
                        var tenorFrom = getPropValue('COMMN_TenorFrom');
                    }
                    if (propId == "F_CaseFolder.COMMN_InvoiceDate") {
                        var invoiceDate = self.propValue;
                        var usance = getPropValue('COMMN_UsanceDays');
                        console.log("usanceDays", usance);
                        var draftDate = getPropValue('COMMN_DraftDate');
                        var lrgrbolDate = getPropValue('COMMN_LRGRBOLDate');
                        var lcDate = getPropValue('COMMN_LCOpenDate');
                        var acceptanceDate = getPropValue('COMMN_AcceptanceDate');
                        var tenorFrom = getPropValue('COMMN_TenorFrom');
                    }
                    if (propId == "F_CaseFolder.COMMN_LCOpenDate") {
                        var lcDate = self.propValue;
                        var usance = getPropValue('COMMN_UsanceDays');
                        console.log("usanceDays", usance);
                        var draftDate = getPropValue('COMMN_DraftDate');
                        var lrgrbolDate = getPropValue('COMMN_LRGRBOLDate');
                        var invoiceDate = getPropValue('COMMN_InvoiceDate');
                        var acceptanceDate = getPropValue('COMMN_AcceptanceDate');
                        var tenorFrom = getPropValue('COMMN_TenorFrom');
                    }
                    if (propId == "F_CaseFolder.COMMN_AcceptanceDate") {
                        var acceptanceDate = self.propValue;
                        var usance = getPropValue('COMMN_UsanceDays');
                        console.log("usanceDays", usance);
                        var draftDate = getPropValue('COMMN_DraftDate');
                        var lrgrbolDate = getPropValue('COMMN_LRGRBOLDate');
                        var invoiceDate = getPropValue('COMMN_InvoiceDate');
                        var lcDate = getPropValue('COMMN_LCOpenDate');
                        var tenorFrom = getPropValue('COMMN_TenorFrom');
                    }

                    if (tenorFrom == 'BOE Date' && (usance != null || usance != undefined) && (draftDate != null || draftDate != undefined)) {
                        var usanceDays = parseInt(usance);
                        var boeDate = new Date(draftDate);
                        boeDate.setDate(boeDate.getDate() + usanceDays);
                        console.log("boeDate::reshma:", boeDate);
                        var dueDate = boeDate;
                        console.log("dueDate", dueDate);
                        setPropValue("COMMN_DueDate", dueDate);
                    }
                    if (tenorFrom == 'LC Date' && (usance != null || usance != undefined) && (lcDate != null || lcDate != undefined)) {
                        var usanceDays = parseInt(usance);
                        var lcDate = new Date(lcDate);
                        lcDate.setDate(lcDate.getDate() + usanceDays);
                        console.log("lcDate::reshma:", lcDate);
                        var dueDate = lcDate;
                        console.log("dueDate", dueDate);
                        setPropValue("COMMN_DueDate", dueDate);
                    }
                    if (tenorFrom == 'INVOICE Date' && (usance != null || usance != undefined) && (invoiceDate != null || invoiceDate != undefined)) {
                        var usanceDays = parseInt(usance);
                        var invoiceDate = new Date(invoiceDate);
                        invoiceDate.setDate(invoiceDate.getDate() + usanceDays);
                        console.log("invoiceDate::reshma:", invoiceDate);
                        var dueDate = invoiceDate;
                        console.log("dueDate", dueDate);
                        setPropValue("COMMN_DueDate", dueDate);
                    }
                    if (tenorFrom == 'Acceptance Date' && (usance != null || usance != undefined) && (acceptanceDate != null || acceptanceDate != undefined)) {
                        var usanceDays = parseInt(usance);
                        var acceptanceDate = new Date(acceptanceDate);
                        acceptanceDate.setDate(acceptanceDate.getDate() + usanceDays);
                        console.log("acceptanceDate::reshma:", acceptanceDate);
                        var dueDate = acceptanceDate;
                        console.log("dueDate", dueDate);
                        setPropValue("COMMN_DueDate", dueDate);
                    }
                    if (tenorFrom == 'LR Date' && (usance != null || usance != undefined) && (lrgrbolDate != null || lrgrbolDate != undefined)) {
                        var usanceDays = parseInt(usance);
                        var lrgrbolDate = new Date(lrgrbolDate);
                        lrgrbolDate.setDate(lrgrbolDate.getDate() + usanceDays);
                        console.log("lrgrbolDate::reshma:", lrgrbolDate);
                        var dueDate = lrgrbolDate;
                        console.log("dueDate", dueDate);
                        setPropValue("COMMN_DueDate", dueDate);
                    }
                }

                if (self.pg_role == "DTFC COMP" || self.pg_role == "FIN AUTH") {
                    if (propId == "F_CaseFolder.COMMN_BankCoverLetterDate" || propId == "F_CaseFolder.COMMN_LCExpiryDate") {
                        if (propId == "F_CaseFolder.COMMN_BankCoverLetterDate") {
                            var bankCoverLetterDate = self.propValue;
                            var lcExpiryDate = getPropValue('COMMN_LCExpiryDate');
                        } else if (propId == "F_CaseFolder.COMMN_LCExpiryDate") {
                            var lcExpiryDate = self.propValue;
                            var bankCoverLetterDate = getPropValue('COMMN_BankCoverLetterDate');
                        }
                        if (lcExpiryDate != null && bankCoverLetterDate != null) {
                            if (bankCoverLetterDate > lcExpiryDate) {
                                customPopUpViewer("Bank cover letter date is post the date of LC expiry date, please check");
                            }
                        }

                    }

                    if (propId == "F_CaseFolder.COMMN_ApplicantNameonInvoice" || propId == "F_CaseFolder.COMMN_OperativeAccountName") {
                        if (propId == "F_CaseFolder.COMMN_ApplicantNameonInvoice") {
                            var applicantNameonInvoice = self.propValue;
                            var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                            var operativeAcctName = getPropValue('COMMN_OperativeAccountName');
                        }
                        if (propId == "F_CaseFolder.COMMN_OperativeAccountName") {
                            var operativeAcctName = self.propValue;
                            var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                            var applicantNameonInvoice = getPropValue('COMMN_ApplicantNameonInvoice');
                        }
                        if (applicantNameonInvoice != null && operativeAcctName != null) {
                            if (collectionOnBill == 'Non LC' && (applicantNameonInvoice != operativeAcctName)) {
                                customPopUpViewer("Applicant Name on Invoice and Operative Account Name should be same, please check");
                            }
                        }

                    }

                }
                if (self.pg_role == "DTFC COMP") {
                    if (propId == "F_CaseFolder.COMMN_LcAvailableValue" || propId == "F_CaseFolder.COMMN_DCUtilizationAmount") {
                        if (propId == "F_CaseFolder.COMMN_LcAvailableValue") {
                            var lcAvailableVal = self.propValue;
                            var lcAvailableValue = parseFloat(lcAvailableVal);
                            var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                            var dcUtilizationAmount = parseFloat(dcUtilizationAmt);
                        }
                        if (propId == "F_CaseFolder.COMMN_DCUtilizationAmount") {
                            var dcUtilizationAmt = self.propValue;
                            var dcUtilizationAmount = parseFloat(dcUtilizationAmt);
                            var lcAvailableVal = getPropValue('COMMN_LcAvailableValue');
                            var lcAvailableValue = parseFloat(lcAvailableVal);
                        }
                        if (dcUtilizationAmount != null && lcAvailableValue != null) {
                            if (dcUtilizationAmount > lcAvailableValue) {
                                customPopUpViewer("Value in this field is lesser than DC utilization amt, please check");
                            }
                        }
                    }
                    if (propId == "F_CaseFolder.COMMN_StampDutyPaid" || propId == "F_CaseFolder.COMMN_StampDutyAmount") {
                        if (propId == "F_CaseFolder.COMMN_StampDutyPaid") {
                            var stampDutyPaidValue = self.propValue;
                            var stampDutyAmtValue = getPropValue('COMMN_StampDutyAmount');
							var stampDutyPaid = parseFloat(stampDutyPaidValue);
							var stampDutyAmt = parseFloat(stampDutyAmtValue);
                        }
                        if (propId == "F_CaseFolder.COMMN_StampDutyAmount") {
                            var stampDutyAmtValue = self.propValue;
                            var stampDutyPaidValue = getPropValue('COMMN_StampDutyPaid');
							var stampDutyPaid = parseFloat(stampDutyPaidValue);
							var stampDutyAmt = parseFloat(stampDutyAmtValue);
                        }
                        
                        if (stampDutyPaid != null && stampDutyPaid != undefined && stampDutyAmt != null && stampDutyAmt != undefined) {
                            if (stampDutyPaid < stampDutyAmt) {
                                customPopUpViewer("Stamp Duty paid is less than stamp duty amt, please check");
                            }
                        }
                    }
                }

                if (self.pg_role == "RTGS AUTH") {
                    var subOperation = getPropValue("COMMN_SubOperation");
                    if ((operation == 'LODGEMENT' && subOperation == 'REALIZATION') || operation == 'PRE-ACCEPTED') {
                        if (propId == "F_CaseFolder.COMMN_DeferralPending") {
                            var deferralPending = self.propValue;
                            if (deferralPending == 'Yes') {
                                var mandateProps = ['COMMN_DTFCDEEFERALREASON'];
                                doPropsAction(mandateProps, "Mandate");
                            } else {
                                var mandateProps = ['COMMN_DTFCDEEFERALREASON'];
                                doPropsAction(mandateProps, "Non_Mandate");
                            }
                        }
                    }
                }

                if (self.pg_role == "BR ACCEPT MAKER" || self.pg_role == "DTFC HOLD") {
                    if (propId == "F_CaseFolder.COMMN_DTFCHoldBranchdecision" || propId == "F_CaseFolder.COMMN_SubOperation") {
                        if (propId == "F_CaseFolder.COMMN_DTFCHoldBranchdecision") {
                            var branchDecision = self.propValue;
                            var subOperation = getPropValue('COMMN_SubOperation');
                        }
                        if (propId == "F_CaseFolder.COMMN_SubOperation") {
                            var subOperation = self.propValue;
                            var branchDecision = getPropValue('COMMN_DTFCHoldBranchdecision');
                        }
                        if (branchDecision == 'Return Document' || subOperation == 'DISHONOR') {
                            var enableProps = ['COMMN_CourierNo', 'COMMN_CourierCoName', 'COMMN_DateofReturn'];
                            doPropsAction(enableProps, "enable");
                        } else {
                            var enableProps = ['COMMN_CourierNo', 'COMMN_CourierCoName', 'COMMN_DateofReturn'];
                            doPropsAction(enableProps, "disable");
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_InterestApplicable") {
                    var interestApplicable = self.propValue;
                    if (interestApplicable == 'Yes') {
                        var enableProps = ['COMMN_InterestRate', 'COMMN_GrossInterestAmount', 'COMMN_TDSApplicable', 'COMMN_TDSAmount', 'COMMN_GSTApplicable', 'COMMN_GSTAmount', 'COMMN_NetInterestAmount'];
                        doPropsAction(enableProps, "enable");
                        doPropsAction(enableProps, "Mandate");
                    } else {
                        var enableProps = ['COMMN_InterestRate', 'COMMN_GrossInterestAmount', 'COMMN_TDSApplicable', 'COMMN_TDSAmount', 'COMMN_GSTApplicable', 'COMMN_GSTAmount', 'COMMN_NetInterestAmount'];
                        doPropsAction(enableProps, "disable");
                        doPropsAction(enableProps, "Non_Mandate");
                    }
                }

                if (propId == "F_CaseFolder.COMMN_LRGRBOLDate" || propId == "F_CaseFolder.COMMN_LCOpenDate" || propId == "F_CaseFolder.COMMN_LatestShipmentDate") {
                    if (propId == "F_CaseFolder.COMMN_LRGRBOLDate") {
                        var lrgrbolDate = self.propValue;
                        var latestShipmentDate = getPropValue('COMMN_LatestShipmentDate');
                        var lcOpenDate = getPropValue('COMMN_LCOpenDate');
                    }
                    if (propId == "F_CaseFolder.COMMN_LCOpenDate") {
                        var lcOpenDate = self.propValue;
                        var latestShipmentDate = getPropValue('COMMN_LatestShipmentDate');
                        var lrgrbolDate = getPropValue('COMMN_LRGRBOLDate');
                    }
                    if (propId == "F_CaseFolder.COMMN_LatestShipmentDate") {
                        var latestShipmentDate = self.propValue;
                        var lrgrbolDate = getPropValue('COMMN_LRGRBOLDate');
                        var lcOpenDate = getPropValue('COMMN_LCOpenDate');
                    }
                    if (lrgrbolDate != null && latestShipmentDate != null) {
                        if (lrgrbolDate > latestShipmentDate) {
                            customPopUpViewer("lr/gr/bol date is post the date of latest shipment date ,please check");
                        }
                    }
                    if (lrgrbolDate != null && lcOpenDate != null) {
                        if (lrgrbolDate < lcOpenDate) {
                            customPopUpViewer("LR/GR/BOL Date is prior to LC open date, please check");
                        }
                    }
                }

                if (propId == "F_CaseFolder.COMMN_ApplicantNameinLC" || propId == "F_CaseFolder.COMMN_ApplicantNameonInvoice" || propId == "F_CaseFolder.COMMN_CustomerName") {
                    if (propId == "F_CaseFolder.COMMN_ApplicantNameinLC") {
                        var apllicantNameinLC = self.propValue;
                        var applicantNameonInvoice = getPropValue('COMMN_ApplicantNameonInvoice');
                        var customerName = getPropValue('COMMN_CustomerName');
                    }
                    if (propId == "F_CaseFolder.COMMN_ApplicantNameonInvoice") {
                        var applicantNameonInvoice = self.propValue;
                        var apllicantNameinLC = getPropValue('COMMN_ApplicantNameinLC');
                    }
                    if (propId == "F_CaseFolder.COMMN_CustomerName") {
                        var customerName = self.propValue;
                        var apllicantNameinLC = getPropValue('COMMN_ApplicantNameinLC');
                    }
                    if (apllicantNameinLC != null && applicantNameonInvoice != null) {
                        if (apllicantNameinLC != applicantNameonInvoice) {
                            customPopUpViewer("Value entered does not match with the Applicant Name on invoice, please check");
                        }
                    }
                    if (apllicantNameinLC != null && customerName != null) {
                        if (apllicantNameinLC != customerName) {
                            customPopUpViewer("Value entered does not match with the Customer Name, please check");
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_LCOpenDate" || propId == "F_CaseFolder.COMMN_DraftDate") {
                    if (propId == "F_CaseFolder.COMMN_LCOpenDate") {
                        var lcOpenDate = self.propValue;
                        var draftDate = getPropValue('COMMN_DraftDate');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                    }
                    if (propId == "F_CaseFolder.COMMN_DraftDate") {
                        var draftDate = self.propValue;
                        var lcOpenDate = getPropValue('COMMN_LCOpenDate');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                    }
                    if (draftDate != null && lcOpenDate != null) {
                        if (draftDate < lcOpenDate) {
                            customPopUpViewer(" Draft date is prior to LC open date, please check");
                        }
                    }
                }

                if (propId == "F_CaseFolder.COMMN_DraftAmount" || propId == "F_CaseFolder.COMMN_LcAvailableValue") {
                    if (propId == "F_CaseFolder.COMMN_DraftAmount") {
                        var draftAmt = self.propValue;
                        var draftAmount = parseFloat(draftAmt);
                        var lcAvailableVal = getPropValue('COMMN_LcAvailableValue');
                        var lcAvailableValue = parseFloat(lcAvailableVal);
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                    }
                    if (propId == "F_CaseFolder.COMMN_LcAvailableValue") {
                        var lcAvailableVal = self.propValue;
                        var lcAvailableValue = parseFloat(lcAvailableVal);
                        var draftAmt = getPropValue('COMMN_DraftAmount');
                        var draftAmount = parseFloat(draftAmt);
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                    }
                    if (draftAmount != null && lcAvailableValue != null) {
                        if (collectionOnBill == 'Backed by LC' && (draftAmount > lcAvailableValue)) {
                            customPopUpViewer("The Draft Amount is greater than the field LC Available Value, please check");
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_BeneficiaryNameonInvoice" || propId == "F_CaseFolder.COMMN_BeneficiaryNameinLC") {
                    if (propId == "F_CaseFolder.COMMN_BeneficiaryNameonInvoice") {
                        var beneficiaryNameonInvoice = self.propValue;
                        var beneficiaryNameinLC = getPropValue('COMMN_BeneficiaryNameinLC');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                    }
                    if (propId == "F_CaseFolder.COMMN_BeneficiaryNameinLC") {
                        var beneficiaryNameinLC = self.propValue;
                        var beneficiaryNameonInvoice = getPropValue('COMMN_BeneficiaryNameonInvoice');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                    }
                    if (beneficiaryNameinLC != null && beneficiaryNameonInvoice != null) {
                        if (collectionOnBill == 'Backed by LC' && (beneficiaryNameinLC != beneficiaryNameonInvoice)) {
                            customPopUpViewer("Beneficiary name in LC does not match with the beneficiary name on invoice, please check");
                        }
                    }

                }
                if (propId == "F_CaseFolder.COMMN_OperativeAcNoofLC" || propId == "F_CaseFolder.COMMN_OperativeAccountNo") {
                    if (propId == "F_CaseFolder.COMMN_OperativeAcNoofLC") {
                        var operativeAcNoofLC = self.propValue;
                        var OperativeAcctNo = getPropValue('COMMN_OperativeAccountNo');
                    }
                    if (propId == "F_CaseFolder.COMMN_OperativeAccountNo") {
                        var OperativeAcctNo = self.propValue;
                        var operativeAcNoofLC = getPropValue('COMMN_OperativeAcNoofLC');
                    }
                    if (operativeAcNoofLC != null && OperativeAcctNo != null) {
                        if (operativeAcNoofLC != OperativeAcctNo) {
                            customPopUpViewer("Value entered does not match with Operative Account Number, Please check");
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_ChargeCollection") {
                    var chargeCollection = self.propValue;


                    if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE" || self.pg_role == "PENDING REALISATION" || self.pg_role == "DTFC OCR") {

                        if (chargeCollection == 'Yes') {
                            var enableProps = ['COMMN_ChargeEventId', 'COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges'];

                            var mandateProps = ['COMMN_ChargeEventId', 'COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges'];

                            doPropsAction(enableProps, "enable");
                            doPropsAction(mandateProps, "Mandate");
                        } else {
                            var enableProps = ['COMMN_ChargeEventId', 'COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges'];
                            doPropsAction(enableProps, "disable");

                            var mandateProps = ['COMMN_ChargeEventId', 'COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges'];
                            doPropsAction(mandateProps, "Non_Mandate");
                        }

                        if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR' || subOperation == 'REALIZATION' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {

                            if (chargeCollection == 'Yes') {
                                var enableProps = ['COMMN_DiscrepancyGST'];
                                var mandateProps = ['COMMN_DiscrepancyGST'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            } else {
                                var enableProps = ['COMMN_DiscrepancyGST'];
                                doPropsAction(enableProps, "disable");

                                var mandateProps = ['COMMN_DiscrepancyGST'];
                                doPropsAction(mandateProps, "Non_Mandate");
                            }
                        }
                    }
                }

                if (propId == "F_CaseFolder.COMMN_CBOInstruction") {
					var subOperation = getPropValue('COMMN_SubOperation');
                    var cboInstruction = self.propValue;
                    if (cboInstruction == 'OPEN DEVOLVMENT ACCOUNT' || cboInstruction == 'EXISTING DEVOLVMENT ACCOUNT' || cboInstruction == 'PAYMENT VIA TOD IN OPERATIVE ACCOUNT') {
                        setPropValue("COMMN_PaymentthroughTODInvocation", 'Yes');
                    } else {
                        setPropValue("COMMN_PaymentthroughTODInvocation", 'No');
                    }

                    if ((operation == 'LODGEMENT' && subOperation == 'REALIZATION') || operation == 'PRE-ACCEPTED') {
                        if (cboInstruction == 'EXISTING DEVOLVMENT ACCOUNT') {
                            var enableProps = ['COMMN_ExistingAccountNo', 'COMMN_ExisitingDevolvmentAccountName'];
                            doPropsAction(enableProps, "enable");
                        } else {
                            var enableProps = ['COMMN_ExistingAccountNo', 'COMMN_ExisitingDevolvmentAccountName'];
                            doPropsAction(enableProps, "disable");
                        }
						
						if (self.pg_role == "PENDING REALISATION" || self.pg_role == "REALISATION FIN AUTH" || self.pg_role == "REALISATION FIN ENTRY") {
							
							if (cboInstruction == 'OPEN DEVOLVMENT ACCOUNT') {
								var enableProps = ['COMMN_CMEFlag','COMMN_NewDevolvementAccountNo'];
								var mandateProps = ['COMMN_CMEFlag'];
								
								doPropsAction(enableProps, "enable");
								doPropsAction(mandateProps, "Mandate");
							}else {
								var enableProps = ['COMMN_CMEFlag','COMMN_NewDevolvementAccountNo'];
								var mandateProps = ['COMMN_CMEFlag'];
								
								doPropsAction(enableProps, "disable");
								doPropsAction(mandateProps, "Non_Mandate");
							}
						}

                        if (cboInstruction == 'OPEN DEVOLVMENT ACCOUNT') {
                            var enableProps = ['COMMN_RefAccountNo', 'COMMN_SanctionLimit', 'COMMN_LimitId', 'COMMN_LimitIdSuffix', 'COMMN_InterestRateCode', 'COMMN_AcctLabel', 'COMMN_SectorCode', 'COMMN_SubSectorCode', 'COMMN_OccupationCode', 'COMMN_PurposeofAdvance', 'COMMN_ModeofAdvance', 'COMMN_TypeofAdvance', 'COMMN_NatureofAdvance', 'COMMN_GuaranteeCoverCode', 'COMMN_IndustryType', 'COMMN_LedgerNo', 'COMMN_ModeofOperation', 'COMMN_SanctionDate', 'COMMN_ExpiryDate', 'COMMN_CBO_DocumentDate', 'COMMN_ReviewDate', 'COMMN_SactionLevel', 'COMMN_SanctionAuthority', 'COMMN_LimitRefNo', 'COMMN_DrawingPowerInd', 'COMMN_DrawingPower', 'COMMN_BorrowerCategory', 'COMMN_AcctPrefIntDr', 'COMMN_IntDrAcFlag', 'COMMN_CMEFlag'];

                            var mandateProps = ['COMMN_RefAccountNo', 'COMMN_SanctionLimit', 'COMMN_LimitId', 'COMMN_LimitIdSuffix', 'COMMN_InterestRateCode', 'COMMN_AcctLabel', 'COMMN_SectorCode', 'COMMN_SubSectorCode', 'COMMN_OccupationCode', 'COMMN_PurposeofAdvance', 'COMMN_ModeofAdvance', 'COMMN_TypeofAdvance', 'COMMN_NatureofAdvance', 'COMMN_GuaranteeCoverCode', 'COMMN_IndustryType', 'COMMN_LedgerNo', 'COMMN_ModeofOperation', 'COMMN_SanctionDate', 'COMMN_ExpiryDate', 'COMMN_CBO_DocumentDate', 'COMMN_ReviewDate', 'COMMN_SactionLevel', 'COMMN_SanctionAuthority', 'COMMN_LimitRefNo', 'COMMN_DrawingPowerInd', 'COMMN_DrawingPower', 'COMMN_BorrowerCategory', 'COMMN_AcctPrefIntDr', 'COMMN_IntDrAcFlag', 'COMMN_CMEFlag'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(mandateProps, "Mandate");
                        } else {
                            var enableProps = ['COMMN_RefAccountNo', 'COMMN_SanctionLimit', 'COMMN_LimitId', 'COMMN_LimitIdSuffix', 'COMMN_InterestRateCode', 'COMMN_AcctLabel', 'COMMN_SectorCode', 'COMMN_SubSectorCode', 'COMMN_OccupationCode', 'COMMN_PurposeofAdvance', 'COMMN_ModeofAdvance', 'COMMN_TypeofAdvance', 'COMMN_NatureofAdvance', 'COMMN_GuaranteeCoverCode', 'COMMN_IndustryType', 'COMMN_LedgerNo', 'COMMN_ModeofOperation', 'COMMN_SanctionDate', 'COMMN_ExpiryDate', 'COMMN_CBO_DocumentDate', 'COMMN_ReviewDate', 'COMMN_SactionLevel', 'COMMN_SanctionAuthority', 'COMMN_LimitRefNo', 'COMMN_DrawingPowerInd', 'COMMN_DrawingPower', 'COMMN_BorrowerCategory', 'COMMN_AcctPrefIntDr', 'COMMN_IntDrAcFlag', 'COMMN_CMEFlag'];

                            var mandateProps = ['COMMN_RefAccountNo', 'COMMN_SanctionLimit', 'COMMN_LimitId', 'COMMN_LimitIdSuffix', 'COMMN_InterestRateCode', 'COMMN_AcctLabel', 'COMMN_SectorCode', 'COMMN_SubSectorCode', 'COMMN_OccupationCode', 'COMMN_PurposeofAdvance', 'COMMN_ModeofAdvance', 'COMMN_TypeofAdvance', 'COMMN_NatureofAdvance', 'COMMN_GuaranteeCoverCode', 'COMMN_IndustryType', 'COMMN_LedgerNo', 'COMMN_ModeofOperation', 'COMMN_SanctionDate', 'COMMN_ExpiryDate', 'COMMN_CBO_DocumentDate', 'COMMN_ReviewDate', 'COMMN_SactionLevel', 'COMMN_SanctionAuthority', 'COMMN_LimitRefNo', 'COMMN_DrawingPowerInd', 'COMMN_DrawingPower', 'COMMN_BorrowerCategory', 'COMMN_AcctPrefIntDr', 'COMMN_IntDrAcFlag', 'COMMN_CMEFlag'];

                            doPropsAction(enableProps, "disable");
                            doPropsAction(mandateProps, "Non_Mandate");
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_AccountHolderName" || propId == "F_CaseFolder.COMMN_ApplicantNameonInvoice") {
                    if (propId == "F_CaseFolder.COMMN_AccountHolderName") {
                        var accountHolderName = self.propValue;
                        var applicantNameonInvoice = getPropValue('COMMN_ApplicantNameonInvoice');
                    }
                    if (propId == "F_CaseFolder.COMMN_ApplicantNameonInvoice") {
                        var applicantNameonInvoice = self.propValue;
                        var accountHolderName = getPropValue('COMMN_AccountHolderName');
                    }
                    if (accountHolderName != null && applicantNameonInvoice != null) {
                        if (accountHolderName != applicantNameonInvoice) {
                            customPopUpViewer("Value entered does not match with the Applicant name on invoice, please check");
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_TotalClaimedAmount" || propId == "F_CaseFolder.COMMN_OurBankCharges") {
                    if (propId == "F_CaseFolder.COMMN_TotalClaimedAmount") {
                        var totalClaimedAmont = self.propValue;
                        var ourBankCharges = getPropValue('COMMN_OurBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_OurBankCharges") {
                        var ourBankCharges = self.propValue;
                        var totalClaimedAmont = getPropValue('COMMN_TotalClaimedAmount');
                    }
                    if (totalClaimedAmont != null && ourBankCharges != null) {
                        var amount = (parseFloat(totalClaimedAmont) - parseFloat(ourBankCharges));
                        setPropValue("COMMN_AcceptedAmount", amount.toFixed(2));
                    }
                }
                if (propId == "F_CaseFolder.COMMN_SFMSRequired") {
                    var sfmsRequired = self.propValue;
                    if (sfmsRequired == 'Yes') {
                        var enableProps = ['COMMN_MessageType'];
                        doPropsAction(enableProps, "enable");
                        doPropsAction(enableProps, "Mandate");
                    } else {
                        var enableProps = ['COMMN_MessageType'];
                        doPropsAction(enableProps, "disable");
                        doPropsAction(enableProps, "Non_Mandate");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_DiscrepancyStatus") {
                    var discrepancyStatus = self.propValue;
                    var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                    if (discrepancyStatus == 'Rejection MT 499' && collectionOnBill != 'Non LC') {
                        customPopUpViewer("Collection on bill value should be Non LC");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_MessageType") {
                    var messageType = self.propValue;
					var subOperation = getPropValue("COMMN_SubOperation");
					
                    if (messageType == 'REJECTION 734') {
                        var enableProps = ['COMMN_DisposalofDocuments'];
                        doPropsAction(enableProps, "enable");
                        doPropsAction(enableProps, "Mandate");
                    } else if (messageType != 'REJECTION 734') {
                        var disableProps = ['COMMN_DisposalofDocuments'];
                        doPropsAction(disableProps, "disable");
                        doPropsAction(disableProps, "Non_Mandate");
                    }

                    if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE" || self.pg_role == "DTFC OCR" || self.pg_role == "FIN ENTRY" || self.pg_role == "ACCEPTANCE XMM ENTRY/MOD") {

                        if ((operation == "LODGEMENT" || operation == "ROLLOVER") && (!(self.pg_role == "FIN ENTRY" || self.pg_role == "ACCEPTANCE XMM ENTRY/MOD"))) {
                            if (messageType != '412') {
                                var enableProps = ['COMMN_EntityType'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            } else {
                                var disableProps = ['COMMN_EntityType'];
                                doPropsAction(disableProps, "disable");
                                doPropsAction(disableProps, "Non_Mandate");
                            }
                        }
                        if (operation == "LODGEMENT" || operation == "MISCELLANEOUS") {
                            if (messageType != '412') {
                                var enableProps = ['COMMN_EntityId'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            } else {
                                var disableProps = ['COMMN_EntityId'];
                                doPropsAction(disableProps, "disable");
                                doPropsAction(disableProps, "Non_Mandate");
                            }
                        }
                    }


                    if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {
                        if (messageType == '754') {
                            var enableProps = ['COMMN_AcceptanceDate'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(enableProps, "Mandate");

                        } else {
                            var enableProps = ['COMMN_AcceptanceDate'];
                            doPropsAction(enableProps, "disable");
                            doPropsAction(enableProps, "Non_Mandate");
                        }
                    }

					if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR')) || operation == 'PRE-ACCEPTED' || operation == 'MISCELLANEOUS' || operation == 'ROLLOVER') {
                            var sfmsRequired = getPropValue("COMMN_SFMSRequired");
							if (msgTypeValue != '412' && sfmsRequired == 'Yes') {
                                var enableProps = ['COMMN_Narrative'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            } else {
								var enableProps = ['COMMN_Narrative'];
								doPropsAction(enableProps, "disable");
								doPropsAction(enableProps, "Non_Mandate");
							}
                        }
					
                    if ((operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') || operation == 'PRE-ACCEPTED') {
                        if (messageType == '754') {
                            var enableProps = ['COMMN_SFMSFlag', 'COMMN_DocumentType', 'COMMN_DocumentNo', 'COMMN_DocumentDate'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(enableProps, "Mandate");
                        } else {
                            var enableProps = ['COMMN_SFMSFlag', 'COMMN_DocumentType', 'COMMN_DocumentNo', 'COMMN_DocumentDate'];
                            doPropsAction(enableProps, "disable");
                            doPropsAction(enableProps, "Non_Mandate");
                        }
                    }

                    if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {

                        if (messageType == '754') {
                            var enableProps = ['COMMN_Narrative77A'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(enableProps, "Mandate");
                         } else {
                            var enableProps = ['COMMN_Narrative77A'];
                            doPropsAction(enableProps, "disable");
                            doPropsAction(enableProps, "Non_Mandate");
                        }
                    }
                }
                if (propId == "F_CaseFolder.COMMN_ProcessingType") {
                    var lodgementProcessing = self.propValue;
                    if (lodgementProcessing == 'STP') {
                        var mandateProps = ['COMMN_FinacleRefNo'];
                        doPropsAction(mandateProps, "disable");
                        doPropsAction(mandateProps, "Non_Mandate");
                    } else if (lodgementProcessing == 'Manual') {
                        var mandateProps = ['COMMN_FinacleRefNo'];
                        doPropsAction(mandateProps, "enable");
                        doPropsAction(mandateProps, "Mandate");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_Accep_ProcessingType") {
                    var accepProcessing = self.propValue;
                    if (accepProcessing == 'STP') {
                        var mandateProps = ['COMMN_Accep_FinacleRefNo'];
                        doPropsAction(mandateProps, "disable");
                        doPropsAction(mandateProps, "Non_Mandate");
                    } else if (accepProcessing == 'Manual') {
                        var mandateProps = ['COMMN_Accep_FinacleRefNo'];
                        doPropsAction(mandateProps, "enable");
                        doPropsAction(mandateProps, "Mandate");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_Re_ProcessingType") {
                    var reProcessingValue = self.propValue;
                    if (reProcessingValue == 'STP') {
                        var mandateProps = ['COMMN_Re_FinacleRefNo'];
                        doPropsAction(mandateProps, "disable");
                        doPropsAction(mandateProps, "Non_Mandate");
                    } else if (reProcessingValue == 'Manual') {
                        var mandateProps = ['COMMN_Re_FinacleRefNo'];
                        doPropsAction(mandateProps, "enable");
                        doPropsAction(mandateProps, "Mandate");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_Real_ProcessingType") {
                    var accepProcessing = self.propValue;
                    if (accepProcessing == 'STP') {
                        var mandateProps = ['COMMN_Real_FinacleRefNo'];
                        doPropsAction(mandateProps, "disable");
                        doPropsAction(mandateProps, "Non_Mandate");
                    } else if (accepProcessing == 'Manual') {
                        var mandateProps = ['COMMN_Real_FinacleRefNo'];
                        doPropsAction(mandateProps, "enable");
                        doPropsAction(mandateProps, "Mandate");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_Dev_ProcessingType") {
                    var accepProcessing = self.propValue;
                    if (accepProcessing == 'STP') {
                        var mandateProps = ['COMMN_Dev_FinacleRefNo'];
                        doPropsAction(mandateProps, "disable");
                        doPropsAction(mandateProps, "Non_Mandate");
                    } else if (accepProcessing == 'Manual') {
                        var mandateProps = ['COMMN_Dev_FinacleRefNo'];
                        doPropsAction(mandateProps, "enable");
                        doPropsAction(mandateProps, "Mandate");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_Dis_ProcessingType") {
                    var accepProcessing = self.propValue;
                    if (accepProcessing == 'STP') {
                        var mandateProps = ['COMMN_Dis_FinacleRefNo'];
                        doPropsAction(mandateProps, "disable");
                        doPropsAction(mandateProps, "Non_Mandate");
                    } else if (accepProcessing == 'Manual') {
                        var mandateProps = ['COMMN_Dis_FinacleRefNo'];
                        doPropsAction(mandateProps, "enable");
                        doPropsAction(mandateProps, "Mandate");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_HSMG_ProcessingType") {
                    var accepProcessing = self.propValue;
                    if (accepProcessing == 'STP') {
                        var mandateProps = ['COMMN_HSMG_FinacleRefNo'];
                        doPropsAction(mandateProps, "disable");
                        doPropsAction(mandateProps, "Non_Mandate");
                    } else if (accepProcessing == 'Manual') {
                        var mandateProps = ['COMMN_HSMG_FinacleRefNo'];
                        doPropsAction(mandateProps, "enable");
                        doPropsAction(mandateProps, "Mandate");
                    }
                }
                if (propId == "F_CaseFolder.COMMN_BANKCode") {
                    var bankCode = self.propValue;
                    if (bankCode == 'UTIB') {
                        setPropValue("COMMN_BANKCode", null);
                    }
                }
                if (propId == "F_CaseFolder.COMMN_BRANCHCode") {
                    var branchCode = self.propValue;
                    var str = branchCode.substring(0, 4);
                    if (str == 'UTIB') {
                        setPropValue("COMMN_BRANCHCode", null);
                    }
                }
                if (propId == "F_CaseFolder.COMMN_DevolvedDecision") {
                    var devDecision = self.propValue;
                    if (devDecision == 'Devolvement' || devDecision == 'Open New Devolvement account' || devDecision == 'Existing Devolvement Account' || devDecision == 'TOD') {
                        setPropValue("COMMN_Dev_FUNCTION", 'K');
						
						var enableProps = ['COMMN_Dev_DELINKACCOUNTNO', 'COMMN_Dev_REALIZATIONACID', 'COMMN_Dev_PURCHASESALE', 'COMMN_Dev_ACID', 'COMMN_Dev_CHARGEEVENTID'];
							doPropsAction(enableProps, "enable");
							doPropsAction(enableProps, "Mandate");
                    }else{
						var enableProps = ['COMMN_Dev_DELINKACCOUNTNO', 'COMMN_Dev_REALIZATIONACID', 'COMMN_Dev_PURCHASESALE', 'COMMN_Dev_ACID', 'COMMN_Dev_CHARGEEVENTID'];
							doPropsAction(enableProps, "disable");
							doPropsAction(enableProps, "Non_Mandate");

					}
                }

                if (propId == "F_CaseFolder.COMMN_Real_FUNCTION") {
                    var realFunction = self.propValue;
                    if (realFunction == 'R') {
                        var enableProps = ['COMMN_Dev_DELINKACCOUNTNO', 'COMMN_Dev_REALIZATIONACID', 'COMMN_Dev_PURCHASESALE', 'COMMN_Dev_ACID', 'COMMN_Dev_CHARGEEVENTID'];
                        doPropsAction(enableProps, "disable");
                    } else {
                        var enableProps = ['COMMN_Dev_DELINKACCOUNTNO', 'COMMN_Dev_REALIZATIONACID', 'COMMN_Dev_PURCHASESALE', 'COMMN_Dev_ACID', 'COMMN_Dev_CHARGEEVENTID'];
                        doPropsAction(enableProps, "enable");
                    }
                }

                if (propId == "F_CaseFolder.COMMN_RTGSIFSCode") {
                    var rtgsIFSCodeValue = self.propValue;
                    if (rtgsIFSCodeValue != undefined && rtgsIFSCodeValue != null) {
                        var length = rtgsIFSCodeValue.length;
                        if (length >= 4) {
                            var bankCodeVal = rtgsIFSCodeValue.substring(0, 4);
                            setPropValue("COMMN_BANKCode", bankCodeVal);
                        }
                        if (length >= 11) {
                            var branchCodeVal = rtgsIFSCodeValue.substring(5, 11);
                            setPropValue("COMMN_BRANCHCode", branchCodeVal);
                        }
                    }
                }

                if (propId == "F_CaseFolder.COMMN_DrawerBankCodeSFMSIFScode") {
                    var bankIFSCodeValue = self.propValue;
                    if (bankIFSCodeValue != undefined && bankIFSCodeValue != null) {
                        var length = bankIFSCodeValue.length;
                        if (length >= 4) {
                            var bankVal = bankIFSCodeValue.substring(0, 4);
                            setPropValue("COMMN_BANK", bankVal);
                        }
                        if (length >= 11) {
                            var branchVal = bankIFSCodeValue.substring(5, 11);
                            setPropValue("COMMN_BRANCH", branchVal);
                        }
                    }
                }
                /*auto calculate*/

                if (propId == "F_CaseFolder.COMMN_TDSApplicable" || propId == "F_CaseFolder.COMMN_GSTApplicable" || propId == "F_CaseFolder.COMMN_GrossInterestAmount" || propId == "F_CaseFolder.COMMN_TDSAmount" || propId == "F_CaseFolder.COMMN_GSTAmount" || propId == "F_CaseFolder.COMMN_InterestApplicable" || propId == "F_CaseFolder.COMMN_NetInterestAmount" || propId == "F_CaseFolder.COMMN_PrincipleAmount" || propId == "F_CaseFolder.COMMN_StampDutyApplicable" || propId == "F_CaseFolder.COMMN_StampDutyAmount" || propId == "F_CaseFolder.COMMN_CollectiononBill" || propId == "F_CaseFolder.COMMN_DCUtilizationAmount" || propId == "F_CaseFolder.COMMN_OtherBankCharges") {

                    if (propId == "F_CaseFolder.COMMN_TDSApplicable") {
                        var tdsApplicable = self.propValue;
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_GSTApplicable") {
                        var gstApplicable = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_GrossInterestAmount") {
                        var grossInterestAmount = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_TDSAmount") {
                        var tdsAmount = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_GSTAmount") {
                        var gstAmount = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_InterestApplicable") {
                        var interestApplicable = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_NetInterestAmount") {
                        var netInterestAmt = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_PrincipleAmount") {
                        var principleAmt = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_StampDutyApplicable") {
                        var stampDutyApplicable = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_StampDutyAmount") {
                        var stampDutyAmt = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_CollectiononBill") {
                        var collectionOnBill = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_DCUtilizationAmount") {
                        var dcUtilizationAmt = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var otherBankCharges = getPropValue('COMMN_OtherBankCharges');
                    }
                    if (propId == "F_CaseFolder.COMMN_OtherBankCharges") {
                        var otherBankCharges = self.propValue;
                        var tdsApplicable = getPropValue('COMMN_TDSApplicable');
                        var gstApplicable = getPropValue('COMMN_GSTApplicable');
                        var grossInterestAmount = getPropValue('COMMN_GrossInterestAmount');
                        var tdsAmount = getPropValue('COMMN_TDSAmount');
                        var gstAmount = getPropValue('COMMN_GSTAmount');
                        var interestApplicable = getPropValue('COMMN_InterestApplicable');
                        var netInterestAmt = getPropValue('COMMN_NetInterestAmount');
                        var principleAmt = getPropValue('COMMN_PrincipleAmount');
                        var stampDutyApplicable = getPropValue('COMMN_StampDutyApplicable');
                        var stampDutyAmt = getPropValue('COMMN_StampDutyAmount');
                        var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                        var dcUtilizationAmt = getPropValue('COMMN_DCUtilizationAmount');
                    }

                    if (tdsApplicable == 'Yes' && gstApplicable == 'Yes' && grossInterestAmount != null && gstAmount != null && tdsAmount != null) {
                        var netInterestAmount = ((parseFloat(grossInterestAmount) + parseFloat(gstAmount)) - parseFloat(tdsAmount));
                        console.log("netInterestAmount if both yes", netInterestAmount);
                        setPropValue("COMMN_NetInterestAmount", netInterestAmount.toFixed(2));
                    }
                    if (tdsApplicable == 'No' && gstApplicable == 'No' && grossInterestAmount != null) {
                        var netInterestAmount = parseFloat(grossInterestAmount);
                        console.log("netInterestAmount if both No", netInterestAmount);
                        setPropValue("COMMN_NetInterestAmount", netInterestAmount.toFixed(2));
                    }
                    if (tdsApplicable == 'Yes' && gstApplicable == 'No' && grossInterestAmount != null && tdsAmount != null) {
                        var netInterestAmount = (parseFloat(grossInterestAmount) - parseFloat(tdsAmount));
                        console.log("netInterestAmount if one yes other no", netInterestAmount);
                        setPropValue("COMMN_NetInterestAmount", netInterestAmount.toFixed(2));
                    }
                    if (tdsApplicable == 'No' && gstApplicable == 'Yes' && grossInterestAmount != null && gstAmount != null) {
                        var netInterestAmount = (parseFloat(grossInterestAmount) + parseFloat(gstAmount));
                        console.log("netInterestAmount if one no other yes", netInterestAmount);
                        setPropValue("COMMN_NetInterestAmount", netInterestAmount.toFixed(2));
                    }
                    if (interestApplicable == 'Yes' && (gstApplicable == 'Yes' || gstApplicable == 'No') && principleAmt != null && netInterestAmt != null) {
                        var dcUtilizationAmt = (parseFloat(principleAmt) + parseFloat(netInterestAmt));
                        console.log("dcUtilizationAmt", dcUtilizationAmt);
                        setPropValue("COMMN_DCUtilizationAmount", dcUtilizationAmt.toFixed(2));
                    }
                    if (interestApplicable == 'Yes' && stampDutyApplicable == 'Stamp Duty on Applicant' && principleAmt != null && netInterestAmt != null && stampDutyAmt != null) {
                        var dcUtilizationAmt = (parseFloat(principleAmt) + parseFloat(netInterestAmt) + parseFloat(stampDutyAmt));
                        console.log("dcUtilizationAmt", dcUtilizationAmt);
                        setPropValue("COMMN_DCUtilizationAmount", dcUtilizationAmt.toFixed(2));
                    }
                    if (interestApplicable == 'No' && stampDutyApplicable == 'Stamp Duty on Applicant' && principleAmt != null && stampDutyAmt != null) {
                        var dcUtilizationAmt = (parseFloat(principleAmt) + parseFloat(stampDutyAmt));
                        console.log("dcUtilizationAmt", dcUtilizationAmt);
                        setPropValue("COMMN_DCUtilizationAmount", dcUtilizationAmt.toFixed(2));
                    }
                    if (interestApplicable == 'No' && stampDutyApplicable == 'No' && principleAmt != null) {
                        var dcUtilizationAmt = (parseFloat(principleAmt));
                        console.log("dcUtilizationAmt", dcUtilizationAmt);
                        setPropValue("COMMN_DCUtilizationAmount", dcUtilizationAmt.toFixed(2));
                    }
                    if (collectionOnBill == 'Backed by LC' && dcUtilizationAmt != null && otherBankCharges != null) {
                        var totalClaimedAmt = (parseFloat(dcUtilizationAmt) + parseFloat(otherBankCharges));
                        console.log("totalClaimedAmt", totalClaimedAmt);
                        setPropValue("COMMN_TotalClaimedAmount", totalClaimedAmt.toFixed(2));
                    }
                    if (collectionOnBill == 'Non LC' && interestApplicable == 'Yes' && principleAmt != null && netInterestAmt != null) {
                        var totalClaimedAmt = (parseFloat(principleAmt) + parseFloat(netInterestAmt));
                        console.log("totalClaimedAmt", totalClaimedAmt);
                        setPropValue("COMMN_TotalClaimedAmount", totalClaimedAmt.toFixed(2));
                    }
                    if (collectionOnBill == 'Non LC' && interestApplicable == 'No' && principleAmt != null) {
                        var totalClaimedAmt = parseFloat(principleAmt);
                        console.log("totalClaimedAmt", totalClaimedAmt);
                        setPropValue("COMMN_TotalClaimedAmount", totalClaimedAmt.toFixed(2));
                    }
                }
				
				if(propId == "F_CaseFolder.COMMN_CommissiononIBC"){
					var commissionIBC = self.propValue;
					var commission = parseFloat(commissionIBC);
					var gst = (commission * 0.18);
					setPropValue("COMMN_GST", gst.toFixed(2));
				}

				if(propId == "F_CaseFolder.COMMN_PostageonIBC"){
					var postageIBC = self.propValue;
					var postage = parseFloat(postageIBC);
					var postageGst = (postage * 0.18);
					setPropValue("COMMN_PostageGST", postageGst.toFixed(2));
				}

				if(propId == "F_CaseFolder.COMMN_SFMSCharges"){
					var sfmsCharges = self.propValue;
					var sfms = parseFloat(sfmsCharges);
					var sfmsGst = (sfms * 0.18);
					setPropValue("COMMN_SFMSGST", sfmsGst.toFixed(2));
				}

				if(propId == "F_CaseFolder.COMMN_DiscrpancyCharges"){
					var discrepancyCharges = self.propValue;
					var discrepancy = parseFloat(discrepancyCharges);
					var discrepancyGst = (discrepancy * 0.18);
					setPropValue("COMMN_DiscrepancyGST", discrepancyGst.toFixed(2));
				}

                /*Finacle Service Implementation*/

                /*Cust_ID Service Implementation*/
                if (propId == "F_CaseFolder.COMMN_Custid") {
                    var url = finUrls.getCustomerDetailsOnCustIdZone;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, fetchAgainstCustID);

                    var url = finUrls.getOCCAccountType;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, fetchOCCAccountType);

                    var url = finUrls.getCustIdValidation;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, validateCustID);

                }
				 if (propId == "F_CaseFolder.COMMN_AccountNotobeDebited") {
						var url = finUrls.getOperativeAccountDetails;
						url = url.replace("%1", self.propValue);
						callFinacleService(url, setAccountHolderName);
				 }
				
                /*OperativeAccNo Service Implementation*/
                if (propId == "F_CaseFolder.COMMN_OperativeAccountNo") {

                    var url = finUrls.getOperativeAccountDetails;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, fetchAgainstOperativeAccNo);

                    var url = finUrls.getGstAgainstAccNum;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, getGstNosAgainstAccNo);

                    var url = finUrls.getOperativeAccountDetails;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, showOperativeAccNoDetails);

                    var CustID = getPropValue('COMMN_Custid');
                    var url = finUrls.validateCustIdWithAccNo;
                    url = url.replace("%1", CustID);
                    url = url.replace("%2", self.propValue);
                    callFinacleService(url, validateOperativeCustID);

                }
                /*Set Selected Gst No*/
                if (propId == "F_CaseFolder.COMMN_GSTNo") {
                    setPropValue("COMMN_SelectedGSTNo", self.propValue);
                }
                if (propId === "F_CaseFolder.COMMN_GSTNo") {
                    console.log("Inside GST Flag Set");
                    var gstFlag = self.pg_propCollectionController.getPropertyController("COMMN_GSTINDefaultFlagYesNo");
                    var gstSelect = self.pg_propCollectionController.getPropertyController("COMMN_SelectedGSTNo");
                    var gstSelectNum = gstSelect.get("value");
                    var selectGSTno = gstSelectNum.split("(");
                    if (gstSelectNum !== null && gstSelectNum.includes("DEFAULT")) {

                        gstFlag.set("value", "Y");
                        gstSelect.set("value", selectGSTno[0]);
                        console.log("Flag Set Yes");
                    } else {
                        gstFlag.set("value", "N");
                        gstSelect.set("value", gstSelectNum);
                        console.log("Flag Set No");
                    }

                }
                //Set Selected Gst No
                if (propId == "F_CaseFolder.COMMN_SelectedGSTNumber") {
                    var url = finUrls.getGstNoFlag;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, fetchGSTNoFlag);
                }

                //ChargesAccNo Service Implementation
                if (propId == "F_CaseFolder.COMMN_ChargesAcctNum") {
                    var url = finUrls.getOperativeAccNameobile;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, fetchAgainstChargesAccNo);
                }


                /*OriginSolId Service Implementation*/
                if (propId == "F_CaseFolder.COMMN_OriginSOLID") {
                    var url = finUrls.validateSolIdWithOrgSol;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, validateOriginSolID);
                }
                /*SolId Service Implementation*/
                if (propId == "F_CaseFolder.COMMN_SOLID") {
                    var url = finUrls.validateSolId;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, validateSolID);

                    var url = finUrls.getZoneAgainstSolID;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, ZoneAgainstSolID);
                }
                //FinacleRefNo Service Implementation
                if (propId == "F_CaseFolder.COMMN_FinacleRefNo") {
                    var registerType = getPropValue("COMMN_BillType");
                    var solID = getPropValue("COMMN_SOLID");

                    var url = finUrls.fetchFinacleDetails;
                    url = url.replace("%1", self.propValue);
                    url = url.replace("%2", solID);
                    url = url.replace("%3", registerType);
                    callFinacleService(url, setFinacleDetails);

                }
                //Asp Implementation starts
                //RefAccountNo Service Implementation
                if (propId == "F_CaseFolder.COMMN_RefAccountNo") {
                    var url = finUrls.getRefAccntNoDetails;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, setRefAccntNoDetails);
                }
                //Dc Number Service Implementation
                if (propId == "F_CaseFolder.COMMN_DCNumber") {
                    var url = finUrls.getDetailsBasedOnDCNo;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, setDetailsBasedOnDCNo);
                }
				//Set LC Name On DC NO CUSTID
				 /* if (propId == "F_CaseFolder.COMMN_CUSTIDOFLC") {
					var url = finUrls.getCustomerDetailsOnCustIdZone;;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, setLCNameOnCUSTID);
                } */
				
                //Due Date Service Implementation
                if (propId == "F_CaseFolder.COMMN_DueDate") {
                    var url = finUrls.validateForDueDate;
                    var today = new Date();
                    var dt = today.getDate();
                    var mon = today.getMonth();
                    var yr = today.getFullYear();
                    url = url.replace("%1", dt);
                    url = url.replace("%2", mon);
                    url = url.replace("%3", yr);
                    url = url.replace("%4", self.propValue);
                    callFinacleService(url, validateForDueDate);
                }
                //RTGS IFS Code validation Service Implementation
                if (propId == "F_CaseFolder.COMMN_RTGSIFSCode") {
                    var url = finUrls.validateRTGSIFSCCode;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, validateRTGSIFSCCode);
                }
                //Cust Category validation Service Implementation
                if (propId == "F_CaseFolder.COMMN_CustomerCategory") {
                    var url = finUrls.validateCustCategory;
                    url = url.replace("%1", self.propValue);
                    callFinacleService(url, validateCustCategory);
                }
                //Earlier WID Implementation
                if (propId == "F_CaseFolder.COMMN_EarlierWID") {
                    var url = finUrls.EarlierWIDService;
                    var widNoQueryString = "COMMN_WID=" + "'" + self.propValue + "'";
                    var prefix = "COMMN_";
                    var caseType = "IBC_InwardBill";
                    url = url.replace("%1", widNoQueryString);
                    url = url.replace("%2", prefix);
                    url = url.replace("%3", caseType);
                    callFinacleService(url, setAllPropsValue);
                }
                //Asp Implementation Ends

                if (propId == "F_CaseFolder.COMMN_BANKCode" || propId == "F_CaseFolder.COMMN_BRANCHCode") {
                    if (propId == "F_CaseFolder.COMMN_BANKCode") {
                        var bankCode = self.propValue;
                        var branchCode = getPropValue('COMMN_BRANCHCode');
                    } else if (propId == "F_CaseFolder.COMMN_BRANCHCode") {
                        var branchCode = self.propValue;
                        var bankCode = getPropValue('COMMN_BANKCode');
                    }

                    if (bankCode !== null && branchCode !== null && bankCode != undefined && branchCode != undefined) {
                        var url = finUrls.getBICCode;
                        url = url.replace("%1", bankCode);
                        url = url.replace("%2", branchCode);
                        callFinacleService(url, bicCodeService);
                    }
                }
                if (propId == "F_CaseFolder.COMMN_BANK" || propId == "F_CaseFolder.COMMN_BRANCH") {
                    if (propId == "F_CaseFolder.COMMN_BANK") {
                        var bank = self.propValue;
                        var branch = getPropValue('COMMN_BRANCH');
                    } else if (propId == "F_CaseFolder.COMMN_BRANCH") {
                        var branch = self.propValue;
                        var bank = getPropValue('COMMN_BANK');
                    }

                    if (bank !== null && branch !== null && bank != undefined && branch != undefined) {
                        var url = finUrls.getBICCode;
                        url = url.replace("%1", bank);
                        url = url.replace("%2", branch);
                        callFinacleService(url, bicService);
                    }
                }

            } else if (self.pg_eventName == "icm.FieldUpdated") {
                //Currrently No Scripts In this block
            } else if (self.pg_eventName == "icm.CellClicked") {
                self.current_row = payload.row;
            } else if (self.pg_eventName == "icm.CellChanged") {
                self.current_row = payload.row;
            } else if (self.pg_eventName == "icm.CellUpdated") {
                self.current_row = payload.row;
            } else if (self.pg_eventName == "onClickEWIDocs") {
                console.log("////////");
                dailogMessage = self.earierDocsList;
                customPopUpViewerForDocs();
            }


            /*Methods for Finacle Service*/
            function fetchAgainstCustID(response) {
                var map = {
                    'CUST_NAME': 'COMMN_CustomerName',
                    'CUST_ZONE': 'COMMN_CustTypeZone',
                    'SEGMENT': 'COMMN_SegmentFinal',
                    'CBO_UNIT': 'COMMN_CBOUnit',
                    'EMAIL': 'COMMN_RegisteredEmailid'
                };
                setFinacleServiceData(map, response);
                /*checkTFPartyFlag(response);*/

            }
			
			function setLCNameOnCUSTID(response){
				var map = {'CUST_NAME': 'COMMN_ApplicantNameinLC'};
                setFinacleServiceData(map, response);
			}

            function fetchOCCAccountType(response) {
                var map = {
                    'FORACID': 'COMMN_RefAccountNo'
                };
                setFinacleServiceData(map, response);
            }
			function setAccountHolderName(response){
				 var map = {
                    'ACCT_NAME': 'COMMN_AccountHolderName'
                };
                setFinacleServiceData(map, response);
			}

            function fetchAgainstOperativeAccNo(response) {
                var map = {
                    'ACCT_NAME': 'COMMN_OperativeAccountName'
                };
                setFinacleServiceData(map, response);

                var map = {
                    'ACCT_NAME': 'COMMN_ExisitingDevolvmentAccountName'
                };
                setFinacleServiceData(map, response);

                var map = {
                    'ACCT_NAME': 'COMMN_AccountName'
                };
                setFinacleServiceData(map, response);

/*                 var map = {
                    'ACCT_NAME': 'COMMN_AccountHolderName'
                };
                setFinacleServiceData(map, response); */

            }

            function fetchAgainstChargesAccNo(response) {
                var map = {
                    'ACCT_NAME': 'COMMN_ChargesAcctName'
                    //,'ACCT_CRNCY_CODE': 'COMMN_Currency',	                     
                    //'SCHM_TYPE':'COMMN_SchemeType',
                    //'ACCT_OPN_DATE':'COMMN_OperativeAcctOpeningDate'
                };
                setFinacleServiceData(map, response);

            }

            function fetchGSTNoFlag(response) {
                if (response["DEFAULT_FLAG"] == 'Y') {
                    setPropValue("COMMN_GSTNDefaultFlagYN", "Yes");
                } else {
                    setPropValue("COMMN_GSTNDefaultFlagYN", "No");
                }
            }

            function showOperativeAccNoDetails(response) {
                dailogMessage += "<li>Effective Balance ::" + response.EFF_BALANCE + "</li>";
                dailogMessage += "<li>Account Status ::" + response.ACCT_STATUS + "</li>";
                dailogMessage += "<li>Account Currency Code ::" + response.ACCT_CRNCY_CODE + "</li>";
                dailogMessage += "<li>Scheme Type ::" + response.SCHM_TYPE + "</li>";
                customPopUpViewer2();
            }

            function getGstNosAgainstAccNo(response) {
                var gstNumbers = response.GST_NUM;
                if (self.pg_editable.propertiesCollection.hasOwnProperty("COMMN_GSTNo")) {
                    var propController = self.pg_propCollectionController.getPropertyController("COMMN_GSTNo");
                    if (propController != undefined) {
                        var choicelist = [];
                        var gstArray = gstNumbers.substr(1, gstNumbers.length - 2).split(",");
                        array.forEach(gstArray, function(number) {
                            console.log(" number ", number);
                            var object = new Object();
                            object["label"] = number;
                            object["value"] = number;
                            choicelist.push(number);
                        });
                        propController.set("choices", choicelist);
                        propController.set("choices", choicelist);
                    } else {
                        console.log("COMMN_GSTNo" + " is Undefined for this action");
                    }
                }
            }

            function validateOriginSolID(response) {
                if (response["output"] == "true") {
                    customPopUpViewer("OrginSolID Validated Successfully");
                } else {
                    customPopUpViewer("OrginSolID is Invalid");
                }

            }

            function validateSolID(response) {
                if (response["valid"] == "true") {
                    customPopUpViewer("SolID Validated Successfully");

                } else {
                    customPopUpViewer("SolID is Invalid");
                }
            }

            function validateCustID(response) {
                if (response["FLAG"] == "Y") {
                    customPopUpViewer("CUST ID Validated Successfully");

                } else {
                    customPopUpViewer("CUST ID is Invalid");
                }
            }

            function validateOperativeCustID(response) {
                if (response["output"] == "true") {
                    customPopUpViewer("CUST ID Validated Successfully");

                } else {
                    customPopUpViewer("CUST ID doesn't match with Operative Account No");
                }
            }
            /*function checkTFPartyFlag(response) {
                if (response !== undefined && response.TFPARTYFLAG !== null && response.TFPARTYFLAG !== undefined && response.TFPARTYFLAG !== '' && response.TFPARTYFLAG == 'N') {
                    customPopUpViewer("Entered Cust Id Doesn't have Trade Finance Access");
                }
            }*/
            function ZoneAgainstSolID(response) {
                var map = {
                    'ZONE': 'COMMN_Zone'
                };
                setFinacleServiceData(map, response);
            }

            function setFinacleDetails(response) {
                /*var map = {
                    'COLLECTION_CRNCY': 'COMMN_Currency',
                    "CIF_ID": "COMMN_CustID",
                    "COLLECTION_AMT": "COMMN_Amount"
                };
                setFinacleServiceData(map, response);*/
				
				if (response["CIF_ID"] != undefined || response["CIF_ID"] != null) {
                    customPopUpViewer("Finacle Ref No validated successfully");
                }else{
					customPopUpViewer("Finacle Ref No is invalid, kindly check");
                    setPropValue("COMMN_FinacleRefNo", null);
				}
            }
			
            //Asp Implementation
            function setRefAccntNoDetails(response) {
                var map = {
                    'SANCT_LIM': 'COMMN_SanctionLimit',
                    "LIMIT_PREFIX": "COMMN_LimitId",
                    "LIMIT_SUFFIX": "COMMN_LimitIdSuffix",
                    "INT_TBL_CODE": "COMMN_InterestRateCode",
                    "SECTOR_CODE": "COMMN_SectorCode",
                    "SUB_SECTOR_CODE": "COMMN_SubSectorCode",
                    "ACCT_OCCP_CODE": "COMMN_OccupationCode",
                    "PURPOSE_OF_ADVN": "COMMN_PurposeofAdvance",
                    "MODE_OF_ADVN": "COMMN_ModeofAdvance",
                    "TYPE_OF_ADVN": "COMMN_TypeofAdvance",
                    "NATURE_OF_ADVN": "COMMN_NatureofAdvance",
                    "GUAR_COVER_CODE": "COMMN_GuaranteeCoverCode",
                    "INDUSTRY_TYPE": "COMMN_IndustryType",
                    "LIM_SANCT_DATE": "COMMN_SanctionDate",
                    "LIM_EXP_DATE": "COMMN_ExpiryDate",
                    "LOAN_PAPER_DATE": "COMMN_CBO_DocumentDate",
                    "APPLICABLE_DATE": "COMMN_ReviewDate",
                    "SANCT_LEVL_CODE": "COMMN_SactionLevel",
                    "SANCT_AUTH_CODE": "COMMN_SanctionAuthority",
                    "DRWNG_POWER": "COMMN_DrawingPower"
                };
                setFinacleServiceData(map, response);
            }

            function setDetailsBasedOnDCNo(response) {
                var map = {
                    'ISSU_PARTY_CODE': 'COMMN_CUSTIDOFLC',
                    "DATE_OPND": "COMMN_LCOpenDate",
                    "PLACE_OF_EXPIRY": "COMMN_PlaceofExpiry",
                    "EXPIRY_DATE": "COMMN_LCExpiryDate",
                    "APPLICANT_NAME": "COMMN_BeneficiaryNameinLC",
                    "ACTL_USANCE": "COMMN_UsanceDays",
                    "AVAILABLE_VALUE": "COMMN_LcAvailableValue",
                    "TENOR_DESC": "COMMN_TenorDiscription"
                };
                setFinacleServiceData(map, response);
				 var map = {
                    'APPLICANT_NAME': 'COMMN_ApplicantNameinLC',
                    
                };
                setFinacleServiceData(map, response);
				
            }

            function validateForDueDate(response) {
                var dueDate = self.propValue;
                var today = new Date();
                if (response != undefined && response != null && response["IS_HOLIDAY"] == "Y" && dueDate == today) {
                    customPopUpViewer("Due Date is a Holiday.");
                }
            }

            function validateRTGSIFSCCode(response) {
                if (response != undefined && response != null && response["COUNT"] == "1") {
                    customPopUpViewer("RTGS IFSC Code Validated Successfully.");
                } else {
                    customPopUpViewer("RTGS IFSC Code is InValid.");
                }
            }

            function validateCustCategory(response) {
                if (response != undefined && response != null && response["BORROWER/NON-BORROWER"] == "NON-BORROWER") {
                    customPopUpViewer("Customer is a NON-BORROWER.");
                }
            }
            //Asp Implementation Ends
            
              function setAllPropsValue(response) {
                //var repositoryID = "icmtos";
                //var ip = "http://10.254.9.58:9080/";
                var docIds = response["docs"];
                var properties = response["props"];
				var excludedProps=["COMMN_Source","COMMN_TradePortalRefNo","COMMN_Operation","COMMN_SubOperation","COMMN_NFTR","COMMN_RejectionReason","COMMN_RejectionCategory","COMMN_TFCComment","COMMN_BranchComment","COMMN_WhetherGapResolved"];
                var props = self.pg_propCollectionController.getPropertyControllers("F_CaseFolder");
                for (var i = 0; i < props.length; i++) {
                    var propId = props[i]["id"];
					if(!(excludedProps.includes(propId))){
						var value = properties[propId];
						var type = props[i]["type"];
						if (type == "datetime") {
							var date = new Date(value);
							props[i].set("value", date);
						} else {
							props[i].set("value", value);
						}
					}
                  
                }

                var keysList = Object.keys(docIds);
                for (var i = 0; i < keysList.length; i++) {
                    var docId = docIds[keysList[i]];
                    var docTitle = keysList[i];
                    dailogMessage += "<li><a href=" + "\"" + ip + "navigator/bookmark.jsp?desktop=icm&repositoryId=" + repositoryID + "&docid=" + docId + "&template_name=Document&version=released\" target=\"_blank\">" + docTitle + "</a></li>"
                }
                self.earierDocsList = dailogMessage;
                customPopUpViewerForDocs();

            }

            //Asp Implementation Ends

            function bicCodeService(response) {
                var map = {
                    'BANK_IDENTIFIER': 'COMMN_BIC'
                };
                setFinacleServiceData(map, response);
            }

            function bicService(response) {
                var map = {
                    'BANK_IDENTIFIER': 'COMMN_FinSTP_BIC'
                };
                setFinacleServiceData(map, response);
            }

            function getPropValue(propertyId) {
                if (self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) {
                    var propController = self.pg_propCollectionController.getPropertyController(propertyId);
                    if (propController != undefined) {
                        return propController.get("value");
                    } else {
                        console.log(propertyId + " is Undefined for this action");
                        return null;
                    }
                }
            }

            function setPropValue(propertyId, value) {
                if (self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) {
                    var propController = self.pg_propCollectionController.getPropertyController(propertyId);
                    if (propController != undefined) {
                        propController.set("value", value);
                    } else {
                        console.log(propertyId + " is Undefined for this action");
                    }
                }
            }


            function setFinacleServiceData(map, response) {
                var keysList = Object.keys(map);
                for (var i = 0; i < keysList.length; i++) {
                    var propertyId = map[keysList[i]];
                    var propertyValue = response[keysList[i]];

                    if (self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) {

                        var propController = self.pg_propCollectionController.getPropertyController(propertyId);
                        if (propController != undefined && propertyValue != null && propertyValue != undefined) {
                            if (propertyId == "COMMN_OperativeAcctOpeningDate" || propertyId.toLowerCase().includes("date")) {
                                propController.set("value", new Date(propertyValue));

                            } else {

                                propController.set("value", propertyValue.trim());

                            }

                        } else {

                            console.log(propertyId + " is Undefined for this action");
                        }
                    }

                }

            }



            function doPropsAction(props, action) {
                for (var i = 0; i < props.length; i++) {
                    if (self.pg_editable.propertiesCollection.hasOwnProperty(props[i])) {
                        var propController = self.pg_propCollectionController.getPropertyController(props[i]);
                        if (propController != undefined) {
                            if (action == "Mandate") {
                                propController.set("required", true);
                            } else if (action == "Non_Mandate") {
                                propController.set("required", false);
                            } else if (action == "disable") {
                                propController.set("readOnly", true);
                            } else if (action == "enable") {
                                propController.set("readOnly", false);
                            } else if (action == "hide") {
                                propController.set("hidden", true);
                            } else if (action == "unhide") {
                                propController.set("hidden", false);
                            }
                        } else {

                            console.log(props[i] + " is Undefined for OnLoadAction");
                        }
                    }
                }
            }


            //Method to Assign one Prop value to other Prop
            function exchangePropValue(receiver) {
                var donerValue = self.propValue;
                if (self.pg_editable.propertiesCollection.hasOwnProperty(receiver)) {
                    var receiverController = self.pg_propCollectionController.getPropertyController(receiver);
                    if (receiverController != undefined) {
                        if (donerValue != undefined && donerValue != null) {
                            receiverController.set("value", donerValue);
                        }

                    } else {

                        console.log("Doner Value::" + donerValue + "can't set value to receiver ::" + receiverController);
                    }
                }

            }

            //Confiramation POPUP Viewer
            function customPopUpViewer(dailogMessage) {
                dailogMessage = "<li>" + dailogMessage + "</li>";
                var dailog = new ecm.widget.dialog.BaseDialog();
                dailog.setTitle("Validation");
                dailog.setMessage("<ul>" + dailogMessage + "</ul>", "error");
                dailog.show();
            }
            //Confiramation POPUP Viewer2
            function customPopUpViewer2() {
                var dailog = new ecm.widget.dialog.BaseDialog();
                dailog.setTitle("Validation");
                dailog.setMessage("<ul>" + dailogMessage + "</ul>", "error");
                dailog.show();
                dailogMessage = "";
            }
            //Confiramation POPUP Viewer for Documents
            function customPopUpViewerForDocs() {
                var dailog = new ecm.widget.dialog.BaseDialog();
                dailog.setTitle("Early WID Documents");
                if (dailogMessage != undefined && dailogMessage != "") {
                    dailog.setMessage("<ul>" + dailogMessage + "</ul>", "confirmation");
                } else if (dailogMessage == undefined) {
                    dailog.setMessage("<ul>" + "<li>Kindly fill the Earlier WID No.</li>" + "</ul>", "confirmation");
                } else {
                    dailog.setMessage("<ul>" + "<li>Existing Ealier WID No doesn't have any docs.</li>" + "</ul>", "confirmation");
                }
                dailog.show();
                dailogMessage = "";
            }

            //Ajax call for Finacle Service
            function callFinacleService(URL, callBack) {
                var response = {};
                console.log("Inside callFinancial Service - URL ", URL);
                console.log("Inside callFinancial Service - CallBack", callBack);
                xhrArgs = {
                    url: URL,
                    handleAs: "json",
                    sync: true,
                    preventCache: true,
                    headers: {
                        "Content-Type": "application/json"
                    },
                    load: callBack,
                    error: function(error) {
                        console.log("Inside sol maker work Load  error  ", error);
                    }
                };

                response = dojo.xhrGet(xhrArgs);
                return response;
            }

            function feedChoiceItems(propID, choiceItem) {
                if (self.pg_editable.propertiesCollection.hasOwnProperty(propID)) {
                    var propController = self.pg_propCollectionController.getPropertyController(propID);
                    if (propController != undefined) {
                        propController.set("choices", choiceItem);
                    } else {
                        console.log(props[i] + " is Undefined for OnLoadAction");
                    }
                }

            }
			
            function freezeNonMandateAllProps() {
				
                var props = self.pg_propCollectionController.getPropertyControllers("F_CaseFolder");
                for (var i = 0; i < props.length; i++) {
                    props[i].set("readOnly", true);
					props[i].set("required", false);
                }
				
				
            }




        }

    });


});