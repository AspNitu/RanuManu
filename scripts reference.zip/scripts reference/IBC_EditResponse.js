//21/05/2020
require(["icm/base/Constants", "icm/model/properties/controller/ControllerManager","dojo/_base/lang","dojo/aspect","pvr/widget/editors/grid/_GridEditor"], function(Constants, ControllerManager,lang,aspect,_GridEditor){

	lang.setObject("IBC_EditResponse",{
        //Remove Unnecessary Responses and Grid Validation
		"OnEditResponseAction":function(pg_editable,role)
	    {
			var operation = pg_editable.icmWorkItem.attributes.COMMN_Operation;
			var nftrFlag = pg_editable.icmWorkItem.attributes.COMMN_NFTR;
			var reportingValue = pg_editable.icmWorkItem.attributes.COMMN_Reporting;
			lang.setObject("reportingValLabel",reportingValue);
			
			//For All Operation Response removal
			if(role=="SOL MAKER"){
				if(nftrFlag!=true){
					var responsesToRemove=["Send to Branch Hold"];
					removeResponses(responsesToRemove);
				}
			}				
						
			//For OperationWise Response removal		
			if(operation == 'LODGEMENT')
			{
				if(role=="SOL CHECKER"){
					var responsesToRemove=["Send to DTFC Comp"];
					removeResponses(responsesToRemove);
				}		 		
				if(role=="BRANCH HOLD"){
					var responsesToRemove=["Send to DTFC Comp"];
					removeResponses(responsesToRemove);
				}	 		
				if(role=="FIN ENTRY"){}	 		
				if(role=="FIN AUTH"){
					var responsesToRemove=["Send to Pending Realisation","Send to Processed"];
					removeResponses(responsesToRemove);
				}	 		
				if(role=="XMM ENTRY/MOD"){}	 		
				if(role=="SFMS AUTH"){
					var responsesToRemove=["Send to Pending Realisation"];
					removeResponses(responsesToRemove);
				}	 		
			
		    }else if(operation == 'PRE-ACCEPTED'){
					 		
				if(role=="SOL CHECKER"){
					var responsesToRemove=["Send to DTFC Comp"];
					removeResponses(responsesToRemove);
				}	 		
				if(role=="BRANCH HOLD"){
					var responsesToRemove=["Send to DTFC Comp"];
					removeResponses(responsesToRemove);
				}	 		
				if(role=="FIN ENTRY"){}	 		
				if(role=="FIN AUTH"){
					var responsesToRemove=["Send to BR Accept Maker","Send to Processed"];
					removeResponses(responsesToRemove);
				}	 		
				if(role=="XMM ENTRY/MOD"){}	 		
				if(role=="SFMS AUTH"){
					var responsesToRemove=["Send to BR Accept Maker"];
					removeResponses(responsesToRemove);
				}	 		
				
				
			}else if(operation == 'ROLLOVER'){
					 		
				if(role=="SOL CHECKER"){
					var responsesToRemove=["Send to DTFC OCR"];
					removeResponses(responsesToRemove);	
				}				
				if(role=="DTFC COMP"){
					var responsesToRemove=["Send to Fin Entry","Send to FIN STP","Reject to DTFC OCR"];
					removeResponses(responsesToRemove);	
				}	 		
				if(role=="BRANCH HOLD"){
					var responsesToRemove=["Send to DTFC OCR"];
					removeResponses(responsesToRemove);
				}	 				
				if(role=="SFMS AUTH"){
					var responsesToRemove=["Reject to Fin Auth","Send to Processed","Send to DTFC Hold","Send to Pending Realisation"];
					removeResponses(responsesToRemove);
				}	 		
			
				
			}else if(operation == 'CHARGE REVERSAL'||operation == 'MISCELLANEOUS'){
					 		
				if(role=="SOL CHECKER"){
					var responsesToRemove=["Send to DTFC OCR"];
					removeResponses(responsesToRemove);	
				}			
				if(role=="DTFC COMP"){
					var responsesToRemove=["Send to XMM Entry/MOD","Send to FIN STP","Reject to DTFC OCR","Send to SFMS Auth"];
					removeResponses(responsesToRemove);	
				}	 		
				if(role=="BRANCH HOLD"){
					var responsesToRemove=["Send to DTFC OCR"];
					removeResponses(responsesToRemove);
				}	 		
				if(role=="FIN ENTRY"){}	 		
				if(role=="FIN AUTH"){
					var responsesToRemove=["Send to Pending Realisation","Send to BR Accept Maker","Send to SFMS Auth"];
					removeResponses(responsesToRemove);
				}	 		
				if(role=="XMM ENTRY/MOD"){}	 		
				if(role=="SFMS AUTH"){
					var responsesToRemove=["Send to Pending Realisation","Send to BR Accept Maker","Send to DTFC Hold"];
					removeResponses(responsesToRemove);
				}	 		
					
			}
							
			
			
			/*Grid Validation*/
			aspect.before(_GridEditor.prototype, "focus", function(response) 
			{
				
                var propName = this.editorWidget.property.params.binding;
                propName = propName.substring(propName.indexOf(".") + 1);
                var role1 = ecm.model.desktop.currentRole.name;
                console.log("role" + role + "   ......role1" + role1);
				
				/*Rejection Grid Non editable*/
				if(propName=="COMMN_RejectionReason"||propName=="COMMN_RejectionCategory"||propName=="COMMN_TFCComment"){
					if(role1=="DTFC COMP"||role1=="SFMS AUTH" || role1 == "BILL ACCEPTANCE"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
				if(propName=="COMMN_BranchComment"||propName=="COMMN_WhetherGapResolved"){
					if(role1=="BRANCH HOLD"||role1=="DTFC HOLD"||role1=="BR ACCEPT MAKER"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
		
				/*Deferral Grid Non editable*/
				if(propName=="COMMN_DeferralReason"||propName=="COMMN_EmpNo"||propName=="COMMN_ApproversRole"||propName=="COMMN_DefGrid_DueDate"){
					if(role1=="PENDING REALISATION"||role1=="REALISATION FIN ENTRY"||role1=="REALISATION FIN ENTRY"||role1=="RTGS ENTRY"||role1=="RTGS AUTH"||role1=="RECOVERY AUTH"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
				if(propName=="COMMN_DTFCComment"){
					if(role1=="DEFERRAL DTFC"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
				
				/*Underlying Grid Non editable*/
				if(propName=="COMMN_UnderlyingDocs"||propName=="COMMN_NameofApplicant"||propName=="COMMN_NameofBene"||propName=="COMMN_BeneficiaryAccountNo"||propName=="COMMN_UnGrid_Currency"||propName=="COMMN_Amount"||propName=="COMMN_UnderlyingNo"||propName=="COMMN_UnderlyingDate"||propName=="COMMN_RemittanceAmount"){
					if(role1=="SOL MAKER"||role1=="DTFC OCR"||role1=="DTFC COMP"||role1=="FIN ENTRY"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
				
				/*Discrepancy Grid*/
				if(propName=="COMMN_DISCREPENCY"){
					if(role1=="BILL ACCEPTANCE"||role1=="DTFC OCR"||role1=="DTFC COMP"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
				/*Instruction Grid*/
				if(propName == "COMMN_FilterMessage_1" || propName == "COMMN_InstructionBy_1" || propName == "COMMN_InstructionDescription_1" || propName == "COMMN_InstructionSubDesc_1"){
					if(role1 == "DTFC OCR" || role1 == "DTFC COMP"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
				
				if(propName == "COMMN_FilterMessage_2" || propName == "COMMN_InstructionBy_2" || propName == "COMMN_InstructionDescription_2" || propName == "COMMN_InstructionSubDesc_2" || propName == "COMMN_FilterMessage_6" || propName == "COMMN_InstructionBy_6" || propName == "COMMN_InstructionDescription_6" || propName == "COMMN_InstructionSubDesc_6"){
					if(role1=="BILL ACCEPTANCE"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
				
				if(propName == "COMMN_FilterMessage_3" || propName == "COMMN_InstructionBy_3" || propName == "COMMN_InstructionDescription_3" || propName == "COMMN_InstructionSubDesc_3" || propName == "COMMN_FilterMessage_4" || propName == "COMMN_InstructionBy_4" || propName == "COMMN_InstructionDescription_4" || propName == "COMMN_InstructionSubDesc_4"){
					if(role1 == "PENDING REALISATION"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
				
				if(propName == "COMMN_FilterMessage_5" || propName == "COMMN_InstructionBy_5" || propName == "COMMN_InstructionDescription_5" || propName == "COMMN_InstructionSubDesc_5"){
					if(role1 == "DEVOLVED"){
						this.editorWidget.domNode.style.display = "block";
					}else{
						this.editorWidget.domNode.style.display = "none";
					}
				}
            });
				    
		    //Method to remove responses from Workitem Obj
			function removeResponses(responses)
			{
				if(responses.length!=0)
				{
					var workItem = pg_editable.icmWorkItem;
					var newResponses = workItem.responses.filter(function(item){ return responses.indexOf(item)==-1});
					workItem.responses = newResponses;	
				}
				
			}
			
	    	
			
		}				
	});				
						
});						
