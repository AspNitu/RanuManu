/* Scripts having all the constants */

/* Import here all the Modules used in this JS */
require(["dojo/_base/lang"],function(lang){
	
	lang.setObject("IBC_TRADConstants",{
		
		"loadConstants":function(){
			
			var ip="http://10.254.9.58:9081"; //DGSL_DEV
		 // var ip="http://10.9.12.57:9081"; 
		 /* var ip="https://tradaxinuat.axisb.com"; Axis_uat */
		 /* var ip="https://tradaxin.axisb.com"; //Axis_prod */
			var repositoryID = "icmtos";//DGSL_DEV
			
			var tbmlIP = "http://10.254.9.58:9081/TradaxTBML/IBCTBMLServices/";
			
			var finacleUrls={
	
					"getZoneAgainstSolID":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getZoneAgainstSolId?solId=%1",
					
					"getOperativeAccountDetails":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getOperativeAccountDetails?accountNum=%1",
					
					"getCustomerDetailsOnCustIdZone":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getCustDetails?custId=%1",
					
					"getOCCAccountType":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getOCCAccountType?custId=%1",
					
					"getGstAgainstAccNum":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getGstAgainstAccNum?accountNum=%1",
					
					"fetchFinacleDetails":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getValidFinacleRef?finRef=%1&solId=%2&resgisterType=%3",
					
					"getCustIdValidation":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getCustIdValidation?custId=%1",
					
					"validateSolId":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/validateSolId?solId=%1",
					
					"FINACLE_SOLID_USERID":"http://10.254.8.105:9081/test1/solService/getSol?userId=%1",
					
					"validateSolIdWithOrgSol":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/validateSolIdWithOrgSol?orgSolId=%1",
					
					"validateCustIdWithAccNo":ip+ "/TRADAXFinacleServicesPh4/IBCFinacleServices/validateCustIdWithAccNo?custId=%1&oprAccNo=%2",
					
					"commentsUrl":ip+"/commentPh4/viewComment",
					
					"checkListUrl":ip+"/commentPh4/viewCheckList",
					
					"STP_Data_Insertion":ip+"/irmstp/getStpStatus?widNo=%1",
					
					"getfincardrate":ip+"/getCardDetails?toCrncy=INR&frmCrncy=%1&rateCode=BLS&date=%2",
					
					"checkTBMLEnableSol":tbmlIP+"checkTBMLEnableSol?product=IBC&solId=%1",
					
					"insertTBMLData":tbmlIP+"insertTBMLData?wid=%1&product=%2&caseId=%3&solId=%4&custId=%5&vehicleNo1=%6&vehicleNo2=%7",
					
					"getProcessFlag":tbmlIP+"getProcessFlag?wid=%1",
					
					"getRefAccntNoDetails":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getRefAccntNoDetails?refAccntNo=%1",
					
					"getDetailsBasedOnDCNo":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getDetailsBasedOnLCNo?lcNo=%1",
					
					"validateForDueDate":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/validateForDueDate?todayDate=%1&month=%2&year=%3&solId=%4",
					
					"validateRTGSIFSCCode":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/validateRTGSIFSCCode?ifscCode=%1",
					
					"validateCustCategory":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/validateCustCategory?custId=%1",
					
					"getBICCode":ip+"/TRADAXFinacleServicesPh4/IBCFinacleServices/getBICCode?bankCode=%1&branchCode=%2",
					
					"EarlierWIDService":ip+"/EWIDService/EarlierWIDServices/fetchWIDDetails?widNoQueryString=%1&prefix=%2&caseType=%3",
					
					
					"EmailUrl": ip+"/Emailer/EmailServices/sendEmail?fromStep=%1&toStep=%2&action=%3&product=%4&wId=%5&caseId=%6"
			}
			
			return finacleUrls;
		}

	});
		
});