/* Scripts having all the OnLoad validation 04/11/2020 Version_2*/

/* Import here all the Modules used in your JS */
require(["icm/base/Constants", "icm/model/properties/controller/ControllerManager", "dojo/_base/lang", "dojo/_base/array"], function(Constants, ControllerManager, lang, array) {

    lang.setObject("IBC_OnLoad", {

        /* Method to return payload */
        "passthrough": function(payload, solution, role, scriptAdaptor) {
            return payload;
        },

        /* Main Method for OnLoad Scripts */
        "OnLoadAction": function(payload, solution, role, scriptAdaptor) {

            var self = scriptAdaptor;
            self.pg_UserId = ecm.model.desktop.userId;
            self.pg_UserName = ecm.model.desktop.userDisplayName;
            self.pg_coordination = payload.coordination;
            self.pg_solution = scriptAdaptor.solution;
            self.pg_prefix = scriptAdaptor.solution.getPrefix();
            self.pg_eventName = payload.eventName;
            self.pg_role = ecm.model.desktop.currentRole.name;

            if (self.pg_eventName == "icm.SendWorkItem") {
                var dailogMessage = "";
                self.pg_editable = payload.workItemEditable;

                /* Call Edit Response Script */
                IBC_EditResponse.OnEditResponseAction(self.pg_editable, self.pg_role);

                /* Before Load Coordination  */
                self.pg_coordination.participate(Constants.CoordTopic.BEFORELOADWIDGET,
                    function(context, complete, abort) {
                        /* Load Constatnt Urls */
                        var finUrls = IBC_TRADConstants.loadConstants();
                        lang.setObject("finUrls", finUrls);

                        /* Set some open POPup reference globally */
                        lang.setObject("comment_Childwindow");
                        lang.setObject("checklist_Childwindow");
                        //lang.setObject("doc_childwindow");
                        lang.setObject("childwindow");


                        /* Call the Choicelist Service */
                        var choiceListArray = ["ACCEPTANCE REJECTION REASON", "Bill Payable", "Bill Type", "Charge Event id", "Collection on Bill", "Customer Category", "DTFC DEEFERAL REASON", "DTFC HOLD REASON", "DTFC Hold Branch decision", "Devolved decision", "Discrepancy Status", "Entity Type", "FUNCTION", "Message Type", "Operation", "PAYMENT STATUS", "PURCHASE/SALE", "Processing Type", "Recovery", "Sanction Charges", "Stamp Duty Applicable", "Sub-Operation", "TOD/ Devolvement", "Tenor From", "Trash Reason", "Y/N Type", "YES/NO Type", "CBO Instruction", "Trade Portal_Operation", "Rejection Reason", "Rejection Category", "Recovery FUNCTION"];
                        ecm.model.Request.invokePluginService("ChoicelistFetch", "ChoicelistFetchService", {
                            requestParams: {
                                "solutionName": "IBC",
                                "choiceList": choiceListArray
                            },
                            backgroundRequest: false,
                            requestCompleteCallback: lang.hitch(this, function(response) {
                                /* console.log("Response::::"+response); */
                                /* console.dir(response); */
                                self.choiceItems = response;
                                lang.setObject("choiceItems", self.choiceItems);
                                console.log("choiceItems: ", self.choiceItems);
                                complete();
                            }),
                            requestFailedCallback: lang.hitch(this, function(response) {
                                /* failed */
                                console.log('Error in ChoicelistFetchService :: ' + response);
                                abort();

                            })
                        });

                        /* complete();  */
                    });

                /* After Load Coordination */
                self.pg_coordination.participate(Constants.CoordTopic.LOADWIDGET,
                    function(context, complete, abort) {
                        self.pg_editable = payload.workItemEditable;
                        self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);

                        var operationController = self.pg_propCollectionController.getPropertyController("COMMN_Operation");
                        var operation = operationController.get("value");
						var subOperation = getPropValue("COMMN_SubOperation");
                        var source = getPropValue("COMMN_Source");

                        /* Set ChoiceItems to PROPERTY_CONTROLLER */
                        for (i in self.choiceItems) {
                            if (self.choiceItems[i]['choiceName'] == "ACCEPTANCE REJECTION REASON") {
                                feedChoiceItems("COMMN_ACCEPTANCEREJECTIONREASON", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Rejection Reason") {
                                feedChoiceItems("COMMN_RejectionReason", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Bill Payable") {
                                feedChoiceItems("COMMN_BillPayable", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Bill Type") {
                                feedChoiceItems("COMMN_BillType", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Charge Event id") {
                                feedChoiceItems("COMMN_ChargeEventId", self.choiceItems[i]["choiceArray"]);


                            }
                            if (self.choiceItems[i]['choiceName'] == "Collection on Bill") {
                                feedChoiceItems("COMMN_CollectiononBill", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Customer Category") {
                                feedChoiceItems("COMMN_CustomerCategory", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "DTFC DEEFERAL REASON") {
                                feedChoiceItems("COMMN_DTFCDEEFERALREASON", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "DTFC HOLD REASON") {
                                feedChoiceItems("COMMN_DTFCHOLDREASON", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "DTFC Hold Branch decision") {
                                feedChoiceItems("COMMN_DTFCHoldBranchdecision", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Devolved decision") {
                                feedChoiceItems("COMMN_DevolvedDecision", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Discrepancy Status") {
                                feedChoiceItems("COMMN_DiscrepancyStatus", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Entity Type") {
                                feedChoiceItems("COMMN_EntityType", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "FUNCTION") {
                                feedChoiceItems("COMMN_FUNCTION", self.choiceItems[i]["choiceArray"]);
								feedChoiceItems("COMMN_Real_FUNCTION", self.choiceItems[i]["choiceArray"]);
								feedChoiceItems("COMMN_Accep_FUNCTION", self.choiceItems[i]["choiceArray"]);
								feedChoiceItems("COMMN_Dev_FUNCTION", self.choiceItems[i]["choiceArray"]);
							}
							  if (self.choiceItems[i]['choiceName'] == "Recovery FUNCTION") {
                                feedChoiceItems("COMMN_Re_FUNCTION", self.choiceItems[i]["choiceArray"]);
							}
							
                            if (self.choiceItems[i]['choiceName'] == "Message Type") {
                                feedChoiceItems("COMMN_MessageType", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Operation" && source != "Trade Prortal") {
                                feedChoiceItems("COMMN_Operation", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Trade Portal_Operation" && source == "Trade Portal") {
                                feedChoiceItems("COMMN_Operation", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "PAYMENT STATUS") {
                                feedChoiceItems("COMMN_PaymentStatus", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "PURCHASE/SALE") {
                                feedChoiceItems("COMMN_PURCHASESALE", self.choiceItems[i]["choiceArray"]);
								feedChoiceItems("COMMN_Dev_PURCHASESALE", self.choiceItems[i]["choiceArray"]);
                            }
                            if (self.choiceItems[i]['choiceName'] == "Processing Type") {
                                feedChoiceItems("COMMN_ProcessingType", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_Accep_ProcessingType", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_Real_ProcessingType", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_Dev_ProcessingType", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_Re_ProcessingType", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_Dis_ProcessingType", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_HSMG_ProcessingType", self.choiceItems[i]["choiceArray"]);


                            }
                            if (self.choiceItems[i]['choiceName'] == "Recovery") {
                                feedChoiceItems("COMMN_Recovery", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Sanction Charges") {
                                feedChoiceItems("COMMN_SanctionCharges", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Stamp Duty Applicable") {
                                feedChoiceItems("COMMN_StampDutyApplicable", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Sub-Operation") {
                                feedChoiceItems("COMMN_SubOperation", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "TOD/ Devolvement") {
                                feedChoiceItems("COMMN_TODDevolvement", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Tenor From") {
                                feedChoiceItems("COMMN_TenorFrom", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_DUEDATEIND", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Trash Reason") {
                                feedChoiceItems("COMMN_TrashReason", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Y/N Type") {
                                feedChoiceItems("COMMN_SanctionLetter", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_SanctionLetterAttached", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "YES/NO Type") {
                                feedChoiceItems("COMMN_InterestApplicable", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_TDSApplicable", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_GSTApplicable", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_DeferralPending", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_SFMSRequired", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_SFMSFlag", self.choiceItems[i]["choiceArray"]);
								/*
                               // feedChoiceItems("COMMN_TBMLEnableSOL", self.choiceItems[i]["choiceArray"]);
							   */
                                feedChoiceItems("COMMN_PaymentthroughTODInvocation", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_CMEFlag", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_MargintobeReleased", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_TransfertoNPAAccount", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_ChargeCollection", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_UNDERDOCUMENTRYCREDIT", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_Accep_SFMSFLAG", self.choiceItems[i]["choiceArray"]);
                                feedChoiceItems("COMMN_WhetherGapResolved", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "CBO Instruction") {
                                feedChoiceItems("COMMN_CBOInstruction", self.choiceItems[i]["choiceArray"]);

                            }
                            if (self.choiceItems[i]['choiceName'] == "Rejection Category") {
                                feedChoiceItems("COMMN_RejectionCategory", self.choiceItems[i]["choiceArray"]);

                            }

                        }

                        /*Set global value*/
                        var rejectionReason = getPropValue("COMMN_RejectionReason");
                        var rejectionReasonCount = rejectionReason.length;
                        lang.setObject("RejReasonCountOnLoad", rejectionReasonCount);
						
						var deferralReason = getPropValue("COMMN_DeferralReason");
						var deferralReasonCount = deferralReason.length;
                        lang.setObject("deferralReasonCountOnLoad", deferralReasonCount);
						
						var filterMsg1 = getPropValue("COMMN_FilterMessage_1");
						var filterMsg1Count = filterMsg1.length;
						lang.setObject("filterMsg1CountOnLoad", filterMsg1Count);

						var filterMsg2 = getPropValue("COMMN_FilterMessage_2");
						var filterMsg2Count = filterMsg2.length;
						lang.setObject("filterMsg2CountOnLoad", filterMsg2Count);

						var filterMsg3 = getPropValue("COMMN_FilterMessage_3");
						var filterMsg3Count = filterMsg3.length;
						lang.setObject("filterMsg3CountOnLoad", filterMsg3Count);

						var filterMsg4 = getPropValue("COMMN_FilterMessage_4");
						var filterMsg4Count = filterMsg4.length;
						lang.setObject("filterMsg4CountOnLoad", filterMsg4Count);

						var filterMsg5 = getPropValue("COMMN_FilterMessage_5");
						var filterMsg5Count = filterMsg5.length;
						lang.setObject("filterMsg5CountOnLoad", filterMsg5Count);

						var filterMsg6 = getPropValue("COMMN_FilterMessage_6");
						var filterMsg6Count = filterMsg6.length;
						lang.setObject("filterMsg6CountOnLoad", filterMsg6Count);

                        /* Freeze all the props */
                        freezeProps();

                        /* RoleWise Enable and Mandate Props */
                        /*All role Enable Mandate Props */
                        var mandateProps = ['COMMN_BillType'];
                        doPropsAction(mandateProps, "Mandate");

                        if (self.pg_role == "SOL MAKER") {
                            var subOperation = getPropValue("COMMN_SubOperation");

							setPropValue("COMMN_Accep_DOCUMENTSTYPE", '26');
                            setPropValue("COMMN_Accep_DOCUMENTSNO", '754');
                            setPropValue("COMMN_Accep_SFMSFLAG", 'Yes');
							setPropValue("COMMN_SFMSFlag", 'Yes');
							
                            /*Sub-Operation value set based on operation*/

                            if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                                setPropValue("COMMN_SubOperation", 'LODGMENT');
                            }

                            if (operation == 'ROLLOVER') {
                                setPropValue("COMMN_SubOperation", 'ROLLOVER');
                            }

                            var enableProps = ['COMMN_OriginSOLID', 'COMMN_CollectiononBill', 'COMMN_Custid', 'COMMN_OperativeAccountNo', 'COMMN_GSTNo', 'COMMN_BillPayable', 'COMMN_EarlierWID', 'COMMN_DocumentReceivedDate', 'COMMN_OtherBankRefno', 'COMMN_SignatureVerifiedbyEmployeeId'];

                            var mandateProps = ['COMMN_OriginSOLID','COMMN_Operation','COMMN_CollectiononBill','COMMN_Custid', 'COMMN_OperativeAccountNo','COMMN_GSTNo','COMMN_BillPayable', 'COMMN_DocumentReceivedDate','COMMN_OtherBankRefno', 'COMMN_Product', 'COMMN_SOLID','COMMN_Zone','COMMN_CustomerName','COMMN_CustTypeZone','COMMN_SegmentFinal', 'COMMN_CBOUnit','COMMN_Currency','COMMN_OperativeAccountName','COMMN_SelectedGSTNo','COMMN_GSTINDefaultFlagYesNo', 'COMMN_Country','COMMN_PaysisId','COMMN_PaymentStatus','COMMN_FinSTP_COUNTRY','COMMN_SignatureVerifiedbyEmployeeId'];

                            doPropsAction(enableProps, "enable");
                            doPropsAction(mandateProps, "Mandate");

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_StampDutyPaid', 'COMMN_RegisteredEmailid', 'COMMN_SanctionLetter', 'COMMN_SanctionLetterAttached', 'COMMN_TradePortalRefNo'];
								
                                var mandateProps = ['COMMN_StampDutyPaid', 'COMMN_FinSTP_OTHERBANKSREFNO', 'COMMN_OPERATIVEACID', 'COMMN_RegisteredEmailid', 'COMMN_DateandAmountofUtilization32ADate', 'COMMN_DateandAmountofUtilization32AINR','COMMN_FUNCTION','COMMN_BILLCCY','COMMN_CIFID','COMMN_FinSTP_BILLTYPE','COMMN_PAYSYSID','COMMN_ORIGINOFGOODS',
								'COMMN_PORTOFDESTINATION', 'COMMN_CONSIGNEECOUNTRY','COMMN_DOCUMENTSRECEIVEDON'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
							
							if (operation == 'LODGEMENT' && subOperation == 'DISHONOR') {
								var mandateProps = ['COMMN_Dis_FUNCTION'];
								doPropsAction(mandateProps, "Mandate");
							}
							
                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_StampDutyPaid', 'COMMN_AccountNotobeDebited', 'COMMN_RegisteredEmailid', 'COMMN_SanctionLetter', 'COMMN_SanctionLetterAttached','COMMN_SignatureVerifiedbyEmployeeId'];
								
                                var mandateProps = ['COMMN_StampDutyPaid', 'COMMN_AccountNotobeDebited', 'COMMN_FinSTP_OTHERBANKSREFNO', 'COMMN_OPERATIVEACID', 'COMMN_RegisteredEmailid', 'COMMN_SignatureVerifiedbyEmployeeId', 'COMMN_DateandAmountofUtilization32ADate', 'COMMN_DateandAmountofUtilization32AINR','COMMN_FUNCTION','COMMN_BILLCCY'
								,'COMMN_CIFID','COMMN_FinSTP_BILLTYPE','COMMN_PAYSYSID','COMMN_ORIGINOFGOODS','COMMN_PORTOFDESTINATION', 'COMMN_CONSIGNEECOUNTRY','COMMN_DOCUMENTSRECEIVEDON'];
								
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
                            if (operation == 'MISCELLANEOUS') {
                                var enableProps = ['COMMN_SubOperation'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }
                            if (operation == 'PRE-ACCEPTED' || operation == 'LODGEMENT') {
                                var sanctionLetter = getPropValue("COMMN_SanctionLetter");
                                if (sanctionLetter == 'Y') {
                                    var enableProps = ['COMMN_SanctionCharges'];
                                    var mandateProps = ['COMMN_SanctionCharges', 'COMMN_SanctionLetterAttached'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(mandateProps, "Mandate");
                                    customPopUpViewer("Please attach sanction letter");
                                }
                            }

                        }
                        if (self.pg_role == "SOL CHECKER") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            var enableProps = ['COMMN_TrashReason', 'COMMN_BANKCOVERLETTER', 'COMMN_BILLOFEXCHANGE', 'COMMN_UnderlyingDocuments',
                                'COMMN_TRANSPORTDOCUMENT', 'COMMN_OTHERDOCUMENTS', 'COMMN_DEBITNOTE', 'COMMN_ACCEPTANCELETTER'
                            ];
                            doPropsAction(enableProps, "enable");

                            var sanctionLetter = getPropValue("COMMN_SanctionLetter");
                            if (sanctionLetter == 'Y') {
                                customPopUpViewer("Please attach sanction letter");
                            }

                        }

                        if (self.pg_role == "DTFC OCR") {

                            var tfcFlag = getPropValue("COMMN_TFCDatacap_Done");
                            var source = getPropValue("COMMN_Source");
                            var queueID = getPropValue("COMMN_QueueID");
                            if (queueID && tfcFlag == true) {
                                performOCRTask();
                            } else if (!queueID) {
                                performOCRTask();
                            }

                        }

                        if (self.pg_role == "DTFC COMP") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            var enableProps = ['COMMN_CollectiononBill', 'COMMN_BillPayable', 'COMMN_DocumentaryCreditNoonBankCoverLetter', 'COMMN_OtherBankRefno', 'COMMN_ApplicantNameonInvoice', 'COMMN_BeneficiaryNameonInvoice', 'COMMN_TotalClaimedAmount', 'COMMN_IBCNumber', 'COMMN_SFMSRequired', 'COMMN_PlaceofExpiry', 'COMMN_LCExpiryDate'];

                            var mandateProps = ['COMMN_CollectiononBill', 'COMMN_BillPayable', 'COMMN_OtherBankRefno', 'COMMN_ApplicantNameonInvoice', 'COMMN_BeneficiaryNameonInvoice', 'COMMN_TotalClaimedAmount', 'COMMN_IBCNumber', 'COMMN_SFMSRequired'];

                            doPropsAction(enableProps, "enable");
                            doPropsAction(mandateProps, "Mandate");

                            if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                                var usanceDays = getPropValue("COMMN_UsanceDays");
                                if (usanceDays > 90) {
                                    var enableProps = ['COMMN_StampDutyApplicable', 'COMMN_StampDutyAmount'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }
							if(operation == 'CHARGE REVERSAL' || operation == 'LODGEMENT' || operation == 'ROLLOVER' ||  operation == 'MISCELLANEOUS'){
									var enableProps = ['COMMN_HSMG_SOLID','COMMN_HSMG_ENTITYTYPE','COMMN_HSMG_ENTITYID','COMMN_HSMG_PAYMENTSTATUS','COMMN_HSMG_RECEIVERBIC','COMMN_HSMG_RELATEDREF','COMMN_HSMG_NarrativeFreeText'];
									doPropsAction(enableProps, "enable");
									doPropsAction(enableProps, "Mandate");
							}

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DraftNo', 'COMMN_DraftDate', 'COMMN_DraftAmount', 'COMMN_InvoiceNo', 'COMMN_InvoiceDate', 'COMMN_InvoiceAmount', 'COMMN_LRGRBOLDate', 'COMMN_TenorFrom', 'COMMN_InterestApplicable', 'COMMN_PrincipleAmount','COMMN_DeferralPending', 'COMMN_GracePeriod', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_ChargeCollection', 'COMMN_UsanceDays', 'COMMN_TenorDiscription', 'COMMN_ProcessingType', 'COMMN_FinSTP_SOLID', 'COMMN_NAME', 'COMMN_ADDRESSLINE1', 'COMMN_ADDRESSLINE2', 'COMMN_ADDRESSLINE3', 'COMMN_CITY', 'COMMN_STATE', 'COMMN_POSTALCODE', 'COMMN_BANKCode', 'COMMN_BRANCHCode', 'COMMN_BIC', 'COMMN_BANK', 'COMMN_TENORDESC', 'COMMN_GRACEPERIODDDD', 'COMMN_DUEDATEIND', 'COMMN_ONBOARDDATE','COMMN_FinSTP_BIC', 'COMMN_FinSTP_CHARGEEVENTID', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo',  'COMMN_DCNumber', 'COMMN_BRANCH', 'COMMN_OurBankCharges', 'COMMN_ChargeDescreption', 'COMMN_DiscrepancyStatus', 'COMMN_Narrative77A'];

                                var mandateProps = ['COMMN_InvoiceNo', 'COMMN_InvoiceDate', 'COMMN_InvoiceAmount', 'COMMN_OtherBankAccountNo', 'COMMN_LRGRBOLDate', 'COMMN_TenorFrom', 'COMMN_InterestApplicable', 'COMMN_PrincipleAmount', 'COMMN_DeferralPending', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_ChargeCollection', 'COMMN_UsanceDays', 'COMMN_ProcessingType', 'COMMN_FinSTP_SOLID','COMMN_BANKCode', 'COMMN_BRANCHCode', 'COMMN_BIC', 'COMMN_BANK', 'COMMN_TENORDESC', 'COMMN_GRACEPERIODDDD', 'COMMN_ONBOARDDATE','COMMN_FinSTP_BIC', 'COMMN_FinSTP_CHARGEEVENTID', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo', 'COMMN_DateandAmountofUtilization32AAmount', 'COMMN_BILLAMOUNT', 'DC UTILIZATION AMOUNT', 'COMMN_INVOICEAMT', 'COMMN_FinSTP_INVOICENO', 'COMMN_FinSTP_INVOICEDATE','COMMN_DCNumber', 'COMMN_BRANCH', 'COMMN_OurBankCharges', 'COMMN_ChargeDescreption', 'COMMN_DiscrepancyStatus', 'COMMN_Narrative77A','COMMN_DUEDATEIND'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DraftNo', 'COMMN_DraftDate', 'COMMN_DraftAmount', 'COMMN_InvoiceNo', 'COMMN_InvoiceDate', 'COMMN_InvoiceAmount', 'COMMN_LRGRBOLDate', 'COMMN_TenorFrom', 'COMMN_InterestApplicable', 'COMMN_PrincipleAmount','COMMN_DeferralPending', 'COMMN_GracePeriod', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_UsanceDays', 'COMMN_TenorDiscription', 'COMMN_Narrative77A', 'COMMN_OtherMiscellaneousCharges', 'COMMN_ProcessingType', 'COMMN_FinSTP_SOLID', 'COMMN_NAME', 'COMMN_ADDRESSLINE1', 'COMMN_ADDRESSLINE2', 'COMMN_ADDRESSLINE3', 'COMMN_CITY', 'COMMN_STATE', 'COMMN_POSTALCODE', 'COMMN_BANKCode', 'COMMN_BRANCHCode', 'COMMN_BIC', 'COMMN_BANK', 'COMMN_TENORDESC', 'COMMN_GRACEPERIODDDD', 'COMMN_DUEDATEIND', 'COMMN_ONBOARDDATE', 'COMMN_FinSTP_BIC', 'COMMN_FinSTP_CHARGEEVENTID', 'COMMN_BRANCH', 'COMMN_OurBankCharges', 'COMMN_ChargeDescreption', 'COMMN_DiscrepancyStatus','COMMN_DCNumber'];

                                var mandateProps = ['COMMN_InvoiceNo', 'COMMN_InvoiceDate', 'COMMN_InvoiceAmount', 'COMMN_OtherBankAccountNo', 'COMMN_LRGRBOLDate', 'COMMN_TenorFrom', 'COMMN_InterestApplicable', 'COMMN_PrincipleAmount', 'COMMN_DeferralPending', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_UsanceDays', 'COMMN_Narrative77A', 'COMMN_OtherMiscellaneousCharges', 'COMMN_ProcessingType', 'COMMN_FinSTP_SOLID','COMMN_BANKCode', 'COMMN_BRANCHCode', 'COMMN_BIC', 'COMMN_BANK', 'COMMN_TENORDESC', 'COMMN_GRACEPERIODDDD', 'COMMN_ONBOARDDATE','COMMN_FinSTP_BIC', 'COMMN_FinSTP_CHARGEEVENTID', 'COMMN_DateandAmountofUtilization32AAmount', 'COMMN_BILLAMOUNT', 'DC UTILIZATION AMOUNT', 'COMMN_INVOICEAMT', 'COMMN_FinSTP_INVOICENO', 'COMMN_FinSTP_INVOICEDATE','COMMN_BRANCH', 'COMMN_OurBankCharges', 'COMMN_ChargeDescreption', 'COMMN_DiscrepancyStatus','COMMN_DCNumber','COMMN_DUEDATEIND'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'ROLLOVER') {
                                var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DraftNo', 'COMMN_DraftDate', 'COMMN_DraftAmount', 'COMMN_TenorFrom', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_UsanceDays', 'COMMN_TenorDiscription', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo'];

                                var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_TenorFrom', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_UsanceDays', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'MISCELLANEOUS' && subOperation == 'ACCEPTANCE') {
                                var enableProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                                var mandateProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'MISCELLANEOUS' && subOperation == 'DISHONOR') {
                                var enableProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                                var mandateProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo']

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'MISCELLANEOUS') {
                                var enableProps = ['COMMN_ChargeCollection','COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo'];

                                var mandateProps = ['COMMN_ChargeCollection','COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') {
                                var enableProps = ['COMMN_OtherMiscellaneousCharges'];

                                var mandateProps = ['COMMN_OtherMiscellaneousCharges'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && (subOperation == 'REALIZATION' || subOperation == 'ROLLOVER')) {
                                var enableProps = ['COMMN_OtherMiscellaneousCharges'];
                                var mandateProps = ['COMMN_OtherMiscellaneousCharges'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'CHARGE REVERSAL') {
                                var enableProps = ['COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }

                            if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR')) || operation == 'PRE-ACCEPTED' || operation == 'MISCELLANEOUS' || operation == 'ROLLOVER') {
                                var msgTypeValue = getPropValue("COMMN_MessageType");

                            var sfmsRequired = getPropValue("COMMN_SFMSRequired");
							if (msgTypeValue != '412' && sfmsRequired == 'Yes') {
                                    var enableProps = ['COMMN_Narrative'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }

                            var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                            if (collectionOnBill == 'Backed by LC') {
                                doPropsAction(["COMMN_PlaceofExpiry", "COMMN_LCExpiryDate"], "Mandate");
                            }
                        }

						if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
							var collectionOnBill = getPropValue('COMMN_CollectiononBill');
							if (collectionOnBill == 'Backed by LC') {
								setPropValue("COMMN_UNDERDOCUMENTRYCREDIT", 'Yes');
							}
						}
						
                        if (self.pg_role == "TF CONNECT ACCEPTANCE") {
                            var enableProps = ['COMMN_EarlierWID'];
                            doPropsAction(enableProps, "enable");
                        }

                        if (self.pg_role == "BRANCH HOLD") {
                            doPropsAction(["COMMN_CollectiononBill"], "enable");
                            doPropsAction(["COMMN_CollectiononBill"], "Mandate");

                            if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_SanctionLetterAttached', 'COMMN_SanctionLetter'];
                                doPropsAction(enableProps, "enable");
                                
                                var sanctionLetter = getPropValue("COMMN_SanctionLetter");
                                if (sanctionLetter == 'Y') {
                                    doPropsAction(['COMMN_SanctionLetterAttached'], "Mandate");
                                }
                            }


                        }

                        if (self.pg_role == "FIN ENTRY") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            var enableProps = ['COMMN_IBCNumber'];
                            var mandateProps = ['COMMN_IBCNumber'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(mandateProps, "Mandate");

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_ProcessingType', 'COMMN_FinSTP_SOLID','COMMN_DCNumber'];
                                var mandateProps = ['COMMN_ProcessingType', 'COMMN_FinSTP_SOLID','COMMN_DCNumber'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_ProcessingType', 'COMMN_FinSTP_SOLID','COMMN_DCNumber'];
                                var mandateProps = ['COMMN_ProcessingType', 'COMMN_FinSTP_SOLID','COMMN_DCNumber'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                        }

                        if (self.pg_role == "DTFC HOLD") {
                            if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_DTFCHoldBranchdecision'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }

                            var branchDecision = getPropValue('COMMN_DTFCHoldBranchdecision');
                            var subOperation = getPropValue('COMMN_SubOperation');
                            if (branchDecision == 'Return Document' || subOperation == 'DISHONOR') {
                                var enableProps = ['COMMN_CourierNo', 'COMMN_CourierCoName', 'COMMN_DateofReturn'];
                                doPropsAction(enableProps, "enable");
                            }
                        }

                        if (self.pg_role == "BR ACCEPT MAKER") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            var enableProps = ['COMMN_SubOperation', 'COMMN_EarlierWID', 'COMMN_SignatureVerifiedbyEmployeeId'];

                            var mandateProps = ['COMMN_SubOperation','COMMN_SignatureVerifiedbyEmployeeId'];

                            doPropsAction(enableProps, "enable");
                            doPropsAction(mandateProps, "Mandate");

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_TradePortalRefNo'];
                                doPropsAction(enableProps, "enable");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var mandateProps = ['COMMN_SignatureVerifiedbyEmployeeId'];
                                doPropsAction(mandateProps, "Mandate");
								doPropsAction(mandateProps, "enable");
                            }

                            if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'REALIZATION' || subOperation == 'ROLLOVER'))) {
                                var enableProps = ['COMMN_AccountNotobeDebited'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }

                            var branchDecision = getPropValue('COMMN_DTFCHoldBranchdecision');
                            var subOperation = getPropValue('COMMN_SubOperation');
                            if (branchDecision == 'Return Document' || subOperation == 'DISHONOR') {
                                var enableProps = ['COMMN_CourierNo', 'COMMN_CourierCoName', 'COMMN_DateofReturn'];
                                doPropsAction(enableProps, "enable");
                            }

                        }

                        if (self.pg_role == "BILL ACCEPTANCE") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            var enableProps = ['COMMN_SubOperation', 'COMMN_OtherBankRefno', 'COMMN_SFMSRequired'];

                            var mandateProps = ['COMMN_SubOperation', 'COMMN_OtherBankRefno', 'COMMN_SFMSRequired'];

                            doPropsAction(enableProps, "enable");
                            doPropsAction(mandateProps, "Mandate");

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_ChargeCollection', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID', 'COMMN_OurBankCharges', 'COMMN_Narrative77A'];

                                var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_ChargeCollection','COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID','COMMN_OurBankCharges', 'COMMN_Narrative77A']

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_Narrative77A', 'COMMN_OtherMiscellaneousCharges', 'COMMN_OurBankCharges'];

                                var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_Narrative77A', 'COMMN_OtherMiscellaneousCharges', 'COMMN_OurBankCharges'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'ROLLOVER') {
                                var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID'];

                                var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo', 'COMMN_HSMG_PAYSISID'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'MISCELLANEOUS' && subOperation == 'ACCEPTANCE') {
                                var enableProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                                var mandateProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'MISCELLANEOUS' && subOperation == 'DISHONOR') {
                                var enableProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                                var mandateProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo']

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') {
                                var enableProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_RolloverInterestAmount', 'COMMN_RolloverIBCNo', 'COMMN_OtherMiscellaneousCharges', 'COMMN_Accep_ACCEPTANCEDATE', 'COMMN_DISCREPANCIES', 'COMMN_Accep_DOCUMENTSTYPE', 'COMMN_Accep_DOCUMENTSNO', 'COMMN_AMT', 'COMMN_Accep_SFMSFLAG', 'COMMN_Accep_CHARGEEVENTID', 'COMMN_Accep_PAYSYSID', 'COMMN_Accep_ProcessingType'];

                                var mandateProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_SELECTEDACCEPTANCEREJECTIONREASON', 'COMMN_OtherMiscellaneousCharges', 'COMMN_Accep_ACCEPTANCEDATE', 'COMMN_DISCREPANCIES', 'COMMN_Accep_DOCUMENTSTYPE', 'COMMN_Accep_DOCUMENTSNO', 'COMMN_AMT', 'COMMN_Accep_SFMSFLAG', 'COMMN_Accep_CHARGEEVENTID', 'COMMN_Accep_PAYSYSID', 'COMMN_Accep_ProcessingType','COMMN_Accep_FUNCTION'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'ROLLOVER') {
                                var enableProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_RolloverInterestAmount', 'COMMN_RolloverIBCNo', 'COMMN_OtherMiscellaneousCharges'];

                                var mandateProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_SELECTEDACCEPTANCEREJECTIONREASON', 'COMMN_OtherMiscellaneousCharges'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'DISHONOR') {
                                var enableProps = ['COMMN_ACCEPTANCEREJECTIONREASON','COMMN_Dis_ProcessingType', 'COMMN_RolloverInterestAmount', 'COMMN_RolloverIBCNo','COMMN_Dis_CHARGEEVENTID'];

                                var mandateProps = ['COMMN_ACCEPTANCEREJECTIONREASON', 'COMMN_Postage','COMMN_Dis_ProcessingType', 'COMMN_SELECTEDACCEPTANCEREJECTIONREASON','COMMN_Dis_CHARGEEVENTID','COMMN_Dis_FUNCTION'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'MISCELLANEOUS') {
                                var enableProps = ['COMMN_ChargeCollection', 'COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID'];

                                var mandateProps = ['COMMN_ChargeCollection','COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
                                var mandateProps = ['COMMN_OtherMiscellaneousCharges'];

                                var enableProps = ['COMMN_OtherMiscellaneousCharges'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'CHARGE REVERSAL') {
                                var enableProps = ['COMMN_HSMG_ProcessingType', 'COMMN_HSMG_FinacleRefNo','COMMN_HSMG_PAYSISID'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }

                            if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR')) || operation == 'PRE-ACCEPTED' || operation == 'MISCELLANEOUS' || operation == 'ROLLOVER') {
                                var msgTypeValue = getPropValue("COMMN_MessageType");

                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
								if (msgTypeValue != '412' && sfmsRequired == 'Yes') {
                                    var enableProps = ['COMMN_Narrative'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }
							
							if ((operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') || operation == 'PRE-ACCEPTED') {
								var mandateProps = ['COMMN_Accep_ACCEPTANCEDATE','COMMN_SignatureVerifiedbyEmployeeId'];
								doPropsAction(mandateProps, "Mandate");
							}
							
							if(operation == 'CHARGE REVERSAL' || operation == 'LODGEMENT' || operation == 'ROLLOVER' ||  operation == 'MISCELLANEOUS'){
									var enableProps = ['COMMN_HSMG_SOLID','COMMN_HSMG_ENTITYTYPE','COMMN_HSMG_ENTITYID','COMMN_HSMG_PAYMENTSTATUS','COMMN_HSMG_RECEIVERBIC','COMMN_HSMG_RELATEDREF','COMMN_HSMG_NarrativeFreeText'];
									doPropsAction(enableProps, "enable");
									doPropsAction(enableProps, "Mandate");
							}
                        }

                        if (self.pg_role == "ACCEPTANCE FIN ENTRY") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            if (operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'ROLLOVER' || subOperation == 'DISHONOR')) {
                                var enableProps = ['COMMN_RolloverInterestAmount', 'COMMN_RolloverIBCNo'];
                                doPropsAction(enableProps, "enable");
                            }

                            if (operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'ROLLOVER' || subOperation == 'REALIZATION')) {
                                var enableProps = ['COMMN_OtherMiscellaneousCharges'];
                                var mandateProps = ['COMMN_OtherMiscellaneousCharges'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_OtherMiscellaneousCharges'];
                                var mandateProps = ['COMMN_OtherMiscellaneousCharges'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
                        }

                        if (self.pg_role == "ACCEPTANCE FIN AUTH") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            if (operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'ROLLOVER' || subOperation == 'DISHONOR')) {
                                var enableProps = ['COMMN_RolloverInterestAmount'];
                                doPropsAction(enableProps, "enable");
                            }
                        }

                        if (self.pg_role == "ACCEPTANCE SFMS AUTH") {
                            var enableProps = ['COMMN_SubOperation'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(enableProps, "Mandate");

                        }
						
						if (self.pg_role == "SFMS AUTH") {
                            var enableProps = ['COMMN_DTFCHOLDREASON'];
                            doPropsAction(enableProps, "enable");
                        }
						

                        if (self.pg_role == "PENDING REALISATION") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            var enableProps = ['COMMN_OtherBankRefno'];

                            var mandateProps = ['COMMN_OtherBankRefno'];

                            doPropsAction(enableProps, "enable");
                            doPropsAction(mandateProps, "Mandate");

                            if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
                                var enableProps = ['COMMN_DTFCDEEFERALREASON', 'COMMN_AccountNotobeCredited', 'COMMN_OtherMiscellaneousCharges', 'COMMN_Real_REALIZATIONACCOUNTID', 'COMMN_Real_BILLREALIZATIONAMT', 'COMMN_Real_PAYMENTAMT', 'COMMN_OTHERBANKINTERESTAMT', 'COMMN_Real_COMMISSION', 'COMMN_PURCHASESALE', 'COMMN_Real_ACID', 'COMMN_Real_IMMEDIATECOLLECTIONAMT', 'COMMN_Real_IMMEDIATECOLLECTIONAMTGST', 'COMMN_Real_IMMEDIATECOLLECTIONAMTPostage', 'COMMN_Real_IMMEDIATECOLLECTIONAMTPostageGST', 'COMMN_Real_IMMEDIATECOLLECTIONAMTSFMS', 'COMMN_Real_IMMEDIATECOLLECTIONAMTSFMSGST', 'COMMN_Real_ProcessingType','COMMN_Real_FUNCTION','COMMN_Real_CHARGEEVENTID'];

                                var mandateProps = ['COMMN_OtherMiscellaneousCharges','COMMN_Real_REALIZATIONACCOUNTID', 'COMMN_Real_BILLREALIZATIONAMT', 'COMMN_Real_PAYMENTAMT', 'COMMN_OTHERBANKINTERESTAMT', 'COMMN_Real_COMMISSION', 'COMMN_PURCHASESALE', 'COMMN_Real_ACID', 'COMMN_Real_ProcessingType', 'COMMN_AccountNotobeCredited','COMMN_Real_FUNCTION','COMMN_Real_CHARGEEVENTID'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");

                                var realFunction = self.pg_propCollectionController.getPropertyController("COMMN_Real_FUNCTION");
                                var realFunctionValue = realFunction.get("value");
                                if (realFunctionValue != 'R') {
                                    var enableProps = ['COMMN_Dev_DELINKACCOUNTNO', 'COMMN_Dev_REALIZATIONACID', 'COMMN_Dev_PURCHASESALE', 'COMMN_Dev_ACID','COMMN_Dev_CHARGEEVENTID'];
                                    doPropsAction(enableProps, "enable");
                                }

                            }

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_ChargeCollection','COMMN_Dev_ProcessingType','COMMN_Dev_DELINKACCOUNTNO','COMMN_Dev_REALIZATIONACID','COMMN_Dev_PURCHASESALE','COMMN_Dev_ACID','COMMN_Dev_CHARGEEVENTID'];

                                var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_ChargeCollection','COMMN_Dev_ProcessingType','COMMN_Dev_DELINKACCOUNTNO','COMMN_Dev_REALIZATIONACID','COMMN_Dev_PURCHASESALE','COMMN_Dev_ACID','COMMN_Dev_CHARGEEVENTID'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_RTGSIFSCode', 'COMMN_AccountNotobeCredited', 'COMMN_ChargeCollection', 'COMMN_OtherMiscellaneousCharges','COMMN_Dev_ProcessingType', 'COMMN_DTFCDEEFERALREASON','COMMN_Dev_DELINKACCOUNTNO','COMMN_Dev_REALIZATIONACID','COMMN_Dev_PURCHASESALE','COMMN_Dev_ACID','COMMN_Dev_CHARGEEVENTID'];

                                var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_OtherMiscellaneousCharges','COMMN_Dev_ProcessingType','COMMN_AccountNotobeCredited','COMMN_Dev_DELINKACCOUNTNO','COMMN_Dev_REALIZATIONACID','COMMN_Dev_PURCHASESALE','COMMN_Dev_ACID','COMMN_Dev_CHARGEEVENTID'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");

                            }

                            if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                                var devDecision = self.pg_propCollectionController.getPropertyController("COMMN_DevolvedDecision");
                                var devDecisionValue = devDecision.get("value");
                                if (devDecisionValue == 'Devolvement' || devDecisionValue == 'Open New Devolvement account' || devDecisionValue == 'Existing Devolvement Account' || devDecisionValue == 'TOD') {
                                    var mandateProps = ['COMMN_Dev_FUNCTION'];
                                    doPropsAction(mandateProps, "Mandate");
                                }
                            }

                            if (operation == 'ROLLOVER') {
                                var enableProps = ['COMMN_OtherBankAccountNo'];

                                var mandateProps = ['COMMN_OtherBankAccountNo'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') {
                                var enableProps = ['COMMN_AccountNotobeCredited', 'COMMN_OtherMiscellaneousCharges', 'COMMN_ProcessingType'];

                                var mandateProps = ['COMMN_OtherMiscellaneousCharges', 'COMMN_ProcessingType', 'COMMN_AccountNotobeCredited'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'MISCELLANEOUS') {
                                var enableProps = ['COMMN_ChargeCollection'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && (subOperation == 'ROLLOVER')) {
                                var enableProps = ['COMMN_AccountNotobeCredited', 'COMMN_OtherMiscellaneousCharges'];

                                var mandateProps = ['COMMN_OtherMiscellaneousCharges', 'COMMN_AccountNotobeCredited'];


                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && (subOperation == 'REALIZATION' || subOperation == 'ROLLOVER' || subOperation == 'ACCEPTANCE')) {
                                var enableProps = ['COMMN_RTGSIFSCode'];
                                var mandateProps = ['COMMN_RTGSIFSCode'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
							
							var cboInstruction = getPropValue("COMMN_CBOInstruction");
							if ((operation == 'LODGEMENT' && subOperation == 'REALIZATION') || operation == 'PRE-ACCEPTED') {
							
								if (cboInstruction == 'OPEN DEVOLVMENT ACCOUNT') {
									var enableProps = ['COMMN_CMEFlag','COMMN_NewDevolvementAccountNo'];
									var mandateProps = ['COMMN_CMEFlag'];
									
									doPropsAction(enableProps, "enable");
									doPropsAction(mandateProps, "Mandate");
								}
							}
						}

                        if (self.pg_role == "CBO") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_NormalInterestRate', 'COMMN_PenalInterestRate'];
                                doPropsAction(enableProps, "enable");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_CBOInstruction', 'COMMN_NormalInterestRate', 'COMMN_PenalInterestRate', 'COMMN_CBORemarks', 'COMMN_MargintobeReleased', 'COMMN_TransfertoNPAAccount', 'COMMN_Writeoff', 'COMMN_TODDevolvement', 'COMMN_AmounttobeRecover', 'COMMN_AccountNofromAmounttobeRecover'];

                                var mandateProps = ['COMMN_CBOInstruction', 'COMMN_MargintobeReleased', 'COMMN_TODDevolvement'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
							if(((subOperation=="REALIZATION"||subOperation=="RECOVERY")&&operation=="LODGEMENT")|| operation == 'PRE-ACCEPTED'||operation == 'ROLLOVER'){
								doPropsAction(["COMMN_Recovery"], "enable");
                                doPropsAction(["COMMN_Recovery"], "Mandate");
							}

                            if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
                                var enableProps = ['COMMN_CBOInstruction', 'COMMN_AmounttobeRecover', 'COMMN_AccountNofromAmounttobeRecover', 'COMMN_CBORemarks', 'COMMN_MargintobeReleased', 'COMMN_TransfertoNPAAccount', 'COMMN_Writeoff', 'COMMN_TODDevolvement'];

                                var mandateProps = ['COMMN_CBOInstruction', 'COMMN_MargintobeReleased', 'COMMN_TODDevolvement'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'RECOVERY') {
                                var enableProps = ['COMMN_AmounttobeRecover', 'COMMN_AccountNofromAmounttobeRecover', 'COMMN_CBORemarks', 'COMMN_MargintobeReleased', 'COMMN_TransfertoNPAAccount', 'COMMN_Writeoff', 'COMMN_TODDevolvement'];

                                var mandateProps = ['COMMN_MargintobeReleased', 'COMMN_TODDevolvement'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            var cboInstruction = getPropValue("COMMN_CBOInstruction");
                            if ((operation == 'LODGEMENT' && subOperation == 'REALIZATION') || operation == 'PRE-ACCEPTED') {
                                if (cboInstruction == 'EXISTING DEVOLVMENT ACCOUNT') {
                                    var enableProps = ['COMMN_ExistingAccountNo', 'COMMN_ExisitingDevolvmentAccountName'];
                                    doPropsAction(enableProps, "enable");
                                }

                                if (cboInstruction == 'OPEN DEVOLVMENT ACCOUNT') {
                                    var enableProps = ['COMMN_RefAccountNo', 'COMMN_SanctionLimit', 'COMMN_LimitId', 'COMMN_LimitIdSuffix', 'COMMN_InterestRateCode', 'COMMN_AcctLabel', 'COMMN_SectorCode', 'COMMN_SubSectorCode', 'COMMN_OccupationCode', 'COMMN_PurposeofAdvance', 'COMMN_ModeofAdvance', 'COMMN_TypeofAdvance', 'COMMN_NatureofAdvance', 'COMMN_GuaranteeCoverCode', 'COMMN_IndustryType', 'COMMN_LedgerNo', 'COMMN_ModeofOperation', 'COMMN_SanctionDate', 'COMMN_ExpiryDate', 'COMMN_CBO_DocumentDate', 'COMMN_ReviewDate', 'COMMN_SactionLevel', 'COMMN_SanctionAuthority', 'COMMN_LimitRefNo', 'COMMN_DrawingPowerInd', 'COMMN_DrawingPower', 'COMMN_BorrowerCategory', 'COMMN_AcctPrefIntDr', 'COMMN_IntDrAcFlag', 'COMMN_CMEFlag'];

                                    var mandateProps = ['COMMN_RefAccountNo', 'COMMN_SanctionLimit', 'COMMN_LimitId', 'COMMN_LimitIdSuffix', 'COMMN_InterestRateCode', 'COMMN_AcctLabel', 'COMMN_SectorCode', 'COMMN_SubSectorCode', 'COMMN_OccupationCode', 'COMMN_PurposeofAdvance', 'COMMN_ModeofAdvance', 'COMMN_TypeofAdvance', 'COMMN_NatureofAdvance', 'COMMN_GuaranteeCoverCode', 'COMMN_IndustryType', 'COMMN_LedgerNo', 'COMMN_ModeofOperation', 'COMMN_SanctionDate', 'COMMN_ExpiryDate', 'COMMN_CBO_DocumentDate', 'COMMN_ReviewDate', 'COMMN_SactionLevel', 'COMMN_SanctionAuthority', 'COMMN_LimitRefNo', 'COMMN_DrawingPowerInd', 'COMMN_DrawingPower', 'COMMN_BorrowerCategory', 'COMMN_AcctPrefIntDr', 'COMMN_IntDrAcFlag', 'COMMN_CMEFlag'];

                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(mandateProps, "Mandate");
                                }
                            }
                        }

                        if (self.pg_role == "REALISATION FIN ENTRY") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_DTFCDEEFERALREASON'];
                                doPropsAction(enableProps, "enable");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
                                var enableProps = ['COMMN_DTFCDEEFERALREASON'];
                                doPropsAction(enableProps, "enable");
                            }
							
							var cboInstruction = getPropValue("COMMN_CBOInstruction");
							if ((operation == 'LODGEMENT' && subOperation == 'REALIZATION') || operation == 'PRE-ACCEPTED') {
							
								if (cboInstruction == 'OPEN DEVOLVMENT ACCOUNT') {
									var enableProps = ['COMMN_NewDevolvementAccountNo'];
									doPropsAction(enableProps, "enable");
								}
						
							}

                        }

                        if (self.pg_role == "REALISATION FIN AUTH") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_PaymentthroughTODInvocation', 'COMMN_HPORDMNO', 'COMMN_DTFCDEEFERALREASON'];
                                var mandateProps = ['COMMN_PaymentthroughTODInvocation', 'COMMN_HPORDMNO'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");

                            }

                            if (operation == 'LODGEMENT' && subOperation == 'ROLLOVER') {
                                var enableProps = ['COMMN_PaymentthroughTODInvocation', 'COMMN_HPORDMNO'];
                                var mandateProps = ['COMMN_PaymentthroughTODInvocation', 'COMMN_HPORDMNO'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
                                var enableProps = ['COMMN_DTFCDEEFERALREASON', 'COMMN_PaymentthroughTODInvocation', 'COMMN_HPORDMNO'];
                                var mandateProps = ['COMMN_PaymentthroughTODInvocation', 'COMMN_HPORDMNO'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
							
							var cboInstruction = getPropValue("COMMN_CBOInstruction");
							if ((operation == 'LODGEMENT' && subOperation == 'REALIZATION') || operation == 'PRE-ACCEPTED') {
							
								if (cboInstruction == 'OPEN DEVOLVMENT ACCOUNT') {
									var enableProps = ['COMMN_NewDevolvementAccountNo'];
									doPropsAction(enableProps, "enable");
								}
						
							}
                        }

                        if (self.pg_role == "RTGS ENTRY") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
                                var enableProps = ['COMMN_DTFCDEEFERALREASON'];
                                doPropsAction(enableProps, "enable");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_DTFCDEEFERALREASON'];
                                doPropsAction(enableProps, "enable");
                            }

                        }

                        if (self.pg_role == "RTGS AUTH") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            if ((operation == 'LODGEMENT' && (subOperation == 'ROLLOVER' || subOperation == 'REALIZATION'))) {
                                var enableProps = ['COMMN_UTRNO'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_DeferralPending'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'ROLLOVER') {
                                var enableProps = ['COMMN_PaymentthroughTODInvocation'];
                                var mandateProps = ['COMMN_PaymentthroughTODInvocation'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
                                var enableProps = ['COMMN_DTFCDEEFERALREASON', 'COMMN_PaymentthroughTODInvocation'];
                                var mandateProps = ['COMMN_PaymentthroughTODInvocation'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_DeferralPending', 'COMMN_PaymentthroughTODInvocation', 'COMMN_UTRNO', 'COMMN_DTFCDEEFERALREASON'];
                                var mandateProps = ['COMMN_DeferralPending', 'COMMN_PaymentthroughTODInvocation', 'COMMN_UTRNO']

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if ((operation == 'LODGEMENT' && subOperation == 'REALIZATION') || operation == 'PRE-ACCEPTED') {
                                var deferralPending = getPropValue('COMMN_DeferralPending');
                                if (deferralPending == 'Yes') {
                                    var mandateProps = ['COMMN_DTFCDEEFERALREASON'];
                                    doPropsAction(mandateProps, "Mandate");
                                }
                            }

                            if (operation == 'LODGEMENT' && subOperation == 'REALIZATION') {
                                var enableProps = ['COMMN_DTFCDEEFERALREASON'];
                                doPropsAction(enableProps, "enable");
                            }
                        }

                        if (self.pg_role == "DEVOLVED") {
                            var subOperation = getPropValue("COMMN_SubOperation");

                            var enableProps = ['COMMN_SubOperation'];
                            doPropsAction(enableProps, "enable");
                            doPropsAction(enableProps, "Mandate");

                            if (operation == 'LODGEMENT') {
                                var enableProps = ['COMMN_DevolvedDecision'];
                                var mandateProps = ['COMMN_DevolvedDecision'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_DevolvedDecision', 'COMMN_AmounttobeRecover', 'COMMN_AccountNofromAmounttobeRecover'];

                                var mandateProps = ['COMMN_AccountName'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if ((operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') && subOperation == 'RECOVERY') {
                                var enableProps = ['COMMN_Re_RECOVERYAMOUNT','COMMN_Re_ProcessingType','COMMN_Re_FUNCTION','COMMN_Re_CHARGEEVENTID'];

                                var mandateProps = ['COMMN_Re_RECOVERYAMOUNT','COMMN_Re_ProcessingType','COMMN_Re_FUNCTION','COMMN_Re_CHARGEEVENTID'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
							if(((subOperation=="REALIZATION"||subOperation=="RECOVERY")&&operation=="LODGEMENT")|| operation == 'PRE-ACCEPTED'||operation == 'ROLLOVER'){
								doPropsAction(["COMMN_Recovery"], "enable");
                                doPropsAction(["COMMN_Recovery"], "Mandate");
							}
                            if (operation == 'LODGEMENT' && (subOperation == 'RECOVERY' || subOperation == 'REALIZATION')) {
                                var mandateProps = ['COMMN_AmounttobeRecover', 'COMMN_AccountNofromAmounttobeRecover', 'COMMN_AccountName'];
                                doPropsAction(mandateProps, "Mandate");

                                var enableProps = ['COMMN_AccountNofromAmounttobeRecover', 'COMMN_AmounttobeRecover'];
                                doPropsAction(enableProps, "enable");
                            }

                            if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR')) || operation == 'PRE-ACCEPTED' || operation == 'MISCELLANEOUS' || operation == 'ROLLOVER') {
                                var msgTypeValue = getPropValue("COMMN_MessageType");

                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
								if (msgTypeValue != '412' && sfmsRequired == 'Yes') {
                                    var enableProps = ['COMMN_Narrative'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }
                        }

                        if (self.pg_role == "TBML") {
                            if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                                var enableProps = ['COMMN_TBMLStatus', 'COMMN_TBMLRemarks', 'COMMN_TBMLEnableSOL', 'COMMN_TBMLDecision'];
                                doPropsAction(enableProps, "enable");
                            }

                        }

                        if (self.pg_role == "DTFC COMP" || self.pg_role == "FIN AUTH") {
                            var collectionOnBill = getPropValue('COMMN_CollectiononBill');
                            if (collectionOnBill == 'Non LC') {
                                var applicantNameonInvoice = getPropValue('COMMN_ApplicantNameonInvoice');
                                var operativeAcctName = getPropValue('COMMN_OperativeAccountName');
								if(applicantNameonInvoice != null && operativeAcctName != null){
									if (applicantNameonInvoice != operativeAcctName) {
										customPopUpViewer("Applicant Name on Invoice and Operative Account Name should be same, please check");
									}
								}
                            }
                        }


                        if (self.pg_role == "DTFC COMP" && (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED')) {
                            var collectionOnBillCntrl = self.pg_propCollectionController.getPropertyController("COMMN_CollectiononBill");
                            var collectionOnBill = collectionOnBillCntrl.get("value");
                            if (collectionOnBill == 'Backed by LC') {
                                
                                var enableProps = ['COMMN_DocumentaryCreditNoonBOE', 'COMMN_BankCoverLetterDate', 'COMMN_LatestShipmentDate', 'COMMN_DescreptionofDiscrepancyCharges', 'COMMN_GSTAmount', 'COMMN_OtherBankCharges', 'COMMN_DCUtilizationAmount'];
                                doPropsAction(enableProps, "enable");
                                var mandateProps = ['COMMN_DocumentaryCreditNoonBOE', 'COMMN_BankCoverLetterDate', 'COMMN_LatestShipmentDate', 'COMMN_DescreptionofDiscrepancyCharges', 'COMMN_DCUtilizationAmount', 'COMMN_OtherBankCharges'];
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if (collectionOnBill == 'Non LC' || collectionOnBill == 'NON LC') {
                                var enableProps = ['COMMN_BeneficiaryAddress', 'COMMN_BeneficiaryCity', 'COMMN_BeneficiaryState', 'COMMN_BeneficiaryPostalCode'];
                                doPropsAction(enableProps, "enable");

                                var mandateProps = ['COMMN_BILLAMT', 'COMMN_OTHERBANKSREFNO','COMMN_BeneficiaryAddress', 'COMMN_BeneficiaryCity', 'COMMN_NAME', 'COMMN_ADDRESSLINE1', 'COMMN_ADDRESSLINE2', 'COMMN_ADDRESSLINE3', 'COMMN_CITY', 'COMMN_STATE', 'COMMN_POSTALCODE'];
                                doPropsAction(mandateProps, "Mandate");
                            }


                            var stampDutyPaidValue = getPropValue('COMMN_StampDutyPaid');
                            var stampDutyAmtValue = getPropValue('COMMN_StampDutyAmount');
							var stampDutyPaid = parseFloat(stampDutyPaidValue);
							var stampDutyAmt = parseFloat(stampDutyAmtValue);
							if(stampDutyPaid != null && stampDutyAmt != null){
								if (stampDutyPaid < stampDutyAmt) {
									customPopUpViewer("Stamp Duty paid is less than stamp duty amt, please check");
								}
							}
                            
                            var interestApplicable = getPropValue("COMMN_InterestApplicable");
                            if (interestApplicable == 'Yes') {
                                var enableProps = ['COMMN_InterestRate', 'COMMN_GrossInterestAmount', 'COMMN_TDSApplicable', 'COMMN_TDSAmount', 'COMMN_GSTApplicable', 'COMMN_GSTAmount', 'COMMN_NetInterestAmount'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }

                        }

                        if (self.pg_role == "BR ACCEPT MAKER" || self.pg_role == "DTFC HOLD") {
                            var branchDecision = getPropValue('COMMN_DTFCHoldBranchdecision');
                            var subOperation = getPropValue('COMMN_SubOperation');
                            if (branchDecision == 'Return Document' || branchDecision == 'RETURN DOCUMENT' || subOperation == 'DISHONOR') {
                                var enableProps = ['COMMN_CourierNo', 'COMMN_CourierCoName', 'COMMN_DateofReturn'];
                                doPropsAction(enableProps, "enable");
                            }
                        }

                        /*Grid enable*/

                        if (self.pg_role == "BILL ACCEPTANCE" || self.pg_role == "DTFC HOLD" || self.pg_role == "BRANCH HOLD" || self.pg_role == "DTFC COMP" || self.pg_role == "SFMS AUTH") {
                            var gridEnable = ['COMMN_RejectionReason', 'COMMN_RejectionCategory', 'COMMN_TFCComment', 'COMMN_BranchComment', 'COMMN_WhetherGapResolved'];
                            doPropsAction(gridEnable, "enable");
                        }
                        if (self.pg_role == "PENDING REALISATION" || self.pg_role == "REALISATION FIN ENTRY" || self.pg_role == "REALISATION FIN AUTH" || self.pg_role == "RTGS ENTRY" || self.pg_role == "RTGS AUTH" ||  self.pg_role == "RECOVERY AUTH") {
                            var gridEnable = ['COMMN_DeferralReason', 'COMMN_EmpNo', 'COMMN_ApproversRole', 'COMMN_DefGrid_DueDate', 'COMMN_DTFCComment'];
                            doPropsAction(gridEnable, "enable");
                        }

                        if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE") {
                            var gridEnable = ['COMMN_DISCREPENCY'];
                            doPropsAction(gridEnable, "enable");
                        }

                        if (self.pg_role == "SOL MAKER" || self.pg_role == "DTFC COMP" || self.pg_role == "FIN ENTRY") {
                            var gridEnable = ['COMMN_UnderlyingDocs', 'COMMN_NameofApplicant', 'COMMN_NameofBene', 'COMMN_BeneficiaryAccountNo', 'COMMN_UnGrid_Currency', 'COMMN_Amount', 'COMMN_UnderlyingNo', 'COMMN_UnderlyingDate', 'COMMN_RemittanceAmount'];
                            doPropsAction(gridEnable, "enable");
                        }
						
						/*Instruction Grid*/
						if(self.pg_role == "DTFC COMP"){
							if(operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED'){
								var gridEnable = ['COMMN_FilterMessage_1','COMMN_InstructionBy_1','COMMN_InstructionDescription_1','COMMN_InstructionSubDesc_1'];
								doPropsAction(gridEnable,"enable");
							}
						}

						if(self.pg_role == "BILL ACCEPTANCE"){
							var subOperation = getPropValue("COMMN_SubOperation");
							if(operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE'){
								var gridEnable = ['COMMN_FilterMessage_2','COMMN_InstructionBy_2','COMMN_InstructionDescription_2','COMMN_InstructionSubDesc_2'];
								doPropsAction(gridEnable,"enable");
							}
							
							if(operation == 'LODGEMENT' && subOperation == 'DISHONOR'){
								var gridEnable = ['COMMN_FilterMessage_6','COMMN_InstructionBy_6','COMMN_InstructionDescription_6','COMMN_InstructionSubDesc_6'];
								doPropsAction(gridEnable,"enable");
							}
						}

						if(self.pg_role == "PENDING REALISATION"){
							var subOperation = getPropValue("COMMN_SubOperation");
							if(operation == 'LODGEMENT' && subOperation == 'REALIZATION'){
								var gridEnable = ['COMMN_FilterMessage_3','COMMN_InstructionBy_3','COMMN_InstructionDescription_3','COMMN_InstructionSubDesc_3'];
								doPropsAction(gridEnable,"enable");
							}
							
							if(operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED'){
								var gridEnable = ['COMMN_FilterMessage_4','COMMN_InstructionBy_4','COMMN_InstructionDescription_4','COMMN_InstructionSubDesc_4'];
								doPropsAction(gridEnable,"enable");
							}
						}

						if(self.pg_role == "DEVOLVED"){
							var subOperation = getPropValue("COMMN_SubOperation");
							if((operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED')&& subOperation == 'RECOVERY'){
								var gridEnable = ['COMMN_FilterMessage_5','COMMN_InstructionBy_5','COMMN_InstructionDescription_5','COMMN_InstructionSubDesc_5'];
								doPropsAction(gridEnable,"enable");
							}
						}

                        /*Processing Type Enable Diwakar*/

                        if (self.pg_role != "DTFC OCR" || self.pg_role != "PROCESSED") {
                            var enableProps = ['COMMN_ProcessingType', 'COMMN_Accep_ProcessingType', 'COMMN_Real_ProcessingType', 'COMMN_Dev_ProcessingType', 'COMMN_Re_ProcessingType', 'COMMN_Dis_ProcessingType', 'COMMN_HSMG_ProcessingType'];
                            doPropsAction(enableProps, "enable");
                        }

                        /* Based on SubOperation on Load */

                        var subOperation = getPropValue("COMMN_SubOperation");
                        if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                            setPropValue("COMMN_FUNCTION", 'G');
                        }
                        if (subOperation == 'ACCEPTANCE') {
                            setPropValue("COMMN_Accep_FUNCTION", 'A');
                        }
                        if (subOperation == 'REALIZATION') {
                            setPropValue("COMMN_Real_FUNCTION", 'R');
                        }
                        if (subOperation == 'RECOVERY') {
                            setPropValue("COMMN_Re_FUNCTION", 'O');
                        }
                        if (subOperation == 'DISHONOR') {
                            setPropValue("COMMN_Dis_FUNCTION", 'N');
                        }


                        var lodgementProcessing = self.pg_propCollectionController.getPropertyController("COMMN_ProcessingType");
                        var lodgementProcessingValue = lodgementProcessing.get("value");
                        if (lodgementProcessingValue == 'Manual') {
                            var mandateProps = ['COMMN_FinacleRefNo'];
                            doPropsAction(mandateProps, "enable");
                            doPropsAction(mandateProps, "Mandate");
                        }

                        var accepProcessing = self.pg_propCollectionController.getPropertyController("COMMN_Accep_ProcessingType");
                        var accepProcessingValue = accepProcessing.get("value");
                        if (accepProcessingValue == 'Manual') {
                            var mandateProps = ['COMMN_Accep_FinacleRefNo'];
                            doPropsAction(mandateProps, "enable");
                            doPropsAction(mandateProps, "Mandate");
                        }

                        var realProcessing = self.pg_propCollectionController.getPropertyController("COMMN_Real_ProcessingType");
                        var realProcessingValue = realProcessing.get("value");
                        if (realProcessingValue == 'Manual') {
                            var mandateProps = ['COMMN_Real_FinacleRefNo'];
                            doPropsAction(mandateProps, "enable");
                            doPropsAction(mandateProps, "Mandate");
                        }

                        var disProcessing = self.pg_propCollectionController.getPropertyController("COMMN_Dis_ProcessingType");
                        var disProcessingValue = disProcessing.get("value");
                        if (disProcessingValue == 'Manual') {
                            var mandateProps = ['COMMN_Dis_FinacleRefNo'];
                            doPropsAction(mandateProps, "enable");
                            doPropsAction(mandateProps, "Mandate");
                        }

                        var reProcessing = self.pg_propCollectionController.getPropertyController("COMMN_Re_ProcessingType");
                        var reProcessingValue = reProcessing.get("value");
                        if (reProcessingValue == 'Manual') {
                            var mandateProps = ['COMMN_Re_FinacleRefNo'];
                            doPropsAction(mandateProps, "enable");
                            doPropsAction(mandateProps, "Mandate");
                        }

                        var hsmgProcessing = self.pg_propCollectionController.getPropertyController("COMMN_HSMG_ProcessingType");
                        var hsmgProcessingValue = hsmgProcessing.get("value");
                        if (hsmgProcessingValue == 'Manual') {
                            var mandateProps = ['COMMN_HSMG_FinacleRefNo'];
                            doPropsAction(mandateProps, "enable");
                            doPropsAction(mandateProps, "Mandate");
                        }

                        /*var bankCode = self.pg_propCollectionController.getPropertyController("COMMN_BANKCode");
                        var bankCodeValue = bankCode.get("value");
                        if(bankCodeValue == 'UTIB'){
                        	setPropValue("COMMN_BANKCode", null);
                        }

                        var branchCode = self.pg_propCollectionController.getPropertyController("COMMN_BRANCHCode");
                        var branchCodeValue = branchCode.get("value");
                        if (branchCodeValue != undefined && branchCodeValue != null) {
                        	var str = branchCodeValue.substring(0, 4);
                        	if(str == 'UTIB'){
                        		setPropValue("COMMN_BRANCHCode", null);
                        	}
                        }*/
                        if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE" || self.pg_role == "FIN ENTRY" || self.pg_role == "ACCEPTANCE XMM ENTRY/MOD") {
                            var msgTypeValue = getPropValue("COMMN_MessageType");
                            if ((operation == "LODGEMENT" || operation == "ROLLOVER") && (!(self.pg_role == "FIN ENTRY" || self.pg_role == "ACCEPTANCE XMM ENTRY/MOD"))) {
                                if (msgTypeValue != '412') {
                                    var enableProps = ['COMMN_EntityType'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }
                            if (operation == "LODGEMENT" || operation == "MISCELLANEOUS") {
                                if (msgTypeValue != '412') {
                                    var enableProps = ['COMMN_EntityId'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }
                        }
                        if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE") {
                            var sfmsRequiredCntrl = self.pg_propCollectionController.getPropertyController("COMMN_SFMSRequired");
                            var sfmsRequired = sfmsRequiredCntrl.get("value");
                            var msgTypeValue = getPropValue("COMMN_MessageType");

                            if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                                if (msgTypeValue == '754') {
                                    var enableProps = ['COMMN_Narrative77A'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }

                            if ((operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') || operation == 'PRE-ACCEPTED') {
                                if (msgTypeValue == '754') {
                                    var enableProps = ['COMMN_SFMSFlag', 'COMMN_DocumentType', 'COMMN_DocumentNo', 'COMMN_DocumentDate'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }

                            if (sfmsRequired == 'Yes') {
                                var enableProps = ['COMMN_MessageType'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }
                            
                            if (msgTypeValue == 'REJECTION 734') {
                                var enableProps = ['COMMN_DisposalofDocuments'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(enableProps, "Mandate");
                            }


                            if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {
                                var messageType = getPropValue("COMMN_MessageType");
                                if (messageType == '754') {
                                    var enableProps = ['COMMN_AcceptanceDate'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(enableProps, "Mandate");
                                }
                            }

                            if (operation == 'LODGEMENT' && (subOperation == 'REALIZATION' || subOperation == 'ROLLOVER' || subOperation == 'ACCEPTANCE')) {
                                var enableProps = ['COMMN_RTGSIFSCode'];
                                var mandateProps = ['COMMN_RTGSIFSCode'];

                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
                        }

                        if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE" || self.pg_role == "PENDING REALISATION" || self.pg_role == "ACCEPTANCE FIN AUTH" || self.pg_role == "FIN AUTH") {
                            var billPayable = getPropValue('COMMN_BillPayable');
                            if (billPayable == 'Usance') {
                                var enableProps = ['COMMN_DueDate'];
								
								var mandateProps = ['COMMN_DueDate','COMMN_FinSTP_DUEDATE'];
								
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }
                        }

                        if (self.pg_role == "DTFC COMP" || self.pg_role == "BILL ACCEPTANCE" || self.pg_role == "PENDING REALISATION") {

                            var chargeCollection = getPropValue("COMMN_ChargeCollection");

                            if (chargeCollection == 'Yes') {
                                var enableProps = ['COMMN_ChargeEventId', 'COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges'];
                                var mandateProps = ['COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges', 'COMMN_ChargeEventId'];
                                doPropsAction(enableProps, "enable");
                                doPropsAction(mandateProps, "Mandate");
                            }

                            var collectionOnBill = getPropValue("COMMN_CollectiononBill");
                            if (collectionOnBill == 'Backed by LC') {
                                var enableProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
                                doPropsAction(enableProps, "enable");

                                var mandateProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
                                doPropsAction(mandateProps, "Mandate");
                            }

                            if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR' || subOperation == 'REALIZATION' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {

                                var chargeCollection = getPropValue("COMMN_ChargeCollection");
                                if (chargeCollection == 'Yes') {
                                    var enableProps = ['COMMN_DiscrepancyGST'];
                                    var mandateProps = ['COMMN_DiscrepancyGST'];
                                    doPropsAction(enableProps, "enable");
                                    doPropsAction(mandateProps, "Mandate");
                                }

                                var collectionOnBill = getPropValue("COMMN_CollectiononBill");
                                if (collectionOnBill == 'Backed by LC') {
                                    var enableProps = ['COMMN_DiscrepancyGST'];
                                    doPropsAction(enableProps, "enable");

                                    var mandateProps = ['COMMN_DiscrepancyGST'];
                                    doPropsAction(mandateProps, "Mandate");
                                }
                            }
                        }

                        var devDecision = self.pg_propCollectionController.getPropertyController("COMMN_DevolvedDecision");
                        var devDecisionValue = devDecision.get("value");
                        if (devDecisionValue == 'Devolvement' || devDecisionValue == 'Open New Devolvement account' || devDecisionValue == 'Existing Devolvement Account' || devDecisionValue == 'TOD') {
                            setPropValue("COMMN_Dev_FUNCTION", 'K');
							
							var enableProps = ['COMMN_Dev_DELINKACCOUNTNO', 'COMMN_Dev_REALIZATIONACID', 'COMMN_Dev_PURCHASESALE', 'COMMN_Dev_ACID', 'COMMN_Dev_CHARGEEVENTID'];
							doPropsAction(enableProps, "enable");
							doPropsAction(enableProps, "Mandate");
                        }

                        var devProcessing = self.pg_propCollectionController.getPropertyController("COMMN_Dev_ProcessingType");
                        var devProcessingValue = devProcessing.get("value");
                        if (devProcessingValue == 'Manual') {
                            var mandateProps = ['COMMN_Dev_FinacleRefNo'];
                            doPropsAction(mandateProps, "Mandate");
                        }

                        var rtgsIFSCode = self.pg_propCollectionController.getPropertyController("COMMN_RTGSIFSCode");
                        var rtgsIFSCodeValue = rtgsIFSCode.get("value");

                        if (rtgsIFSCodeValue != undefined && rtgsIFSCodeValue != null) {
                            var length = rtgsIFSCodeValue.length;
                            if (length >= 4) {
                                var bankCodeVal = rtgsIFSCodeValue.substring(0, 4);
                                setPropValue("COMMN_BANKCode", bankCodeVal);
                            }
                            if (length >= 11) {
                                var branchCodeVal = rtgsIFSCodeValue.substring(5, 11);
                                setPropValue("COMMN_BRANCHCode", branchCodeVal);
                            }
                        }

                        var bankIFSCode = self.pg_propCollectionController.getPropertyController("COMMN_DrawerBankCodeSFMSIFScode");
                        var bankIFSCodeValue = bankIFSCode.get("value");
                        if (bankIFSCodeValue != undefined && bankIFSCodeValue != null) {
                            var length = bankIFSCodeValue.length;
                            if (length >= 4) {
                                var bankVal = bankIFSCodeValue.substring(0, 4);
                                setPropValue("COMMN_BANK", bankVal);
                            }
                            if (length >= 11) {
                                var branchVal = bankIFSCodeValue.substring(5, 11);
                                setPropValue("COMMN_BRANCH", branchVal);
                            }
                        }

                        var dateAmountofUtilizationCntrl = self.pg_propCollectionController.getPropertyController("COMMN_DateandAmountofUtilization32ADate");
                        var documentDateCntrl = self.pg_propCollectionController.getPropertyController("COMMN_DocumentDate");
                        var acceptanceDateCntrl = self.pg_propCollectionController.getPropertyController("COMMN_Accep_ACCEPTANCEDATE");
                        if (dateAmountofUtilizationCntrl || documentDateCntrl || acceptanceDateCntrl) {
                            var currentDate = new Date();
                            var dateAmountofUtilization = dateAmountofUtilizationCntrl.set("value", currentDate);
                            var documentDate = documentDateCntrl.set("value", currentDate);
                            var acceptanceDate = acceptanceDateCntrl.set("value", currentDate);
                        }

                        /* Onload Finacle services */


                        if (self.pg_role == "SOL MAKER") {
                            /* SolId Services */
                            var url = finUrls.getZoneAgainstSolID;
                            var solID = getPropValue("COMMN_SOLID");
                            url = url.replace("%1", solID);
                            callWebService(url, ZoneAgainstSolID);
                            /* OperativeAccount No Service */
                            var opertiveAccNo = getPropValue("COMMN_OperativeAccountNo");
                            if (opertiveAccNo != null) {
                                var url = finUrls.getOperativeAccountDetails;
                                url = url.replace("%1", opertiveAccNo);
                                callWebService(url, fetchAgainstOperativeAccNo);

                                var url = finUrls.getGstAgainstAccNum;
                                url = url.replace("%1", opertiveAccNo);
                                callWebService(url, getGstNosAgainstAccNo);

                                var url = finUrls.getOperativeAccountDetails;
                                url = url.replace("%1", opertiveAccNo);
                                callWebService(url, showOperativeAccNoDetails);
                            }

                            /*charges acc number
                            var chargesaccnum = getPropValue("COMMN_ChargesAcctNum");
                            if (chargesaccnum != null) {
                                var url = finUrls.getOperativeAccNameobile;
                                url = url.replace("%1", chargesaccnum);
                                callWebService(url, fetchAgainstChargesAccNo);
                            }*/
                            /* CustID Service */
                            var custID = getPropValue("COMMN_Custid");
                            if (custID != null) {
                                var url = finUrls.getCustomerDetailsOnCustIdZone;
                                url = url.replace("%1", custID);
                                callWebService(url, fetchAgainstCustID);
                            }
                            if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                                var checkSolEnableUrl = finUrls.checkTBMLEnableSol;
                                checkSolEnableUrl = checkSolEnableUrl.replace("%1", getPropValue("COMMN_SOLID"));
                                callWebService(checkSolEnableUrl, tbmlEnableSol);
                            }

                        }

                        function ZoneAgainstSolID(response) {
                            var map = {
                                'ZONE': 'COMMN_Zone'
                            };
                            setWebServiceData(map, response);
                        }

                        function fetchAgainstOperativeAccNo(response) {
                            var map = {
                                'ACCT_NAME': 'COMMN_OperativeAccountName'
                            };
                            setWebServiceData(map, response);

                            var map = {
                                'ACCT_NAME': 'COMMN_ExisitingDevolvmentAccountName'
                            };
                            setWebServiceData(map, response);

                            var map = {
                                'ACCT_NAME': 'COMMN_AccountName'
                            };
                            setWebServiceData(map, response);

                            var map = {
                                'ACCT_NAME': 'COMMN_AccountHolderName'
                            };
                            setWebServiceData(map, response);
                        }

                        function getGstNosAgainstAccNo(response) {
                            var gstNumbers = response.GST_NUM;
                            if (self.pg_editable.propertiesCollection.hasOwnProperty("COMMN_GSTNo")) {
                                var propController = self.pg_propCollectionController.getPropertyController("COMMN_GSTNo");
                                if (propController != undefined) {
                                    var choicelist = [];
                                    var gstArray = gstNumbers.substr(1, gstNumbers.length - 2).split(",");
                                    array.forEach(gstArray, function(number) {
                                        console.log(" number ", number);
                                        var object = new Object();
                                        object["label"] = number;
                                        object["value"] = number;
                                        choicelist.push(number);
                                    });
                                    propController.set("choices", choicelist);
                                } else {
                                    console.log("COMMN_GSTNo" + " is Undefined for this action");
                                }
                            }
                        }
                        /* start */
                        /*function fetchAgainstChargesAccNo(response) {
                            var map = {
                                'ACCT_NAME': 'COMMN_ChargesAcctName'
                                //,'ACCT_CRNCY_CODE': 'COMMN_Currency',	                     
                                //'SCHM_TYPE':'COMMN_SchemeType',
                                //'ACCT_OPN_DATE':'COMMN_OperativeAcctOpeningDate'
                            };
                            setWebServiceData(map, response);

                        }*/
                        /* end */
                        function showOperativeAccNoDetails(response) {
                            dailogMessage += "<li>Effective Balance ::" + response.EFF_BALANCE + "</li>";
                            dailogMessage += "<li>Account Status ::" + response.ACCT_STATUS + "</li>";
                            dailogMessage += "<li>Account Currency Code ::" + response.ACCT_CRNCY_CODE + "</li>";
                            dailogMessage += "<li>Scheme Type ::" + response.SCHM_TYPE + "</li>";
                            customPopUpViewer2();
                        }

                        function customPopUpViewer(dailogMessage) {
                            dailogMessage = "<li>" + dailogMessage + "</li>";
                            var dailog = new ecm.widget.dialog.BaseDialog();
                            dailog.setTitle("Validation");
                            dailog.setMessage("<ul>" + dailogMessage + "</ul>", "error");
                            dailog.show();
                        }

                        function fetchAgainstCustID(response) {
                            var map = {
                                'CUST_NAME': 'COMMN_CustomerName',
                                'CUST_ZONE': 'COMMN_CustTypeZone',
                                'SEGMENT': 'COMMN_SegmentFinal',
                                'CBO_UNIT': 'COMMN_CBOUnit',
                                'EMAIL': 'COMMN_RegisteredEmailid'
                            };
                            setWebServiceData(map, response);

                        }

                        /* Auto populate  propertyValue from one tab to other */
				
                        exchangePropValue("COMMN_OperativeAccountNo", "COMMN_OPERATIVEACID");
						exchangePropValue("COMMN_OtherBankRefno", "COMMN_FinSTP_OTHERBANKSREFNO");
						exchangePropValue("COMMN_SFMS_OtherBankRefNo", "COMMN_OTHERBANKSREFNO");
						exchangePropValue("COMMN_BeneficiaryPostalCode", "COMMN_POSTALCODE");
						exchangePropValue("COMMN_InvoiceNo", "COMMN_FinSTP_INVOICENO");
						
						complete();
                    });

                /* Unbind the editable Object */
                self.pg_coordination.participate(Constants.CoordTopic.AFTERLOADWIDGET,
                    function(context, complete, abort) {

                        var solID = getPropValue("COMMN_SOLID");
                        if (solID != null) {
                            setPropValue("COMMN_FinSTP_SOLID", solID);
                            setPropValue("COMMN_HSMG_SOLID", solID);
                        }
                        var country = getPropValue("COMMN_Country");
                        if (country != null) {
                            setPropValue("COMMN_FinSTP_COUNTRY", country);
                        }

                        if (self.pg_role == "SOL MAKER") {
                            /* OperativeAccount No Service */
                            var opertiveAccNo = getPropValue("COMMN_OperativeAccountNo");
                            if (opertiveAccNo != null) {
                                var url = finUrls.getOperativeAccountDetails;
                                url = url.replace("%1", opertiveAccNo);
                                callWebService(url, fetchAgainstOperativeAccNo);

                            }
                        }

                        function fetchAgainstOperativeAccNo(response) {
                            var map = {
                                'ACCT_NAME': 'COMMN_OperativeAccountName'
                            };
                            setWebServiceData(map, response);
                        }


                        ControllerManager.unbind(self.pg_editable);
                        complete();
                    });
                /* Unbind the editable Object */
                self.pg_coordination.participate(Constants.CoordTopic.AFTERSAVE,
                    function(context, complete, abort) {
                        setPropValue("COMMN_LastSaveUser", self.pg_UserId);
                        if (self.pg_role == "DTFC OCR") {
                            var operation = getPropValue("COMMN_Operation");
                            performOCRTask();
                        }
                        complete();
                    });
            }

            function freezeProps() {
                var props = self.pg_propCollectionController.getPropertyControllers("F_CaseFolder");
                for (var i = 0; i < props.length; i++) {
                    props[i].set("readOnly", true);
                }
            }

            /* Method to doAll Props Action */
            function doPropsAction(props, action) {
                for (var i = 0; i < props.length; i++) {
                    if (self.pg_editable.propertiesCollection.hasOwnProperty(props[i])) {
                        var propController = self.pg_propCollectionController.getPropertyController(props[i]);
                        if (propController != undefined) {
                            if (action == "Mandate") {
                                propController.set("required", true);
                            } else if (action == "Non_Mandate") {
                                propController.set("required", false);
                            } else if (action == "disable") {
                                propController.set("readOnly", true);
                            } else if (action == "enable") {
                                propController.set("readOnly", false);
                            } else if (action == "hide") {
                                propController.set("hidden", true);
                            } else if (action == "unhide") {
                                propController.set("hidden", false);
                            }
                        } else {

                            console.log(props[i] + " is Undefined for OnLoadAction");
                        }
                    }
                }
            }

            //Method to Assign one Prop value to other Prop
            function exchangePropValue(doner, receiver) {
                if (self.pg_editable.propertiesCollection.hasOwnProperty(doner) && self.pg_editable.propertiesCollection.hasOwnProperty(receiver)) {
                    var donerController = self.pg_propCollectionController.getPropertyController(doner);
                    var receiverController = self.pg_propCollectionController.getPropertyController(receiver);
                    if (donerController != undefined && receiverController != undefined) {
                        var donerValue = donerController.get("value");
                        if (donerValue != undefined && donerValue != null) {
                            receiverController.set("value", donerValue);
                        }

                    } else {

                        console.log("Doner ::" + donerController + "can't set value to receiver ::" + receiverController);
                    }
                }

            }

            function removeResponses(responses) {
                var workItem = self.pg_editable.icmWorkItem;
                var newResponses = workItem.responses.filter(function(item) {
                    return responses.indexOf(item) == -1
                });
                workItem.responses = newResponses;

            }

            function feedChoiceItems(propID, choiceItem) {
                if (self.pg_editable.propertiesCollection.hasOwnProperty(propID)) {
                    var propController = self.pg_propCollectionController.getPropertyController(propID);
                    if (propController != undefined) {
                        propController.set("choices", choiceItem);

                    } else {

                        console.log(props[i] + " is Undefined for OnLoadAction");
                    }
                }

            }

            function getPropValue(propertyId) {
                if (self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) {
                    var propController = self.pg_propCollectionController.getPropertyController(propertyId);
                    if (propController != undefined) {
                        return propController.get("value");
                    } else {
                        console.log(propertyId + " is Undefined for this action");
                        return null;
                    }
                }
            }
            /* Pruthvi 06-05-2020 For Tbml implementation added this piece of code */
            //Ajax call for  TBML WebService
            function callWebService(URL, callBack) {
                var response = {};
                console.log("Inside callFinancial Service - URL ", URL);
                console.log("Inside callFinancial Service - CallBack", callBack);
                xhrArgs = {
                    url: URL,
                    handleAs: "json",
                    sync: true,
                    preventCache: true,
                    headers: {
                        "Content-Type": "application/json"
                    },
                    load: callBack,
                    error: function(error) {
                        console.log("Inside sol maker work Load  error  ", error);
                    }
                };

                response = dojo.xhrGet(xhrArgs);
                return response;
            }

            function tbmlEnableSol(response) {
                var map = {
                    'STATUS': 'COMMN_TBMLEnableSOL'
                };
                if (response.STATUS == 'Y') {
                    response.STATUS = 'Yes';
                } else {
                    response.STATUS = 'No';
                }

                var tbmlEnableSolPropController = self.pg_propCollectionController.getPropertyController('COMMN_TBMLEnableSOL');

                if (tbmlEnableSolPropController) {
                    tbmlEnableSolPropController.set("value", response.STATUS);
                }


            }

            function tbmlProcessFlg(response) {
                var map = {
                    'PROCESS_FLG': 'COMMN_TBMLProcessFlg',
                    'IS_PICKED_UP': 'COMMN_TBMLIsPickedUp',
                    'REMARKS': 'COMMN_TBMLRemarks'
                };
                var propController = self.pg_propCollectionController.getPropertyController('COMMN_TBMLStatus');
                if (propController) {
                    propController.set("value", response.PROCESS_FLG);
                }
                setWebServiceData(map, response);
            }

            function setWebServiceData(map, response) {
                var keysList = Object.keys(map);
                for (var i = 0; i < keysList.length; i++) {
                    var propertyId = map[keysList[i]];
                    var propertyValue = response[keysList[i]];

                    if (self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) {
                        var propController = self.pg_propCollectionController.getPropertyController(propertyId);
                        if (propController != undefined && propertyValue != null && propertyValue != undefined) {
                            if (propertyId == "COMMN_OperativeAcctOpeningDate") {
                                propController.set("value", new Date(propertyValue));

                            } else {
                                propController.set("value", propertyValue.trim());
                            }

                        } else {
                            console.log(propertyId + " is Undefined for this action");
                        }
                    }

                }

            }

            /* End */

            //Confiramation POPUP Viewer2
            function customPopUpViewer2() {
                var dailog = new ecm.widget.dialog.BaseDialog();
                dailog.setTitle("Validation");
                dailog.setMessage("<ul>" + dailogMessage + "</ul>", "error");
                dailog.show();
                dailogMessage = "";
            }

            function setPropValue(propertyId, value) {
                if (self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) {
                    var propController = self.pg_propCollectionController.getPropertyController(propertyId);
                    if (propController != undefined && value != undefined && value != null) {
                        propController.set("value", value);
                    } else {
                        console.log(propertyId + " is Undefined for this action");
                    }
                }
            }

            //Method for Datacap Validation at OCR
            function performOCRTask() {
                var operation = getPropValue("COMMN_Operation");
                var subOperation = getPropValue("COMMN_SubOperation");

                var enableProps = ['COMMN_CollectiononBill', 'COMMN_BillPayable', 'COMMN_DocumentaryCreditNoonBankCoverLetter', 'COMMN_OtherBankRefno', 'COMMN_ApplicantNameonInvoice', 'COMMN_BeneficiaryNameonInvoice', 'COMMN_TotalClaimedAmount', 'COMMN_IBCNumber', 'COMMN_SFMSRequired'];

                var mandateProps = ['COMMN_CollectiononBill', 'COMMN_BillPayable', 'COMMN_OtherBankRefno', 'COMMN_ApplicantNameonInvoice', 'COMMN_BeneficiaryNameonInvoice', 'COMMN_TotalClaimedAmount', 'COMMN_IBCNumber', 'COMMN_SFMSRequired','COMMN_ProcessingType'];

                var gridEnable = ['COMMN_UnderlyingDocs', 'COMMN_NameofApplicant', 'COMMN_NameofBene', 'COMMN_BeneficiaryAccountNo', 'COMMN_UnGrid_Currency', 'COMMN_Amount', 'COMMN_UnderlyingNo', 'COMMN_UnderlyingDate', 'COMMN_RemittanceAmount', 'COMMN_DISCREPENCY','COMMN_FilterMessage_1','COMMN_InstructionBy_1','COMMN_InstructionDescription_1','COMMN_InstructionSubDesc_1'];

                doPropsAction(gridEnable, "enable");
                doPropsAction(enableProps, "enable");
                doPropsAction(mandateProps, "Mandate");
				
				var collectionOnBill = getPropValue('COMMN_CollectiononBill');
				if (collectionOnBill == 'Backed by LC') {
					doPropsAction(["COMMN_LCOpenDate", "COMMN_ApplicantNameinLC", "COMMN_BeneficiaryNameinLC"], "Mandate");
				}

				if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
					if (collectionOnBill == 'Backed by LC') {
						doPropsAction(["COMMN_LcAvailableValue"], "Mandate");
					}
				}

                if (operation == 'LODGEMENT') {
                    var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DraftNo', 'COMMN_DraftDate', 'COMMN_DraftAmount', 'COMMN_InvoiceNo', 'COMMN_InvoiceDate', 'COMMN_InvoiceAmount', 'COMMN_LRGRBOLDate', 'COMMN_TenorFrom', 'COMMN_InterestApplicable', 'COMMN_PrincipleAmount','COMMN_DeferralPending', 'COMMN_GracePeriod', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_VEHICLEREGISTRATIONNO1', 'COMMN_VEHICLEREGISTRATIONNO2', 'COMMN_ChargeCollection', 'COMMN_UsanceDays', 'COMMN_TenorDiscription','COMMN_FinSTP_SOLID', 'COMMN_NAME', 'COMMN_ADDRESSLINE1', 'COMMN_ADDRESSLINE2', 'COMMN_ADDRESSLINE3', 'COMMN_CITY', 'COMMN_STATE', 'COMMN_POSTALCODE', 'COMMN_BANKCode', 'COMMN_BRANCHCode', 'COMMN_BANK', 'COMMN_TENORDESC', 'COMMN_GRACEPERIODDDD', 'COMMN_DUEDATEIND', 'COMMN_ONBOARDDATE', 'COMMN_FinSTP_BIC', 'COMMN_FinSTP_CHARGEEVENTID', 'COMMN_DCNumber', 'COMMN_BIC', 'COMMN_BRANCH', 'COMMN_SanctionLetter', 'COMMN_SanctionLetterAttached', 'COMMN_OurBankCharges', 'COMMN_ChargeDescreption', 'COMMN_DiscrepancyStatus', 'COMMN_Narrative77A'];

                    var mandateProps = ['COMMN_InvoiceNo', 'COMMN_InvoiceDate', 'COMMN_InvoiceAmount', 'COMMN_OtherBankAccountNo', 'COMMN_LRGRBOLDate', 'COMMN_TenorFrom', 'COMMN_InterestApplicable', 'COMMN_PrincipleAmount', 'COMMN_DeferralPending', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_ChargeCollection', 'COMMN_UsanceDays', 'COMMN_FinSTP_SOLID','COMMN_BANKCode', 'COMMN_BRANCHCode', 'COMMN_BANK', 'COMMN_TENORDESC', 'COMMN_GRACEPERIODDDD', 'COMMN_DUEDATEIND', 'COMMN_ONBOARDDATE','COMMN_FinSTP_BIC', 'COMMN_FinSTP_CHARGEEVENTID', 'COMMN_DateandAmountofUtilization32AAmount', 'COMMN_BILLAMOUNT', 'DC UTILIZATION AMOUNT', 'COMMN_INVOICEAMT', 'COMMN_FinSTP_INVOICENO', 'COMMN_FinSTP_INVOICEDATE','COMMN_DCNumber', 'COMMN_BIC', 'COMMN_BRANCH', 'COMMN_OurBankCharges', 'COMMN_ChargeDescreption', 'COMMN_DiscrepancyStatus', 'COMMN_Narrative77A'];

                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");
                }

                if (operation == 'PRE-ACCEPTED') {
                    var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DraftNo', 'COMMN_DraftDate', 'COMMN_DraftAmount', 'COMMN_InvoiceNo', 'COMMN_InvoiceDate', 'COMMN_InvoiceAmount', 'COMMN_LRGRBOLDate', 'COMMN_TenorFrom', 'COMMN_InterestApplicable', 'COMMN_PrincipleAmount','COMMN_DeferralPending', 'COMMN_GracePeriod', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_VEHICLEREGISTRATIONNO1', 'COMMN_VEHICLEREGISTRATIONNO2', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_UsanceDays', 'COMMN_TenorDiscription', 'COMMN_Narrative77A','COMMN_FinSTP_SOLID', 'COMMN_NAME', 'COMMN_ADDRESSLINE1', 'COMMN_ADDRESSLINE2', 'COMMN_ADDRESSLINE3', 'COMMN_CITY', 'COMMN_STATE', 'COMMN_POSTALCODE', 'COMMN_BANKCode', 'COMMN_BRANCHCode', 'COMMN_BANK', 'COMMN_TENORDESC', 'COMMN_GRACEPERIODDDD', 'COMMN_DUEDATEIND', 'COMMN_ONBOARDDATE','COMMN_FinSTP_BIC', 'COMMN_FinSTP_CHARGEEVENTID', 'COMMN_DCNumber', 'COMMN_BIC', 'COMMN_BRANCH', 'COMMN_SanctionLetter', 'COMMN_SanctionLetterAttached', 'COMMN_OurBankCharges', 'COMMN_ChargeDescreption', 'COMMN_DiscrepancyStatus'];

                    var mandateProps = ['COMMN_InvoiceNo', 'COMMN_InvoiceDate', 'COMMN_InvoiceAmount', 'COMMN_OtherBankAccountNo', 'COMMN_LRGRBOLDate', 'COMMN_TenorFrom', 'COMMN_InterestApplicable', 'COMMN_PrincipleAmount', 'COMMN_DeferralPending', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_RTGSIFSCode', 'COMMN_ChargeCollection', 'COMMN_UsanceDays', 'COMMN_Narrative77A',, 'COMMN_FinSTP_SOLID','COMMN_BANKCode', 'COMMN_BRANCHCode', 'COMMN_BANK', 'COMMN_TENORDESC', 'COMMN_GRACEPERIODDDD', 'COMMN_DUEDATEIND', 'COMMN_ONBOARDDATE', 'COMMN_FinSTP_BIC', 'COMMN_FinSTP_CHARGEEVENTID', 'COMMN_DateandAmountofUtilization32AAmount', 'COMMN_BILLAMOUNT', 'DC UTILIZATION AMOUNT', 'COMMN_INVOICEAMT', 'COMMN_FinSTP_INVOICENO', 'COMMN_FinSTP_INVOICEDATE','COMMN_DCNumber', 'COMMN_BIC', 'COMMN_BRANCH', 'COMMN_OurBankCharges', 'COMMN_ChargeDescreption', 'COMMN_DiscrepancyStatus'];

                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");
                }

                if (operation == 'ROLLOVER') {
                    var enableProps = ['COMMN_OtherBankAccountNo', 'COMMN_DraftNo', 'COMMN_DraftDate', 'COMMN_DraftAmount', 'COMMN_TenorFrom', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_UsanceDays', 'COMMN_TenorDiscription'];

                    var mandateProps = ['COMMN_OtherBankAccountNo', 'COMMN_TenorFrom', 'COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo', 'COMMN_UsanceDays'];

                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");
                }

                if (operation == 'MISCELLANEOUS' && subOperation == 'ACCEPTANCE') {
                    var enableProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                    var mandateProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");
                }

                if (operation == 'MISCELLANEOUS' && subOperation == 'DISHONOR') {
                    var enableProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                    var mandateProps = ['COMMN_DrawerBankCodeSFMSIFScode', 'COMMN_SFMS_OtherBankRefNo'];

                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");
                }

                if (operation == 'MISCELLANEOUS') {
                    var enableProps = ['COMMN_ChargeCollection'];

                    var mandateProps = ['COMMN_ChargeCollection'];

                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");
                }

                if (operation == 'LODGEMENT' && (subOperation == 'REALIZATION' || subOperation == 'ROLLOVER' || subOperation == 'ACCEPTANCE')) {
                    var enableProps = ['COMMN_RTGSIFSCode'];
                    var mandateProps = ['COMMN_RTGSIFSCode'];

                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");

                }
                if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {
                    var messageType = getPropValue("COMMN_MessageType");
                    if (messageType == '754') {
                        var enableProps = ['COMMN_AcceptanceDate'];
                        doPropsAction(enableProps, "enable");
                        doPropsAction(enableProps, "Mandate");

                    }

                }

                var msgTypeValue = getPropValue("COMMN_MessageType");
                if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR')) || operation == 'PRE-ACCEPTED' || operation == 'MISCELLANEOUS' || operation == 'ROLLOVER') {
                    var sfmsRequired = getPropValue("COMMN_SFMSRequired");
					if (msgTypeValue != '412' && sfmsRequired == 'Yes') {
                        var enableProps = ['COMMN_Narrative'];
                        doPropsAction(enableProps, "enable");
                        doPropsAction(enableProps, "Mandate");
                    }
                }

                if ((operation == 'LODGEMENT' && subOperation == 'ACCEPTANCE') || operation == 'PRE-ACCEPTED') {
                    if (msgTypeValue == '754') {
                        var enableProps = ['COMMN_SFMSFlag', 'COMMN_DocumentType', 'COMMN_DocumentNo', 'COMMN_DocumentDate'];
                        doPropsAction(enableProps, "enable");
                        doPropsAction(enableProps, "Mandate");
                    }
                }

                if (msgTypeValue == 'REJECTION 734') {
                    var enableProps = ['COMMN_DisposalofDocuments'];
                    doPropsAction(enableProps, "enable");
                    doPropsAction(enableProps, "Mandate");
                }

                if (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED') {
                    var usanceDays = getPropValue("COMMN_UsanceDays");
                    if (usanceDays > 90) {
                        var enableProps = ['COMMN_StampDutyApplicable', 'COMMN_StampDutyAmount'];
                        doPropsAction(enableProps, "enable");
                        doPropsAction(enableProps, "Mandate");
                    }

                    var collectionOnBillCntrl = self.pg_propCollectionController.getPropertyController("COMMN_CollectiononBill");
                    var collectionOnBill = collectionOnBillCntrl.get("value");
                    if (collectionOnBill == 'Backed by LC') {
                        
						var enableProps = ['COMMN_DocumentaryCreditNoonBOE', 'COMMN_BankCoverLetterDate', 'COMMN_LatestShipmentDate', 'COMMN_DescreptionofDiscrepancyCharges', 'COMMN_GSTAmount', 'COMMN_OtherBankCharges', 'COMMN_DCUtilizationAmount'];
                        doPropsAction(enableProps, "enable");
                        var mandateProps = ['COMMN_DocumentaryCreditNoonBOE', 'COMMN_BankCoverLetterDate', 'COMMN_LatestShipmentDate', 'COMMN_DescreptionofDiscrepancyCharges', 'COMMN_DCUtilizationAmount', 'COMMN_OtherBankCharges'];
                        doPropsAction(mandateProps, "Mandate");
                    }

                    if (collectionOnBill == 'Non LC' || collectionOnBill == 'NON LC') {
                        var enableProps = ['COMMN_BeneficiaryAddress', 'COMMN_BeneficiaryCity', 'COMMN_BeneficiaryState', 'COMMN_BeneficiaryPostalCode'];
                        doPropsAction(enableProps, "enable");

                        var mandateProps = ['COMMN_BILLAMT', 'COMMN_OTHERBANKSREFNO','COMMN_NAME', 'COMMN_ADDRESSLINE1', 'COMMN_ADDRESSLINE2', 'COMMN_ADDRESSLINE3', 'COMMN_CITY', 'COMMN_STATE', 'COMMN_POSTALCODE', 'COMMN_BeneficiaryAddress', 'COMMN_BeneficiaryCity'];
                        doPropsAction(mandateProps, "Mandate");
                    }

                }


                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                var msgTypeValue = getPropValue("COMMN_MessageType");
                if (sfmsRequired == 'Yes') {
                    var enableProps = ['COMMN_MessageType'];
                    doPropsAction(enableProps, "enable");
                    doPropsAction(enableProps, "Mandate");
                }
                if (msgTypeValue == '754') {
                    var enableProps = ['COMMN_Narrative77A'];
                    doPropsAction(enableProps, "enable");
                    doPropsAction(enableProps, "Mandate");
                }

                if (msgTypeValue != '412') {
                    var enableProps = ['COMMN_EntityType', 'COMMN_EntityId'];
                    doPropsAction(enableProps, "enable");
                    doPropsAction(enableProps, "Mandate");
                }

                var interestApplicable = getPropValue("COMMN_InterestApplicable");
                if (interestApplicable == 'Yes') {
                    var enableProps = ['COMMN_InterestRate', 'COMMN_GrossInterestAmount', 'COMMN_TDSApplicable', 'COMMN_TDSAmount', 'COMMN_GSTApplicable', 'COMMN_GSTAmount', 'COMMN_NetInterestAmount'];
                    doPropsAction(enableProps, "enable");
                    doPropsAction(enableProps, "Mandate");
                }

                var sanctionLetter = getPropValue("COMMN_SanctionLetter");
                if (sanctionLetter == 'Y') {
                    var enableProps = ['COMMN_SanctionCharges'];
                    var mandateProps = ['COMMN_SanctionCharges', 'COMMN_SanctionLetterAttached'];
                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");
                }


                var chargeCollection = getPropValue("COMMN_ChargeCollection");
                if (chargeCollection == 'Yes') {
                    var enableProps = ['COMMN_ChargeEventId', 'COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges'];
                    var mandateProps = ['COMMN_CommissiononIBC', 'COMMN_GST', 'COMMN_PostageonIBC', 'COMMN_PostageGST', 'COMMN_SFMSCharges', 'COMMN_SFMSGST', 'COMMN_DiscrpancyCharges', 'COMMN_ChargeEventId'];
                    doPropsAction(enableProps, "enable");
                    doPropsAction(mandateProps, "Mandate");
                }

                var collectionOnBill = getPropValue("COMMN_CollectiononBill");
                if (collectionOnBill == 'Backed by LC') {
                    var enableProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
                    doPropsAction(enableProps, "enable");

                    var mandateProps = ['COMMN_ChargeEventId', 'COMMN_DiscrpancyCharges'];
                    doPropsAction(mandateProps, "Mandate");
                }

                if ((operation == 'LODGEMENT' && (subOperation == 'ACCEPTANCE' || subOperation == 'DISHONOR' || subOperation == 'REALIZATION' || subOperation == 'ROLLOVER')) || operation == 'PRE-ACCEPTED') {

                    var chargeCollection = getPropValue("COMMN_ChargeCollection");
                    if (chargeCollection == 'Yes') {
                        var enableProps = ['COMMN_DiscrepancyGST'];
                        var mandateProps = ['COMMN_DiscrepancyGST'];
                        doPropsAction(enableProps, "enable");
                        doPropsAction(mandateProps, "Mandate");
                    }

                    var collectionOnBill = getPropValue("COMMN_CollectiononBill");
                    if (collectionOnBill == 'Backed by LC') {
                        var enableProps = ['COMMN_DiscrepancyGST'];
                        doPropsAction(enableProps, "enable");

                        var mandateProps = ['COMMN_DiscrepancyGST'];
                        doPropsAction(mandateProps, "Mandate");
                    }
                }
				
				var msgTypeValue = getPropValue("COMMN_MessageType");
				if (operation == "LODGEMENT" || operation == "ROLLOVER") {
					if (msgTypeValue != '412') {
						var enableProps = ['COMMN_EntityType'];
						doPropsAction(enableProps, "enable");
						doPropsAction(enableProps, "Mandate");
					}
				}
				if (operation == "LODGEMENT" || operation == "MISCELLANEOUS") {
					if (msgTypeValue != '412') {
						var enableProps = ['COMMN_EntityId'];
						doPropsAction(enableProps, "enable");
						doPropsAction(enableProps, "Mandate");
					}
				}
                
            }
        }

    });


});