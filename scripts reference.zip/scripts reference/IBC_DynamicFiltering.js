require(["dojo/_base/lang"],function(lang){
	lang.setObject("IBC_DynamicFiltering",{
		"doDynamicFiltering":function(scriptAdaptor){
			var solId;
			var data;			
			var self = scriptAdaptor;
	    	self.pg_UserId = ecm.model.desktop.userId;
			self.pg_UserName= ecm.model.desktop.userDisplayName;
			self.pg_role=ecm.model.desktop.currentRole.name;          
			console.log("loginUser user Id for dynamic filtering1 " ,self.pg_UserId);
			try
			{
				var finUrls=IBC_TRADConstants.loadConstants();
				var url = finUrls.FINACLE_SOLID_USERID;
				url =url.replace("%1",self.pg_UserId);
				console.log("Sol Id service URL : ",url);
				callFinacleService(url, getSolID);

				/*function getSolID(response)
				{
					console.log('returned sol id',response.SolId);
					solId=response.SolId;
				}*/
				function callFinacleService(url, callBack)
				{
					var response = {};
					console.log("Inside callFinancial Service ");
					console.log("Inside callFinancial Service - URL ", url);
					console.log("Inside callFinancial Service - CallBack", callBack);
					xhrArgs1 = {
						url: url,
						handleAs: "json",
						sync: true,
						preventCache: true,
						headers: { "Content-Type": "application/json"},       
						load: callBack,
						error: function(error)
						{
						   alert("Getting some error while fetching Sol_ID. Please try after Sometime");
						   solId='#@#';
						   console.log("Inside sol maker work Load  error  " ,error);

						}
					};

					response  = dojo.xhrGet(xhrArgs1);
					return response;
				}


			}catch(e)
			{
				console.log('Error at Sol Checker solid Filter1',e);
				solId='#@#';
			}	
			console.log('returned sol id........',solId);
			
			/*solid function */
			function getSolID(response)
			{
				console.log('returned sol id',response.SolId);
				solId=response.SolId;
			}
			
			//Utilities for all types of filtering
			function doOnlySolFiltering(queueName){
				data = {"queueName":queueName,
						"inbasketName":self.pg_role,
						"hideFilterUI":false,
						"queryFilter":"(COMMN_SOLID = :A)",
						"queryFields":[
						{
						"name":"COMMN_SOLID",
						"type":"xs:string",
						"value":solId
						}
						],
						"hideLockedByOther":false
						};	
			}
			function doSolNRoleFiltering(queueName){
			data = {
				"queueName":queueName,
				"inbasketName":self.pg_role,
				"hideFilterUI":false,
				"queryFilter":"(COMMN_SOLID = :A) and (COMMN_LastModifier != :A)",
				"queryFields":[{"name":"COMMN_SOLID","type":"xs:string","value":solId},{"name":"COMMN_LastModifier","type":"xs:string","value":self.pg_UserId}],
				"hideLockedByOther":false
					};
			}
			function doOnlyRoleFiltering(queueName){
				data = {"queueName":queueName,
						"inbasketName":self.pg_role,
						"hideFilterUI":false,
						"queryFilter":" (COMMN_LastModifier != :A)",
						"queryFields":[{"name":"COMMN_LastModifier","type":"xs:string","value":self.pg_UserId}],
						"hideLockedByOther":false
						};
			}
			function doDummyFiltering(){
				data = {
					"queueName":"TORM_DUMMY",
					"inbasketName":"SOL CHECKER",
					"hideFilterUI":false,
					"queryFilter":"(COMMN_SOLID != :A)",
					"queryFields":[
					{
					"name":"COMMN_SOLID",
					"type":"xs:string",
					"value":"#@#"
					}
					],
					"hideLockedByOther":false
					};
			}
			function customizedFiltering(queueName,queryFilter,queryFields){
					data = {"queueName":queueName,
						"inbasketName":self.pg_role,
						"hideFilterUI":false,
						"queryFilter":queryFilter,
						"queryFields":queryFields,
						"hideLockedByOther":false
						};
				
			}
			//Logic for Rolewise filtering(Change here only!!!!)
			if((solId=='002'||solId=='308'||solId=='2786'||solId=='2787') || 
			(self.pg_role !="SOL CHECKER" && self.pg_role !="FIN AUTH" &&  self.pg_role !="SOL MAKER"&&  self.pg_role !="DTFC HOLD"&&  self.pg_role !="BR ACCEPT MAKER"
			&&  self.pg_role !="BR ACCEPT CHECKER"&&  self.pg_role !="PROCESSED"&&  self.pg_role !="SFMS AUTH"&&  self.pg_role !="ACCEPTANCE FIN AUTH"))
			{
				doDummyFiltering();
			}else if(self.pg_role == "SOL CHECKER")
			{
				doSolNRoleFiltering("IBC_"+"SOLCHECKER");	
			}
			else if(self.pg_role == "FIN AUTH"){
				var queryFilter="(COMMN_LastModifier != :A) and (COMMN_CompUserEmpID != :A)";
				var queryFields=[{"name":"COMMN_LastModifier","type":"xs:string","value":self.pg_UserId},{"name":"COMMN_CompUserEmpID","type":"xs:string","value":self.pg_UserId}];
				customizedFiltering("IBC_"+"FINAUTH",queryFilter,queryFields);			
			}
			else if(self.pg_role == "SOL MAKER"){
				doOnlySolFiltering("IBC_"+"SOLMAKER");		
			}
			else if(self.pg_role == "DTFC HOLD"){
				doOnlySolFiltering("IBC_"+"DTFCHOLD");		
			}
			else if(self.pg_role == "BR ACCEPT MAKER"){
				doOnlySolFiltering("IBC_"+"BRACCEPTMAKER");		
			}
			else if(self.pg_role == "BR ACCEPT CHECKER"){
				doOnlySolFiltering("IBC_"+"BRACCEPTCHECKER");		
			}
			else if(self.pg_role == "PROCESSED"){
				doOnlySolFiltering("IBC_"+"PROCESSED");		
			}
			else if(self.pg_role == "SFMS AUTH"){
				var queryFilter="(COMMN_SFMSUserEmpID != :A)";
				var queryFields=[{"name":"COMMN_SFMSUserEmpID","type":"xs:string","value":self.pg_UserId}];
				customizedFiltering("IBC_"+"SFMSAUTH",queryFilter,queryFields);		
			}
			else if(self.pg_role == "ACCEPTANCE FIN AUTH"){
				var queryFilter="(COMMN_BillAcceptanceUserEmpID != :A)";
				var queryFields=[{"name":"COMMN_BillAcceptanceUserEmpID","type":"xs:string","value":self.pg_UserId}];
				customizedFiltering("IBC_"+"ACCEPTANCEFINAUTH",queryFilter,queryFields);		
			}

			//data.queryFields[0].value = sol_checker;
			var model = icm.model.InbasketDynamicFilter.fromJSON(data);
			console.log(model);
			var modelArray = [];
			modelArray.push(model);
			console.log("Comming to the last part");
			console.log(modelArray);

			return {"dynamicFilters":modelArray};

		}

	});

});