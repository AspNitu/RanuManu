//Scripts having all the Add Case validation

//Import here all the Modules used in your JS
require(["icm/base/Constants", "icm/model/properties/controller/ControllerManager","dojo/_base/lang","dojo/_base/array","ecm/model/Teamspace"], function(Constants, ControllerManager,lang,array,Teamspace){
	
	lang.setObject("IBC_AddCasePage",{
		
		//Method to return payload
		"passthrough":function(payload,solution,role,scriptAdaptor){
	        return payload;		
		},
		
		//Main Method for OnLoad Scripts
	    "AddCasePageAction":function(payload,solution,role,scriptAdaptor)
	    {
	    	debugger;
	    	var self = scriptAdaptor;
	    	self.pg_UserId = ecm.model.desktop.userId;
			self.pg_UserName= ecm.model.desktop.userDisplayName;
			self.pg_coordination = payload.coordination;
			self.pg_solution = scriptAdaptor.solution;
			self.pg_prefix = scriptAdaptor.solution.getPrefix();
			self.pg_eventName = payload.eventName;
			self.pg_role=ecm.model.desktop.currentRole.name;
	        var dailogMessage="";
			
		if(self.pg_eventName=="icm.SendNewCaseInfo")
	    {
				self.pg_editable=payload.caseEditable;
				self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);
				 //Before Load Coordination 
				 self.pg_coordination.participate(Constants.CoordTopic.BEFORELOADWIDGET, 
				 function(context, complete, abort)
				{
					//Load choice list
					//Call the Choicelist Service
					var choiceListArray = ["Operation"];
					ecm.model.Request.invokePluginService("ChoicelistFetch", "ChoicelistFetchService", {
						requestParams: {"solutionName":"IBC","choiceList":choiceListArray},
						backgroundRequest: false,
						requestCompleteCallback: lang.hitch(this, function(response) { 
								self.choiceItems = response;
								console.log("choiceItems: ",self.choiceItems);
								complete();	
						}),
						requestFailedCallback: lang.hitch(this, function(response) { // failed
							console.log('Error in ChoicelistFetchService :: '+response);
							abort();
						})
					});
			
			
				});
			self.pg_coordination.participate(Constants.CoordTopic.LOADWIDGET, 
			function(context, complete, abort)
			{
				//Set ChoiceItems to PROPERTY_CONTROLLER
				  for(i in self.choiceItems)
				  {
					if(self.choiceItems[i]['choiceName']=="Operation")
					{
						feedChoiceItems("COMMN_Operation",self.choiceItems[i]["choiceArray"]);
					}
				 }
				 //Set Source as Manual
				 setPropValue("COMMN_Source","Manual");
				 complete();
			});					
				
		}
		if(payload.eventName === "icm.CaseCreated"){
			
			payload.caseEditable.getCase().retrieveCaseFolder(function(parentCaseFolder){

				debugger;
			var repositroy = parentCaseFolder.repository;
			var addContentItemDialog = new ecm.widget.dialog.AddContentItemDialog(); 
					
			solution.retrieveDocumentTypes(function(docTypes) {
				 var dcList = null;
				 if (docTypes && docTypes.length > 0) {
					 console.log("docType: "+docTypes);
					          dcList = new Teamspace({
					            repository: parentCaseFolder.repository,
					            name: parentCaseFolder.repository.name,
					            type: Teamspace.RUNTIME,
					            addAllowAllClasses: false,
					            contentClasses: docTypes,
					            defaultClass: "IBC_IBCDocument"
					          });
					        }

					        /*Show the add document dialog*/
			 addContentItemDialog.show(parentCaseFolder.repository, parentCaseFolder, true, false, null, dcList, false, null, true);
					      }); 

			});	
			
			
		}
		if (payload.eventName === "icm.SendCaseInfo")
		{
			self.pg_editable=payload.caseEditable;
			console.log("pg_editable: ",self.pg_editable);
			payload.coordination.participate(Constants.CoordTopic.CANCEL, function(context, complete, abort)
            {
				if(self.comment_Childwindow!=undefined&&!self.comment_Childwindow.closed)
				{
					console.log("Comment window close.");
					self.comment_Childwindow.close();
				}
				if(self._childWindow!=undefined&&!self._childWindow.closed)
				{
					console.log("Comment window close.");
					self._childWindow.close();
				}					
				complete();
			});
			
			
		}
		if(self.pg_eventName=="icm.PropertyUpdated")
		{
				self.pg_editable=payload.caseEditable;
				self.propValue = payload.value;
				var propId = payload.property.binding;
				self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);
						
				//Do the Updated Stuff
				//Finacle Service Implementation
				//debugger;
				var finUrls=IBC_TRADConstants.loadConstants();
			
				//SolId Service Implementation
				if(propId=="F_CaseFolder.COMMN_SOLID")
				{
					var url=finUrls.validateSolId;
					url =url.replace("%1",self.propValue);
					callFinacleService(url,validateSolID);
					
					var url=finUrls.getZoneAgainstSolID;
					url =url.replace("%1",self.propValue);
					callFinacleService(url,ZoneAgainstSolID);
				}		  
		}
		if(self.pg_eventName=="OnOpenComment")
		{	  
			  self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);
			  var finUrls=IBC_TRADConstants.loadConstants();
			  if (self.comment_Childwindow != undefined && !self.comment_Childwindow.closed) {
                    console.log("Comment window already open.");
                    self.comment_Childwindow.focus();
                } else {
                   console.log("Open comment window:::",self.pg_editable);
					var caseId = getPropValue('CmAcmCaseIdentifier');
					var WorkItemIDVal = getPropValue('COMMN_WID');
					var dbCheckflag = "No";
					var url=finUrls.commentsUrl;
					console.log("webService",url);
					openPopupPage(url,caseId,WorkItemIDVal,dbCheckflag,"CaseDetails");
                }
		}
			
			//Methods for Finacle Service
			function openPopupPage(url,caseId,WorkItemIDVal,dbCheckflag,pageName)
			{
				 var params = { 'caseId' : caseId, 'userName': self.pg_UserId , 'role': self.pg_role , 'WorkItemIDVal': WorkItemIDVal , 'productName': 'IBC' , 'dbCheckflag': dbCheckflag,'pageName':pageName };
				 var sUsrAg = navigator.userAgent;
				 var form = document.createElement("form");
				 
				 form.method='post';
				 form.action = url;
				 form.target = 'newWinname';	

				 for (var i in params)
				 {
				   if (params.hasOwnProperty(i))
				   {
					 var input = document.createElement('input');
					 input.type = 'hidden';
					 input.name = i;
					 input.value = params[i];
					 form.appendChild(input);
				   }
				 }
				 document.body.appendChild(form);
				 self.comment_Childwindow = window.open("", "newWinname", "width=580,height=580,resizable=yes,top=20,scrollbars=yes");
				
				form.submit();
			}
			function validateSolID(response)
			{
				if(response["valid"]=="true"){
					customPopUpViewer("SolID Validated Successfully");
				}
				else{
					customPopUpViewer("SolID is Invalid");
				}
			}
			function ZoneAgainstSolID(response)
			{
				 var map = {'ZONE': 'COMMN_Zone'};
				 setFinacleServiceData(map,response);
			
			}
			
			
			function setFinacleServiceData(map,response)
			{
				var keysList = Object.keys(map);
				for(var i = 0 ; i < keysList.length ;i++)
				{
					var propertyId = map[keysList[i]];
					var propertyValue = response[keysList[i]];
					
					if(self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) 
					{
						var propController = self.pg_propCollectionController.getPropertyController(propertyId);
						if(propController!=undefined && propertyValue!=null)
						{
							propController.set("value",propertyValue.trim());
							
						}else{
							
							console.log(propertyId+" is Undefined for this action");
						}
					}
					
				}
				
			}
			 function getPropValue(propertyId)
			 {
					if(self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) 
					{
						var propController = self.pg_propCollectionController.getPropertyController(propertyId);
						if(propController!=undefined)
						{
							return propController.get("value");
						}else{
							console.log(propertyId+" is Undefined for this action");
							return null;
						}
					}
			 }
			 function setPropValue(propertyId,value)
			{
				if(self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) 
				{
					var propController = self.pg_propCollectionController.getPropertyController(propertyId);
					if(propController!=undefined && value!=undefined && value!=null)
					{
						propController.set("value",value);
					}else{
						console.log(propertyId+" is Undefined for this action");
					}
				}
			}
			//Confiramation POPUP Viewer
			 function customPopUpViewer(dailogMessage)
			 {
				dailogMessage = "<li>"+dailogMessage+"</li>";
				var dailog = new ecm.widget.dialog.BaseDialog();
				dailog.setTitle("Validation");
			    dailog.setMessage("<ul>"+dailogMessage+"</ul>", "error");
			    dailog.show();
			 }
			 
			 //Ajax call for Finacle Service
			 function callFinacleService(URL, callBack)
			 {
				var response = {};
				console.log("Inside callFinancial Service - URL ", URL);
				console.log("Inside callFinancial Service - CallBack", callBack);
				xhrArgs = {
				url: URL,
				handleAs: "json",
				sync: true,
				preventCache: true,
				headers: { "Content-Type": "application/json"},       
				load: callBack,
				error: function(error)
				{
				   console.log("Inside sol maker work Load  error  " ,error);
				}
						};

				response  = dojo.xhrGet(xhrArgs);
				return response;
			 }
			 
			 function feedChoiceItems(propID,choiceItem)
			{
					if(self.pg_editable.propertiesCollection.hasOwnProperty(propID)) 
					{
						var propController = self.pg_propCollectionController.getPropertyController(propID);
						if(propController!=undefined)
						{
							propController.set("choices",choiceItem);
							
						}
						else{
							
							console.log(props[i]+" is Undefined for OnLoadAction");
						}
					}
				
			}
			//Method to Mandatory Props
			function doPropAction(props,action)
			{
				 for(var i = 0; i < props.length; i++) 
				{
					if(self.pg_editable.propertiesCollection.hasOwnProperty(props[i])) 
					{
						var propController = self.pg_propCollectionController.getPropertyController(props[i]);
						if(propController!=undefined)
						{
							if(action=="Mandate"){
								propController.set("required",true);
							}else if(action=="Non_Mandate"){
								propController.set("required",false);
							}
							else if(action=="disable"){
								propController.set("readOnly",true);
							}
							else if(action=="enable"){
								propController.set("readOnly",false);
							}
							else if(action=="hide"){
								propController.set("hidden",true);
							}
						}else{
							
							console.log(props[i]+" is Undefined for OnLoadAction");
						}
					}
				}	 
			}
			 
			 

	    }
	
	});


});


