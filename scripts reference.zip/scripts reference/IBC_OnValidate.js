//Scripts having all the On Send validation 21/05/2020

//Import here all the Modules used in your JS
require(["icm/base/Constants", "icm/model/properties/controller/ControllerManager","dojo/_base/lang","icm/action/Action","dojo/_base/array"], function(Constants, ControllerManager,lang,ICMAction,array){
	lang.setObject("IBC_OnValidate",{
		
		//Method to return payload
		"passthrough":function(payload,solution,role,scriptAdaptor){
	        return payload;		
		},
		
		//Main Method for OnLoad Scripts
	    "OnValidateAction":function(payload,solution,role,scriptAdaptor)
	    {
	    	
	    	var self = scriptAdaptor;
	    	self.pg_UserId = ecm.model.desktop.userId;
			self.pg_UserName= ecm.model.desktop.userDisplayName;
			self.pg_coordination = payload.coordination;
			self.pg_solution = scriptAdaptor.solution;
			self.pg_prefix = scriptAdaptor.solution.getPrefix();
			self.pg_eventName = payload.eventName;
			self.pg_role=ecm.model.desktop.currentRole.name;
			self.productName="IBC";
			var finUrls = IBC_TRADConstants.loadConstants();
            lang.setObject("finUrls", finUrls); 
			//Take the event
			if(self.pg_eventName=="icm.SendWorkItem")
		    {
				self.pg_editable=payload.workItemEditable;
				self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);
				//Take the Coordination
				 self.pg_coordination.participate(Constants.CoordTopic.VALIDATE, 
				 function(context, complete, abort)
				 {
					self.pg_editable=payload.workItemEditable;
					self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);
					
					var response=context[Constants.CoordContext.WKITEMRESPONSE];
					self.response = response;
					self.wid = getPropValue('COMMN_WID');
					self.caseId = getPropValue('CmAcmCaseIdentifier');
					var confirmationMessage="";
					var abortMessage="";
					var abortProcess=false;
					var operation = getPropValue("COMMN_Operation");
					var subOperation = getPropValue("COMMN_SubOperation");
					/* Abort validation
					if(checklist_Childwindow!=undefined&&!checklist_Childwindow.closed)
					{
					   checklist_Childwindow.close();
					}
					//doc close
					if(childwindow != undefined)
					{
						CompleteCoordinate.onClickValidate(self.pg_coordination,self.pg_solution);
					} */
						//Field level validation
						//Doc Checklist Validation starts
						if (self.pg_role == 'SOL CHECKER') {
							var bankCoverLetter = getPropValue('COMMN_BANKCOVERLETTER');
							var acceptanceLetter = getPropValue('COMMN_ACCEPTANCELETTER');
							if(!(response.includes("Reject") || response.includes("Trash"))){
								if(operation=="PRE-ACCEPTED"&&acceptanceLetter!=true){
									var message = "Acceptance Letter Checklist is mandatory";
									abortMessage = abortMessage + "<li>" + message + "</li>";
									addComment(message);
									abortProcess = true;
								}
								if(bankCoverLetter!=true){
									var message = "Branch Cover Letter Checklist is mandatory";
									abortMessage = abortMessage + "<li>" + message + "</li>";
									addComment(message);
									abortProcess = true;
								}
							}
						}
						//Doc Checklist Validation Ends
						
					 mailer();
					    //Workflow Validation starts...
						//Check Wheather checklist opened n u r sending d wid
						if (checklist_Childwindow!=undefined&&!checklist_Childwindow.closed) {
							var propertyName = "COMMN_CheckList_Branch_Done,COMMN_CheckList_Compliance_Done";
							getNSetChecklistDoneFlag(propertyName);
						}
                        
                        if (self.pg_role == 'SOL CHECKER') {
                            var trashReason = getPropValue('COMMN_TrashReason');
                            if (trashReason == null && response == 'Send to Trash') {
                                var message = "Trash reason is mandatory";
                                abortMessage = abortMessage + "<li>" + message + "</li>";
                                addComment(message);
                                abortProcess = true;
                            }
                            if (trashReason != null && response != 'Send to Trash') {
                                var message = "Trash reason will be filled only while Trashing the WID";
                                abortMessage = abortMessage + "<li>" + message + "</li>";
                                addComment(message);
                                abortProcess = true;
                            }
							 if(!(response.includes('Reject') || response.includes('Trash'))) {
								var branchCheckListVal = getPropValue('COMMN_CheckList_Branch_Done');
								if (branchCheckListVal !== true) {
									var message = "Branch CheckList is Mandatory";
									abortMessage = abortMessage + "<li>" + message + "</li>";
									addComment(message);
									abortProcess = true;
								}
							} 
                        }
                        if(self.pg_role == 'DTFC COMP') {
							if(!(response.includes('Reject') || response.includes('Trash'))) {
								var complianceCheckListVal = getPropValue('COMMN_CheckList_Compliance_Done');
								if (complianceCheckListVal !== true) {
									var message = "Compliance CheckList is Mandatory";
									abortMessage = abortMessage + "<li>" + message + "</li>";
									addComment(message);
									abortProcess = true;
								}
							} /* Pruthvi for TBML */
							if(response.includes('Send') && (operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED')) {
								if (getPropValue('COMMN_TBMLEnableSOL').toUpperCase() == 'YES') {
                                    var wid = getPropValue('COMMN_WID');
                                    var url = finUrls.getProcessFlag;
                                    url = url.replace("%1", wid);
                                    callWebService(url, tbmlProcessFlgUpdate);
                                }

                                var tbmlIsPickedUpValue = getPropValue('COMMN_TBMLStatus');
                                var tbmlProcessFlg = getPropValue('COMMN_TBMLDecision');
                                if (tbmlIsPickedUpValue == 'N' && (getPropValue('COMMN_TBMLEnableSOL').toUpperCase() == 'YES')) {
                                    var message = "Please Wait WID has not yet been picked by TBML";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                                if (tbmlIsPickedUpValue == 'Y' && (getPropValue('COMMN_TBMLEnableSOL').toUpperCase() == 'YES') && (tbmlProcessFlg == '' || tbmlProcessFlg == null || tbmlProcessFlg == 'AVAILABLE')) {
                                    var message = "Please Wait untill TBML Process the WID";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                                if (tbmlIsPickedUpValue == 'Y' && tbmlProcessFlg == 'R') {
                                    var message = "Please Reject to Branch Hold";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
							} 
							
                            if (response == 'Reject to Branch Hold') {
                                var rejectionReason = getPropValue("COMMN_RejectionReason");
                                var rejectionReasonCount = rejectionReason.length;
                                var diff = rejectionReasonCount - RejReasonCountOnLoad;
                                if (diff == 0) {
                                    var message = "Rejection reason is mandatory";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == 'Send to FIN STP') {
                                var processingType = getPropValue("COMMN_ProcessingType");
                                var discrepancyStatus = getPropValue("COMMN_DiscrepancyStatus");
                                var branchDecission = getPropValue("COMMN_DTFCHoldBranchdecision");
                                var stpDone = getPropValue("COMMN_L_STP_DONE");
                                if (operation == "LODGEMENT") {
                                    if (!(processingType == "STP" && (discrepancyStatus == "Nil Discrepant" || discrepancyStatus == "Discrepant MT 734" || branchDecission == "Amend LC"))) {
                                        var message = "Kindly choose Processing Type STP and correct discrepancyStatus and correct DTFC Hold Decission";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    } else if (stpDone == true) {
                                        var message = "STP is already been done,kindly check";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                } else if (operation == "PRE-ACCEPTED") {

                                    if (processingType != "STP") {
                                        var message = "Kindly choose Processing Type STP";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    } else if (stpDone == true) {
                                        var message = "STP is already been done,kindly check";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
                            }
                            if (response == 'Send to Fin Entry' || response == 'Send to XMM Entry/MOD') {
                                if (!(operation == "CHARGE REVERSAL" || operation == "MISCELLANEOUS"||operation == "ROLLOVER")) {
                                    var processingType = getPropValue("COMMN_ProcessingType");
                                    var stpDone = getPropValue("COMMN_L_STP_DONE");
                                    var targetQueue = "";
                                    if (response == 'Send to Fin Entry') {
                                        targetQueue = "FIN Entry"
                                    } else {
                                        targetQueue = "XMM Entry/MOD"
                                    }
                                    if ((processingType == "STP" && stpDone == false)) {
                                        var message = "For Processing type STP ,WID can't move to " + targetQueue;
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                    if ((processingType == "" || processingType == undefined || processingType == null)) {
                                        var message = "WID can't move to " + targetQueue + ",kindly select the processingType as Manual";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
                            }
                            if (response == "Send to SFMS Auth") {
                                var processingType = getPropValue("COMMN_ProcessingType");
                                var discrepancyStatus = getPropValue("COMMN_DiscrepancyStatus");
                                var branchDecission = getPropValue("COMMN_DTFCHoldBranchdecision");
                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                var msgType = getPropValue("COMMN_MessageType");
                                if (operation == "ROLLOVER") {
                                    //Need to do
                                    if (!( processingType == "STP" &&(msgType == "499" || msgType == "799"))) {
                                        var message = "Kindly choose Processing Type STP and msgType as 499 or 799";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                } else {

                                    if (!(processingType == "STP" && sfmsRequired == "Yes" && (discrepancyStatus == "Rejection MT 499" || 
									discrepancyStatus == "Rejection MT 734" || branchDecission == "Return Document"))) {
                                        var message = "Kindly choose Processing Type STP and correct discrepancyStatus and correct DTFC Hold Branch Decission and sfmsRequired should be Yes";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }

                                }
                            }
							
							/*Instruction Grid*/
							if (response == "Send to SFMS Auth" || response == 'Send to Fin Entry' || response == 'Send to XMM Entry/MOD' || response == "Send to FIN STP"){
								var operation = getPropValue("COMMN_Operation");
								if(operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED'){
									var filterMessage1 = getPropValue("COMMN_FilterMessage_1");
									var filterMessage1Count = filterMessage1.length;
									var differ = filterMessage1Count - filterMsg1CountOnLoad;
									if(differ == 0){
										var message = "Instruction Grid Lodgement is Mandatory";
										abortMessage = abortMessage + "<li>" + message + "</li>";
										addComment(message);
										abortProcess = true;
									}
								}
							}
						}
                        if (self.pg_role == 'FIN AUTH') {
                            if (response == "Send to BR Accept Maker") {
                                var discrepancyStatus = getPropValue("COMMN_DiscrepancyStatus");
                                var branchDecission = getPropValue("COMMN_DTFCHoldBranchdecision");
                                if (!(discrepancyStatus == "Nil Discrepant" || branchDecission == "Amend LC")) {
                                    var message = "Kindly choose correct discrepancyStatus and correct DTFC Hold Decission";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == "Send to XMM Entry/MOD") {
                                if (operation == "LODGEMENT") {
                                    var processingType = getPropValue("COMMN_ProcessingType");
                                    if (!(processingType == "Manual")) {
                                        var message = "WID can't move to XMM Entry/MOD ,Kindly select processingType as Manual";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                } else if (operation == "PRE-ACCEPTED") {
                                    var processingType = getPropValue("COMMN_ProcessingType");
                                    var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                    if (!(processingType == "Manual" && sfmsRequired == "Yes")) {
                                        var message = "WID can't move to XMM Entry/MOD ,Kindly select processingType as Manual and SFMS required as Yes";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                } else if (operation == "MISCELLANEOUS" || operation == "CHARGE REVERSAL") {
                                    var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                    if (!(sfmsRequired == "Yes")) {
                                        var message = "WID can't move to XMM Entry/MOD ,Kindly select SFMS required as Yes";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
                            }
                            if (response == "Send to SFMS Auth") {
                                var processingType = getPropValue("COMMN_ProcessingType");
                                var discrepancyStatus = getPropValue("COMMN_DiscrepancyStatus");
                                var stpStatus = getPropValue("COMMN_FinStatus");
                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                if (operation == "LODGEMENT") {
                                    if (!(processingType == "STP" && discrepancyStatus == "Discrepant MT 734")) {
                                        var message = "WID can't move to SFMS Auth ,Kindly select processingType as STP and discrepancyStatus as Discrepant MT 734";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                } else if (operation == "PRE-ACCEPTED") {
                                    if (!(processingType == "STP" && stpStatus == "P" && sfmsRequired == "Yes")) {
                                        var message = "WID can't move to SFMS Auth ,ProcessingType should be STP with succesful status and sfmsRequired should be Yes";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
                            }
                            if (response == "Send to Pending Realisation") {
                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                if (!(sfmsRequired == "No")) {
                                    var message = "WID can't move to Pending Realisation,Kindly select sfmsRequired as No";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == "Send to Processed") {
                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                if (!(sfmsRequired == "No")) {
                                    var message = "WID can't move to Processed,Kindly select sfmsRequired as No";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }

                        }

                        if (self.pg_role == 'SFMS AUTH') {
                            if (response == "Send to BR Accept Maker") {
                                if (operation == "LODGEMENT") {
                                    var discrepancyStatus = getPropValue("COMMN_DiscrepancyStatus");
                                    if (!(discrepancyStatus == "Discrepant MT 734")) {
                                        var message = "Kindly select discrepancyStatus as Discrepant MT 734";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
                            }
                            if (response == "Send to Processed") {
                                if (!(operation == "MISCELLANEOUS" || operation == "CHARGE REVERSAL")) {
                                    var branchDecission = getPropValue("COMMN_DTFCHoldBranchdecision");
                                    if (!(branchDecission == "Return Document")) {
                                        var message = "Kindly select branchDecission as Return Document";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
                            }
                            if (response == "Send to DTFC Hold") {
                                var rejectionReason = getPropValue("COMMN_RejectionReason");
                                var rejectionReasonCount = rejectionReason.length;
                                var diff = rejectionReasonCount - RejReasonCountOnLoad;
                                var discrepancyStatus = getPropValue("COMMN_DiscrepancyStatus");
                                if (!((discrepancyStatus == "Rejection MT 499" || discrepancyStatus == "Rejection MT 734") && diff != 0)) {
                                    var message = "Kindly select discrepancyStatus as Rejection MT 734 or Rejection MT 499 and Rejection reason is mandatory";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
								var dtfcHoldReason = getPropValue("COMMN_DTFCHOLDREASON");
								if(dtfcHoldReason == "" || dtfcHoldReason == null || dtfcHoldReason == undefined){
									var message = "Kindly select DTFC HOLD REASON";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
								}
                            }
                        }
                        if (self.pg_role == "DTFC HOLD") {
                            if (response == "Send to DTFC Comp") {
                                var branchDecission = getPropValue("COMMN_DTFCHoldBranchdecision");
                                if (branchDecission == "" || branchDecission == undefined || branchDecission == null) {
                                    var message = "Kindly select the branchDecission";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
								
                            }
                        }
						if (self.pg_role == "BRANCH HOLD") {
							if(response != "Reject to Sol Maker"){
								var branchComment = getPropValue("COMMN_BranchComment");
                                if (branchComment != null && branchComment.includes("NA")) {
                                    var message = "Kindly select the Branch Comment in Rejection Grid";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
							}
                        }
						 
                        if (self.pg_role == "BR ACCEPT MAKER") {
                            if (response == "Send to BR Accept Checker") {
                                if (operation == "LODGEMENT") {
                                    var subOperation = getPropValue("COMMN_SubOperation");
                                    if (!(subOperation == "ACCEPTANCE" || subOperation == "ROLLOVER" || subOperation == "DISHONOR")) {
                                        var message = "Kindly select the subOperation out of ACCEPTANCE or ROLLOVER or DISHONOR";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
								 
                            }
                        }
                        if (self.pg_role == "BILL ACCEPTANCE") {
                            if (response == 'Reject to BR Accept Maker') {
                                if (operation == "ROLLOVER") {
                                    var rejectionReason = getPropValue("COMMN_RejectionReason");
                                    var rejectionReasonCount = rejectionReason.length;
                                    var diff = rejectionReasonCount - RejReasonCountOnLoad;
                                    if (diff == 0) {
                                        var message = "Rejection reason is mandatory";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
								
							if (operation == "LODGEMENT"&&(subOperation == "ACCEPTANCE" || subOperation == "ROLLOVER" || subOperation == "DISHONOR")) {
								var acceptanceRejectReason = getPropValue("COMMN_ACCEPTANCEREJECTIONREASON");
								if(acceptanceRejectReason == "" || acceptanceRejectReason == null || acceptanceRejectReason == undefined){
									var message = "Kindly select ACCEPTANCE REJECT REASON";
									abortMessage = abortMessage + "<li>" + message + "</li>";
									addComment(message);
									abortProcess = true;
								}
							}
                            }
							
                            if (response == 'Send to Acceptance Fin STP') {
                                var processingType = getPropValue("COMMN_Accep_ProcessingType");
                                var stpDone = getPropValue("COMMN_L_ACC_STP_DONE");

                                if (processingType != "STP") {
                                    var message = "Kindly choose Processing Type STP";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                } else if (stpDone == true) {
                                    var message = "STP is already been done,kindly check";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == 'Send to Acceptance Fin Entry') {
                                var processingType = getPropValue("COMMN_Accep_ProcessingType");
                                var stpDone = getPropValue("COMMN_L_ACC_STP_DONE");
                                if ((processingType == "STP" && stpDone == false)) {
                                    var message = "For Processing type STP ,WID can't move to Acceptance Fin Entry";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                                if ((processingType == "" || processingType == undefined || processingType == null)) {
                                    var message = "WID can't move to Acceptance Fin Entry,kindly select the processingType as Manual";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
							
							/*Instruction Grid*/
							if(response == 'Send to Acceptance Fin STP' || response == 'Send to Acceptance Fin Entry'){
								var operation = getPropValue("COMMN_Operation");
								var subOperation = getPropValue("COMMN_SubOperation");
								if(operation == 'LODGEMENT'&& subOperation == 'DISHONOR'){
									var filterMessage6 = getPropValue("COMMN_FilterMessage_6");
									var filterMessage6Count = filterMessage6.length;
									var differ = filterMessage6Count - filterMsg6CountOnLoad;
									if(differ == 0){
										var message = "Instruction Grid Dishonour is Mandatory";
										abortMessage = abortMessage + "<li>" + message + "</li>";
										addComment(message);
										abortProcess = true;
									}
								}
								
								if(operation == 'LODGEMENT'&& subOperation == 'ACCEPTANCE'){
									var filterMessage2 = getPropValue("COMMN_FilterMessage_2");
									var filterMessage2Count = filterMessage2.length;
									var differ = filterMessage2Count - filterMsg2CountOnLoad;
									if(differ == 0){
										var message = "Instruction Grid Acceptance is Mandatory";
										abortMessage = abortMessage + "<li>" + message + "</li>";
										addComment(message);
										abortProcess = true;
									}
								}
							}
							
                        }
                        if (self.pg_role == "ACCEPTANCE FIN AUTH") {
                            if (response == 'Send to Acceptance XMM Entry/Mod') {
                                var processingType = getPropValue("COMMN_Accep_ProcessingType");
                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                if (!(processingType == "Manual" && sfmsRequired == "Yes")) {
                                    var message = "Kindly choose Processing Type as Manual and sfmsRequired Yes";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == 'Send to Acceptance SFMS Auth') {
                                var processingType = getPropValue("COMMN_Accep_ProcessingType");
                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                if (!(processingType == "STP" && sfmsRequired == "Yes")) {
                                    var message = "Kindly choose Processing Type as STP and sfmsRequired Yes";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                        }
                        if (self.pg_role == "ACCEPTANCE SFMS AUTH") {
                            if (response == "Send to processed") {
                                var subOperation = getPropValue("COMMN_SubOperation");
                                if (subOperation != "DISHONOR") {
                                    var message = "Kindly select the subOperation as DISHONOR for processed the WID";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == "Send to Pending Realisation") {
                                var subOperation = getPropValue("COMMN_SubOperation");
                                if (!(subOperation == "REALIZATION" || subOperation == "ROLLOVER")) {
                                    var message = "Kindly select the subOperation either REALIZATION or ROLLOVER";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                        }
                        if (self.pg_role == "PENDING REALISATION") {
                            if (response == 'Send to Realisation STP') {
                                var processingType = getPropValue("COMMN_Real_ProcessingType");
                                var stpDone = getPropValue("COMMN_L_REAL_STP_DONE");

                                if (processingType != "STP") {
                                    var message = "Kindly choose Processing Type STP";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                } else if (stpDone == true) {
                                    var message = "STP is already been done,kindly check";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == 'Send to Realisation Fin Entry') {
                                var processingType = getPropValue("COMMN_Real_ProcessingType");
                                var stpDone = getPropValue("COMMN_L_REAL_STP_DONE");
                                if ((processingType == "STP" && stpDone == false)) {
                                    var message = "For Processing type STP ,WID can't move to Realisation Fin Entry";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                                if ((processingType == "" || processingType == undefined || processingType == null)) {
                                    var message = "WID can't move to Realisation Fin Entry,kindly select the processingType as Manual";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
							
							/*Instruction Grid*/
							var operation = getPropValue("COMMN_Operation");
							var subOperation = getPropValue("COMMN_SubOperation");
							if(operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED'){
								var filterMessage4 = getPropValue("COMMN_FilterMessage_4");
								var filterMessage4Count = filterMessage4.length;
								var differ = filterMessage4Count - filterMsg4CountOnLoad;
								if(differ == 0){
									var message = "Instruction Grid Devolved is Mandatory";
									abortMessage = abortMessage + "<li>" + message + "</li>";
									addComment(message);
									abortProcess = true;
								}
							}
							if(operation == 'LODGEMENT' && subOperation == 'REALIZATION'){
								var filterMessage3 = getPropValue("COMMN_FilterMessage_3");
								var filterMessage3Count = filterMessage3.length;
								var differ = filterMessage3Count - filterMsg3CountOnLoad;
								if(differ == 0){
									var message = "Instruction Grid Realization is Mandatory";
									abortMessage = abortMessage + "<li>" + message + "</li>";
									addComment(message);
									abortProcess = true;
								}
							}
							
                        }
                        if (self.pg_role == "REALISATION FIN AUTH") {
                            if (response == 'Send to RTGS Entry') {
                                var processingType = getPropValue("COMMN_Accep_ProcessingType");
                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                if (processingType != "Manual") {
                                    var message = "Kindly choose Processing Type as Manual";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == 'Send to RTGS Auth') {
                                var processingType = getPropValue("COMMN_Accep_ProcessingType");
                                var sfmsRequired = getPropValue("COMMN_SFMSRequired");
                                if (processingType != "STP") {
                                    var message = "Kindly choose Processing Type as STP";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                        }
                        if (self.pg_role == "RTGS AUTH") {
                            // Need to doDeferral reason is mandatory if Deferral DTFC is selected as Yes
                            if (response == 'Send to Devolved') {
                                var paymentTodInvo = getPropValue("COMMN_PaymentthroughTODInvocation");
                                if (paymentTodInvo != "Yes") {
                                    var message = "Kindly choose Payment through TOD/Invocation as Yes";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
								//Diwakar Comment
								var subOperation = getPropValue("COMMN_SubOperation");
								if(!(((subOperation=="REALIZATION"||subOperation=="RECOVERY")&&operation=="LODGEMENT")|| operation == 'PRE-ACCEPTED'||operation == 'ROLLOVER')){
									var message = "Kindly Note that for this SubOperation and Operation, WID can't move to Devolved";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
								}
								
                            }
                            if (response == 'Send to Deferral DTFC') {
                                var paymentTodInvo = getPropValue("COMMN_PaymentthroughTODInvocation");
                                var deferralPending = getPropValue("COMMN_DeferralPending")
                                if (!(paymentTodInvo == "No" && deferralPending == "Yes")) {
                                    var message = "Kindly choose Payment through TOD/Invocation as No and deferralPending Yes";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
								var dtfcDeferralReason = getPropValue("COMMN_DTFCDEEFERALREASON");
								if(dtfcDeferralReason == "" || dtfcDeferralReason == null || dtfcDeferralReason == undefined){
									var message = "Kindly select DTFC DEFERRAL REASON";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
								}
								
								var deferralReason = getPropValue("COMMN_DeferralReason");
								var deferralReasonCount = deferralReason.length;
								var difference = deferralReasonCount - deferralReasonCountOnLoad;
								if(difference == 0){
									var message = "Deferral Grid is Mandatory";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
								}
								
                            }
                            if (response == 'Send to Processed') {
                                var paymentTodInvo = getPropValue("COMMN_PaymentthroughTODInvocation");
                                var deferralPending = getPropValue("COMMN_DeferralPending")
                                if (!(paymentTodInvo == "No" && deferralPending == "No")) {
                                    var message = "Kindly choose Payment through TOD/Invocation as No and deferralPending No";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                        }

                        if (self.pg_role == "DEVOLVED") {
                            if (response == 'Send to Non-Performing Asset') {
                                var recoveryOption = getPropValue("COMMN_Recovery");
                                if (recoveryOption != "Not Recovered even after 90 Days") {
                                    var message = "Kindly choose recoveryOption as Not Recovered even after 90 Days";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == 'Send to STP') {
                                var processingType = getPropValue("COMMN_Dev_ProcessingType");
                                var stpDone = getPropValue("COMMN_L_DEV_STP_DONE");

                                if (processingType != "STP") {
                                    var message = "Kindly choose Processing Type STP";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                } else if (stpDone == true) {
                                    var message = "STP is already been done,kindly check";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == 'Send to Recovery Entry') {
                                var processingType = getPropValue("COMMN_Dev_ProcessingType");
                                var stpDone = getPropValue("COMMN_L_DEV_STP_DONE");
								var recoveryOption = getPropValue("COMMN_Recovery");
                                if ((processingType == "STP" && stpDone == false)) {
                                    var message = "For Processing type STP ,WID can't move to Realisation Fin Entry";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                                if ((processingType == "" || processingType == undefined || processingType == null)||(recoveryOption=="Not Recovered even after 90 Days")) {
                                    var message = "WID can't move to Realisation Fin Entry,kindly select the processingType as Manual";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
							
							/*Instruction Grid*/
							var operation = getPropValue("COMMN_Operation");
							var subOperation = getPropValue("COMMN_SubOperation");
							if((operation == 'LODGEMENT' || operation == 'PRE-ACCEPTED')&& subOperation == 'RECOVERY'){
								var filterMessage5 = getPropValue("COMMN_FilterMessage_5");
								var filterMessage5Count = filterMessage5.length;
								var differ = filterMessage5Count - filterMsg5CountOnLoad;
								if(differ == 0){
									var message = "Instruction Grid Recovery is Mandatory";
									abortMessage = abortMessage + "<li>" + message + "</li>";
									addComment(message);
									abortProcess = true;
								}
							}
							
                        }
                        if (self.pg_role == "RECOVERY AUTH") {
                            var recoveryOption = getPropValue("COMMN_Recovery");
                            var deferralPending = getPropValue("COMMN_DeferralPending")
                            if (response == 'Send to Processed') {
                                if (operation == "LODGEMENT" || operation == "ROLLOVER") {
                                    if (recoveryOption != "Full Recovery") {
                                        var message = "Kindly choose recoveryOption as Full Recovery";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                } else if (operation == "PRE-ACCEPTED") {
                                    if (!(recoveryOption == "Full Recovery" && deferralPending == "No")) {
                                        var message = "Kindly choose recoveryOption as Full Recovery and deferralPending as No";
                                        abortMessage = abortMessage + "<li>" + message + "</li>";
                                        addComment(message);
                                        abortProcess = true;
                                    }
                                }
                            }
                            if (response == 'Reject to Devolved') {
                                if (recoveryOption != "Partial Recovery") {
                                    var message = "Kindly choose recoveryOption as Partial Recovery";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
                            }
                            if (response == 'Send to Deferral DTFC') {
                                var deferralPending = getPropValue("COMMN_DeferralPending")
                                if (!(recoveryOption == "Full Recovery" && deferralPending == "Yes")) {
                                    var message = "Kindly choose recoveryOption as Full Recovery and deferralPending as Yes";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
                                }
								
								var deferralReason = getPropValue("COMMN_DeferralReason");
								var deferralReasonCount = deferralReason.length;
								var difference = deferralReasonCount - deferralReasonCountOnLoad;
								if(difference == 0){
									var message = "Deferral Grid is Mandatory";
                                    abortMessage = abortMessage + "<li>" + message + "</li>";
                                    addComment(message);
                                    abortProcess = true;
								}
                            }
                        }

                        if (self.pg_role == 'PROCESSED') {
                            var message = "No Action is available at Processed Queue";
                            abortMessage = abortMessage + "<li>" + message + "</li>";
                            addComment(message);
                            abortProcess = true;
                        }
                        if (self.pg_role == 'TRASH') {
                            var message = "No Action is available at Trash Queue";
                            abortMessage = abortMessage + "<li>" + message + "</li>";
                            addComment(message);
                            abortProcess = true;
                        }
                        if (self.pg_role == 'DTFC OCR') {
                            var tfcDataCapDoneValue = getPropValue('COMMN_TFCDatacap_Done');
                            var queueID = getPropValue("COMMN_QueueID");

                            if (queueID && tfcDataCapDoneValue != true) {
                                var message = "Open Datacap is Mandatory";
                                abortMessage = abortMessage + "<li>" + message + "</li>";
                                addComment(message);
                                abortProcess = true;

                            }
						}
                        //Workflow Validation Ends...
					
					function insertSTPData(feedURL)
					{
							console.log("Inside webcall");
							var response;
							var xhrArgs = {
							url: feedURL,
							handleAs: "text",
							sync: true,
							preventCache: true,
							headers: {
								"Content-Type": "html/text"
							},
							load: function(result) {
								console.log("Inside Load", result);

								response = result;
								console.log("response: ", response);
							},
							error: function(error) {
								response = "Fail";
								//alert("Check STP service.");
							}
						};

						var deferred = dojo.xhrGet(xhrArgs);
						return response;
					}	
					
					//Confirmation validation
					if(response!=undefined)
					{
						var message = "Are you sure you want to " + response+"</li>"
						confirmationMessage = confirmationMessage+"<li>"+message+"</li>";
						addComment(message);	
					}
					if (response.includes("Reject")|| response.includes("Trash")) {
                          openCommentAction();
                    }
						
					//call Custom Modals
					if(!abortProcess){
						confirmationPopUpViewer(complete,abort);
					}
					else{
						abortPopUpViewer(abort);
					}
						
				//Method used for Confirmation POPUP
				 function confirmationPopUpViewer(complete,abort)
				 {
					 var confirmationDailog = new ecm.widget.dialog.BaseDialog({
							onCancel:function()
							{
								this.hide();
								abort({'silent':true});
							}
					 });
					 confirmationDailog.setTitle("Confirmation");
					 confirmationDailog.setMessage("<ul>"+confirmationMessage+"</ul>", "error");
					 confirmationDailog.addButton("Ok", function(){
						   this.hide();
						   setPropValue("COMMN_LastModifier",self.pg_UserId);
						   //Logic for Rejectecting and trashing WID
                           if (response.includes("Reject") || response.includes("Trash")) 
						   {
								var workitemEdit = self.pg_editable;
                                abort({'silent': true});
                                self.pg_coordination.step(Constants.CoordTopic.SAVE, lang.hitch(this, function(results, next, skip) {
									next();
                                }),
                                lang.hitch(this, function(errors, next, skip) {
                                    skip();
                                })).start(context);
                                workitemEdit.setSelectedResponse(response);
                                workitemEdit.completeStep(lang.hitch(this, function(response) {
                                     self.onBroadcastEvent("icm.ClosePage", payload);
									//comment close
									if (comment_Childwindow != undefined && !comment_Childwindow.closed) {
										comment_Childwindow.close();
									}
									//checklist close
									if (checklist_Childwindow != undefined && !checklist_Childwindow.closed) {
										checklist_Childwindow.close();
									}
									//doc close
									if (childwindow != undefined) {
										CompleteCoordinate.onClickValidate(self.pg_coordination, self.pg_solution);
									}
											
                                }),

                               lang.hitch(this, function(response, fieldErrors) {}));

                           }else{
							   complete();
						   }
						   
						   
					 });
					 confirmationDailog.show();
				 }
			 
				 //Method used for Abort POPUP
				 function abortPopUpViewer(abort)
				 {
					 var abortDailog = new ecm.widget.dialog.BaseDialog();
					 abortDailog.setTitle("Validation");
					 abortDailog.setMessage("<ul>"+abortMessage+"</ul>", "error");		
					 abortDailog.show();
					 abort({'silent':true});
				 }
				
							
			 });
			 
			  self.pg_coordination.participate(Constants.CoordTopic.AFTERSAVE,
                    function(context, complete, abort) {
                        doSavePropsToDB();
                        complete();
                    });
			  self.pg_coordination.participate(Constants.CoordTopic.COMPLETE,
				function(context, complete, abort) {
                     doSavePropsToDB();
					 insertIntoTbml();
					 mailer();
					 complete();
					});		
							
			}
			
			//Open Comments 
			else if(self.pg_eventName=="OnOpenComment")
			{
				openCommentAction();
			} else if(self.pg_eventName=="OnOpenCheckList"){
				if(checklist_Childwindow!=undefined&&!checklist_Childwindow.closed)
				{
					console.log("Checklist window already open.");
					checklist_Childwindow.focus();
				}else{
					self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);
					var caseId = getPropValue('CmAcmCaseIdentifier');
					var role = ecm.model.desktop.currentRole.name;
					var userName = ecm.model.desktop.userDisplayName;
					var productName = "IBC";
					var WorkItemIDVal = getPropValue('COMMN_WID');
					var Operation = getPropValue("COMMN_Operation");
					
					var urlWs = finUrls.checkListUrl;
				   
					OpenCheckListWidget(urlWs, caseId, userName, role, productName, Operation);
					console.log("webService", urlWs);
				
				}
				
			}
			
			function openPopupPage(url,caseId,WorkItemIDVal,dbCheckflag)
			{
				 var params = { 'caseId' : caseId, 'userName': self.pg_UserId , 'role': self.pg_role , 'WorkItemIDVal': WorkItemIDVal , 'productName': self.productName , 'dbCheckflag': dbCheckflag };
				 var sUsrAg = navigator.userAgent;
				 var form = document.createElement("form");
				 
				 form.method='post';
				 form.action = url;
				 form.target = 'newWinname';	

				 for (var i in params)
				 {
				   if (params.hasOwnProperty(i))
				   {
					 var input = document.createElement('input');
					 input.type = 'hidden';
					 input.name = i;
					 input.value = params[i];
					 form.appendChild(input);
				   }
				 }
				 document.body.appendChild(form);
				 comment_Childwindow = window.open("", "newWinname", "width=580,height=580,resizable=yes,top=20,scrollbars=yes");
				
				form.submit();
			}
		
			 function getPropValue(propertyId)
			 {
					if(self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) 
					{
						var propController = self.pg_propCollectionController.getPropertyController(propertyId);
						if(propController!=undefined)
						{
							return propController.get("value");
						}else{
							console.log(propertyId+" is Undefined for this action");
							return null;
						}
					}
			 }
			 function setPropValue(propertyId,value)
			{
				if(self.pg_editable.propertiesCollection.hasOwnProperty(propertyId)) 
				{
					var propController = self.pg_propCollectionController.getPropertyController(propertyId);
					if(propController!=undefined && value!=undefined && value!=null)
					{
						propController.set("value",value);
					}else{
						console.log(propertyId+" is Undefined for this action");
					}
				}
			}
			 function checkGridManatory(props)
			 {
				for(var i = 0; i < props.length; i++) 
				{
					if(self.pg_editable.propertiesCollection.hasOwnProperty(props[i])) 
					{
						var propController = self.pg_propCollectionController.getPropertyController(props[i]);
						if(propController!=undefined)
						{
							var values=propController.get("value");
							if(values.includes(null) || values.length==0){
									return true;
							}
						}else{
								return true;
								console.log(props[i]+" is Undefined for this action");
							}
					}
				}
				return false;
			 }
			 function mailer(){
				
				console.log("pg_role::"+self.pg_role+" response::"+self.response+" operation::"+self.operation);
				
				
				if(self.pg_role == 'SFMS AUTH' && self.response == "Send to BR Accept Maker"){
					sendMail("SFMS_AUTH", "BR_ACCEPT_MAKER", "Send");
				}
				if(self.pg_role == 'PENDING REALISATION' && self.response == "Send to CBO"){
					sendMail("PENDING_REALISE", "CBO", "Send");
				}
				if(self.pg_role == 'PENDING REALISATION' && self.response == "Send to CBO"){
					sendMail("PENDING_REALISE", "CBO", "Send");
				}
				if(self.pg_role == 'FIN AUTH' && self.response == "Send to BR Accept Maker"){
					sendMail("FIN_AUTH", "BR_ACCEPT_MAKER", "Send");
				}
				if(self.pg_role == 'DTFC COMP' && self.response == "Reject to Branch Hold"){
					sendMail("DTFC_COMP", "BRANCH_HOLD", "Reject");
				}
				if(self.pg_role == 'ACCEPTANCE FIN AUTH' && self.response == "Send to Pending Realisation"){
					sendMail("ACCEPT_FIN_AUTH", "PENDING_REALISE", "Send");
				}
				
				
			}
			 function sendMail(fromStep, toStep, action){
				console.log("inside mail", new Date());
				var wid = getPropValue('COMMN_WID');
				var caseId = getPropValue('CmAcmCaseIdentifier');
				var URL = finUrls.EmailUrl;
				URL = URL.replace("%1",fromStep);
				URL = URL.replace("%2",toStep);
				URL = URL.replace("%3",action);
				URL = URL.replace("%4","IBC");
				URL = URL.replace("%5",wid);
				URL = URL.replace("%6",caseId);
				
				callWebService(URL, success);
			}
			  /* Pruthvi 06-05-2020 For Tbml implementation added this piece of code */
			 //Ajax call for  TBML WebService
			 function callWebService(URL, callBack)
			 {
				var response = {};
				console.log("Inside callFinancial Service - URL ", URL);
				console.log("Inside callFinancial Service - CallBack", callBack);
				xhrArgs = {
				url: URL,
				handleAs: "json",
				sync: true,
				preventCache: true,
				headers: { "Content-Type": "application/json"},       
				load: callBack,
				error: function(error)
				{
				   console.log("Inside sol maker work Load  error  " ,error);
				}
						};

				response  = dojo.xhrGet(xhrArgs);
				return response;
			 }
			 function OpenCheckListWidget(urlWs, caseIdentifier, userId, roleName, solutionName, operation) {
				var params = {
					'caseIdentifier': caseIdentifier,
					'userId': userId,
					'roleName': roleName,
					'solutionName': solutionName,
					'operation': operation,
					
				};
				var sUsrAg = navigator.userAgent;
				var form = document.createElement("form");

				form.method = 'post';
				form.action = urlWs;
				form.target = 'newWidWinname';

				for (var i in params) {
					if (params.hasOwnProperty(i)) {
						var input = document.createElement('input');
						input.type = 'hidden';
						input.name = i;
						input.value = params[i];
						form.appendChild(input);
					}
				}
				document.body.appendChild(form);
				checklist_Childwindow = window.open("", "newWidWinname", "width=900,height=600,resizable=yes,scrollbars=yes,left=186, top=43");
				var timer = setInterval(checkChild, 500);

				function checkChild() {
					if (checklist_Childwindow.closed) {
						clearInterval(timer);
						var propertyName = "COMMN_CheckList_Branch_Done,COMMN_CheckList_Compliance_Done";
						getNSetChecklistDoneFlag(propertyName);
					}
				}
				form.submit();
			}
			 function success() {
				 
			 }
			 function getNSetChecklistDoneFlag(propertyNames) {
				var propsCtrl = ControllerManager.bind(self.pg_editable);
				var branchDoneCntrl = propsCtrl.getPropertyController("COMMN_CheckList_Branch_Done");
				var checklistDoneCntrl = propsCtrl.getPropertyController("COMMN_CheckList_Compliance_Done");
				var repositoryID = self.pg_editable.repository.repositoryId;
				var caseIdentifier = self.pg_editable.propertiesCollection.CmAcmCaseIdentifier.value;
				console.log(".....repositoryID " + repositoryID);

				var response = ecm.model.Request.invokePluginServiceSynchronous("CheckDocClassification", "CheckFlagService", {
					requestParams: {
						"caseIdentifier": caseIdentifier,
						"repositoyID": repositoryID,
						"PropertyName": propertyNames
					},

					requestCompleteCallback: lang.hitch(this, function(response) { // success
						console.log(response);
						console.log("response1 ", response.COMMN_CheckList_Branch_Done);
						console.log("response2 ", response.COMMN_CheckList_Compliance_Done);

					}),
					requestFailedCallback: lang.hitch(this, function(response) { // failed

					})
				});
				if (branchDoneCntrl != undefined) {

					branchDoneCntrl.set('value', response.COMMN_CheckList_Branch_Done);
				}
				if (checklistDoneCntrl != undefined) {
					checklistDoneCntrl.set('value', response.COMMN_CheckList_Compliance_Done);
				}
				ControllerManager.unbind(self.pg_editable);
			}
			 function openCommentAction() {

                if (comment_Childwindow != undefined && !comment_Childwindow.closed) {
                    console.log("Comment window already open.");
                    comment_Childwindow.focus();
                } else {
                   console.log("Open comment window:::",self.pg_editable);
					self.pg_propCollectionController = ControllerManager.bind(self.pg_editable);
					var caseId = getPropValue('CmAcmCaseIdentifier');
					var WorkItemIDVal = getPropValue('COMMN_WID');
					var dbCheckflag = "No";
					var url=finUrls.commentsUrl;
					console.log("webService",url);
					openPopupPage(url,caseId,WorkItemIDVal,dbCheckflag);
                }

            }
			 function tbmlProcessFlgUpdate(response) {
                var map = {
                    'PROCESS_FLG': 'COMMN_TBMLDecision',
                    'IS_PICKED_UP': 'COMMN_TBMLStatus',
                    'REMARKS': 'COMMN_TBMLRemarks'
                };
                var tbmlDecPropController = self.pg_propCollectionController.getPropertyController('COMMN_TBMLDecision');
				var tbmlStatPropController = self.pg_propCollectionController.getPropertyController('COMMN_TBMLStatus');
				var tbmlRemPropController = self.pg_propCollectionController.getPropertyController('COMMN_TBMLRemarks');
                if (tbmlDecPropController) {
                    tbmlDecPropController.set("value", response.PROCESS_FLG);
                }
                 if (tbmlStatPropController) {
                    tbmlStatPropController.set("value", response.IS_PICKED_UP);
                }
				 if (tbmlRemPropController) {
                    tbmlRemPropController.set("value", response.REMARKS);
                }
            }
			  function insertIntoTbml()
			 {	
				if(self.pg_role=='DTFC OCR')
				{
					if(getPropValue('COMMN_TBMLEnableSOL').toUpperCase() == 'YES')
					{
						var wid = getPropValue('COMMN_WID');
						var product = getPropValue('COMMN_Product');
						var caseId = getPropValue('CmAcmCaseIdentifier');
						var solId = getPropValue('COMMN_SOLID');
						var custId = getPropValue('COMMN_Custid');
						var vehicleNo1 = getPropValue('COMMN_VEHICLEREGISTRATIONNO1');
						var vehicleNo2 = getPropValue('COMMN_VEHICLEREGISTRATIONNO2');
						var url=finUrls.insertTBMLData;
						url =url.replace("%1",wid);
						url =url.replace("%2","IBC");
						url =url.replace("%3",caseId);
						url =url.replace("%4",solId);
						url =url.replace("%5",custId);
						url =url.replace("%6",vehicleNo1);
						url =url.replace("%7",vehicleNo2);
						callWebService(url, success);
					}
				}	
			}	
			 function doSavePropsToDB() {
                var caseFolderId = self.pg_editable.icmWorkItem.caseFolderId;
                var repoId = self.pg_editable.icmWorkItem.repository.name.toLowerCase();
                var wid = getPropValue("COMMN_WID");
                ecm.model.Request.invokePluginService("CustomPlugin", "SavePropToDbService", {
                    requestParams: {
                        "product": self.productName,
     
                   "folderId": caseFolderId,
                        "repositoryId": repoId,
                        "wid": wid
                    },
                    backgroundRequest: true,
                    requestCompleteCallback: lang.hitch(this, function(response) {
                        console.log("resp: ", response);
                    }),
                    requestFailedCallback: lang.hitch(this, function(response) {
                        console.log("SavePropToDbService Failed to save data.", response);

                    })
                });
            }
			
			//Method to push all warning messages to Comment
			function addComment(validationMessage)
			{
				var msg ="Warning : "+validationMessage;
				validationMessage = msg;
				var currentCase = self.pg_editable.getCase();
				console.log("currentCase ", currentCase);
				currentCase.addCaseComment(102,validationMessage,
					function(){
						console.log("Message set");
					}
					,function(e){
						console.error("could not create case comment",e)
					}, true);
			}
          
			/* End */
	    	
	    	
	    }
	
	});


});
