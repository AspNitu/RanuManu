package com.dgsl.plugin;

import java.util.Iterator;


import javax.servlet.http.HttpServletRequest;

import com.ibm.ecm.extension.PluginResponseFilter;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class AuditorFilter extends PluginResponseFilter {
	public String[] getFilteredServices() {
		return new String[] { "/p8/search","/p8/continueQuery" };
	}
	public void filter(String serverType, PluginServiceCallbacks callbacks,
			HttpServletRequest request, JSONObject jsonResponse) throws Exception {
		try
		{
			String desktop = request.getParameter("desktop");
			String Solution = jsonResponse.get("template_name").toString();
			System.out.println("Desktop ::: "+desktop +" Solution:::::"+Solution);
			
			
			if(desktop !=null && desktop .equalsIgnoreCase("icm"))
			{
				if(Solution.equalsIgnoreCase("IBG_InlandBankGuarantee"))
				{
					JSONArray rows =  (JSONArray) jsonResponse.get("rows");
					JSONArray tempRows = new JSONArray() ;
					Integer numberOfRows =(Integer) jsonResponse.get("num_results") ;
					if(numberOfRows>0)
					{
						Iterator<Object> itr=rows.iterator();
						while(itr.hasNext())
						{
							JSONObject rowObject = (JSONObject)itr.next();
							JSONObject attributes = (JSONObject) rowObject.get("attributes");
							JSONArray caseStatus = (JSONArray) attributes.get("COMMN_CaseStatus");
							String pendingWith="";
							if(caseStatus.get(0)!=null)
							{
								pendingWith  = caseStatus.get(0).toString();
							}
							
							System.out.println("2...."+pendingWith);
							if((!(pendingWith.equalsIgnoreCase("Pending With Processed")||pendingWith.equalsIgnoreCase("Pending With Deferral DTFC")||
									pendingWith.equalsIgnoreCase("Pending With Deferral Branch")))&&pendingWith!=null)
							{
								itr.remove();
							}
							
						}
	
					
					}
					
				}
				
				else if(Solution.equalsIgnoreCase("FBG_ForeignBankGuarantee"))
				{
					JSONArray rows =  (JSONArray) jsonResponse.get("rows");
					JSONArray tempRows = new JSONArray() ;
					Integer numberOfRows =(Integer) jsonResponse.get("num_results") ;
					if(numberOfRows>0)
					{
						Iterator<Object> itr=rows.iterator();
						while(itr.hasNext())
						{
							JSONObject rowObject = (JSONObject)itr.next();
							JSONObject attributes = (JSONObject) rowObject.get("attributes");
							JSONArray caseStatus = (JSONArray) attributes.get("COMMN_CaseStatus");
							String pendingWith="";
							if(caseStatus.get(0)!=null)
							{
								pendingWith  = caseStatus.get(0).toString();
							}
							
							System.out.println("2...."+pendingWith);
							if((!(pendingWith.equalsIgnoreCase("At PROCESSED")||pendingWith.equalsIgnoreCase("At Defferal Pending TFC")||
									pendingWith.equalsIgnoreCase("At Defferal Pending Branch")))&&pendingWith!=null)
							{
								itr.remove();
							}
							
						}
	
					
					}
					
				}
				
				else if(Solution.equalsIgnoreCase("ILC_InlandLetterofCredit"))
				{
					JSONArray rows =  (JSONArray) jsonResponse.get("rows");
					JSONArray tempRows = new JSONArray() ;
					Integer numberOfRows =(Integer) jsonResponse.get("num_results") ;
					if(numberOfRows>0)
					{
						Iterator<Object> itr=rows.iterator();
						while(itr.hasNext())
						{
							JSONObject rowObject = (JSONObject)itr.next();
							JSONObject attributes = (JSONObject) rowObject.get("attributes");
							JSONArray caseStatus = (JSONArray) attributes.get("COMMN_StepName");
							String pendingWith="";
							if(caseStatus.get(0)!=null)
							{
								pendingWith  = caseStatus.get(0).toString();
							}
							
							System.out.println("2...."+pendingWith);
							if((!(pendingWith.equalsIgnoreCase("At PROCESSED Stage")||pendingWith.equalsIgnoreCase("At DEFERRAL BRANCH Stage")||
									pendingWith.equalsIgnoreCase("At DEFERRAL DTFC Stage")))&&pendingWith!=null)
							{
								itr.remove();
							}
							
						}
	
					
					}
					
				}
				else if(Solution.equalsIgnoreCase("FLC_LetterofCredit"))
				{
					JSONArray rows =  (JSONArray) jsonResponse.get("rows");
					JSONArray tempRows = new JSONArray() ;
					Integer numberOfRows =(Integer) jsonResponse.get("num_results") ;
					if(numberOfRows>0)
					{
						Iterator<Object> itr=rows.iterator();
						while(itr.hasNext())
						{
							JSONObject rowObject = (JSONObject)itr.next();
							JSONObject attributes = (JSONObject) rowObject.get("attributes");
							JSONArray caseStatus = (JSONArray) attributes.get("COMMN_StepName");
							String pendingWith="";
							if(caseStatus.get(0)!=null)
							{
								pendingWith  = caseStatus.get(0).toString();
							}
							
							System.out.println("2...."+pendingWith);
							if((!(pendingWith.equalsIgnoreCase("At PROCESSED Stage")||pendingWith.equalsIgnoreCase("At DEFERRAL BRANCH Stage")||
									pendingWith.equalsIgnoreCase("At DEFERRAL TFC Stage")))&&pendingWith!=null)
							{
								itr.remove();
							}
							
						}
	
					
					}
					
				}
				
			}
			System.out.println("Final Response:: "+jsonResponse.toString());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("SearchFilter.filter()  " +e);
		}
	
		
		
		
	}
		
		
	}

