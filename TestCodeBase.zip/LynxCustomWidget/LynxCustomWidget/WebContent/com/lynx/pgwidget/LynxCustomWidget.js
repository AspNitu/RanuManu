define([
	"dojo/_base/declare",
	"dojo/json",
	"icm/base/BasePageWidget",
	"icm/base/_BaseWidget",
	"dojo/text!./templates/LynxCustomWidget.html",
	"dijit/form/Button"
], function(declare, json, BasePageWidget, _BaseWidget, template){
	return declare("com.lynx.pgwidget.LynxCustomWidget", [_BaseWidget, BasePageWidget], {
		templateString: template,

		postCreate: function(){
		}
	});
});
